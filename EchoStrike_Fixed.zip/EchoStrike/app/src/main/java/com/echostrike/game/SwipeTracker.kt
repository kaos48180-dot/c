package com.echostrike.game

import android.view.MotionEvent
import kotlin.math.abs
import kotlin.math.max

/**
 * SwipeTracker — detects swipes and multi-finger taps straight from touch events.
 *
 * Android's GestureDetector.onFling only ever sees the FIRST finger and its parameter
 * types differ between SDK versions, so two/three-finger gestures never worked. This
 * tracks the centre of all fingers and reports how many fingers were used.
 */
class SwipeTracker(
    private val minDistancePx: Float,
    private val onSwipe: (direction: Direction, fingers: Int) -> Unit,
    private val onMultiTap: (fingers: Int) -> Unit
) {
    enum class Direction { UP, DOWN, LEFT, RIGHT }

    /** True once a second finger touched during the current gesture. */
    var multiTouch = false
        private set

    private var startX = 0f
    private var startY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var maxFingers = 0
    private var startTime = 0L
    private var active = false

    fun onTouchEvent(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                multiTouch = false
                maxFingers = 1
                startTime = ev.eventTime
                centre(ev); startX = lastX; startY = lastY
                active = true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (!active) return
                maxFingers = max(maxFingers, ev.pointerCount)
                multiTouch = true
                // measure movement from the moment all fingers are down
                centre(ev); startX = lastX; startY = lastY
            }
            MotionEvent.ACTION_MOVE -> if (active) centre(ev)
            MotionEvent.ACTION_POINTER_UP -> if (active) centre(ev)
            MotionEvent.ACTION_CANCEL -> active = false
            MotionEvent.ACTION_UP -> {
                if (!active) return
                active = false
                val dx = lastX - startX
                val dy = lastY - startY
                val elapsed = ev.eventTime - startTime
                val dist = max(abs(dx), abs(dy))
                if (dist >= minDistancePx && elapsed <= 900) {
                    val dir = if (abs(dx) > abs(dy)) {
                        if (dx > 0) Direction.RIGHT else Direction.LEFT
                    } else {
                        if (dy > 0) Direction.DOWN else Direction.UP
                    }
                    onSwipe(dir, maxFingers)
                } else if (maxFingers >= 2 && dist < minDistancePx && elapsed <= 450) {
                    onMultiTap(maxFingers)
                }
            }
        }
    }

    private fun centre(ev: MotionEvent) {
        var sx = 0f; var sy = 0f
        for (i in 0 until ev.pointerCount) { sx += ev.getX(i); sy += ev.getY(i) }
        lastX = sx / ev.pointerCount
        lastY = sy / ev.pointerCount
    }
}
