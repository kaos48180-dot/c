package com.echostrike.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.echostrike.audio.EchoAudioEngine
import com.echostrike.game.SwipeTracker
import com.echostrike.network.NetworkManager
import com.echostrike.network.ServerConfig
import com.echostrike.game.BotBrain
import com.echostrike.server.HostOptions
import android.widget.CheckBox
import android.widget.TextView
import com.echostrike.server.FoundServer
import com.echostrike.weapons.WeaponRegistry
import com.echostrike.weapons.WeaponRegistry.announce
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Main menu. Swipe up/down to browse, double tap to select, long press to hear the item again.
 *
 *   0 Host Game          — start the embedded server on this phone and play on it
 *   1 Cloud Multiplayer  — sign in to your cloud server and play there
 *   2 Find LAN Game      — look for games on the same WiFi
 *   3 Join by Address    — type a hostname or IP address
 *   4 Weapons            — browse the weapon list
 *   5 Settings           — your player name
 *   6 About
 *   7 Quit               — select twice to quit
 */
class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private lateinit var audio: EchoAudioEngine
    private lateinit var network: NetworkManager
    private lateinit var gesture: GestureDetector
    private lateinit var swipes: SwipeTracker

    private val menuItems = listOf(
        "Play Offline", "Play Online", "Host Game", "Find LAN Game",
        "Weapons", "Settings", "About", "Quit"
    )
    private var menuIndex = 0
    private var ttsReady = false
    private var pendingGreeting = false

    // weapon browser sub-screen
    private var inWeapons = false
    private var weaponIndex = 0

    private var quitArmedUntil = 0L
    private var joining = false
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Full-screen black layout — this is an audio game
        val root = View(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        setContentView(root)

        tts = TextToSpeech(this, this)
        audio = EchoAudioEngine(this)
        network = NetworkManager.shared(this)

        gesture = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean { selectMenuItem(); return true }
            override fun onLongPress(e: MotionEvent) { announceCurrentItem() }
        })
        swipes = SwipeTracker(
            minDistancePx = 64f * resources.displayMetrics.density,
            onSwipe = { dir, _ ->
                when (dir) {
                    SwipeTracker.Direction.UP -> navigate(-1)
                    SwipeTracker.Direction.DOWN -> navigate(+1)
                    SwipeTracker.Direction.LEFT, SwipeTracker.Direction.RIGHT ->
                        if (inWeapons) closeWeapons() else speak("Swipe up or down to browse. Double tap to select.")
                }
            },
            onMultiTap = { }
        )

        root.setOnTouchListener { _, ev: MotionEvent ->
            swipes.onTouchEvent(ev)
            gesture.onTouchEvent(ev)
            true
        }

        handleConfigureIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleConfigureIntent(intent)
    }

    /**
     * The Developer Console app can send us the server address. Only the console that is signed
     * with the same key as this app is accepted, so no other app can change where we connect.
     */
    private fun handleConfigureIntent(i: Intent?) {
        if (i?.action != ServerConfig.ACTION_CONFIGURE) return
        val caller = callingPackage
        val trusted = caller == ServerConfig.CONSOLE_PACKAGE &&
            packageManager.checkSignatures(packageName, caller) == PackageManager.SIGNATURE_MATCH
        if (!trusted) {
            setResult(RESULT_CANCELED)
            return
        }
        val host = ServerConfig.save(this, i.getStringExtra(ServerConfig.EXTRA_HOST) ?: "")
        if (host != null) getSharedPreferences("echostrike", MODE_PRIVATE).edit().putString("last_server", host).apply()
        getSharedPreferences("cloud_session", MODE_PRIVATE).edit().remove("session_token").apply()
        setResult(RESULT_OK, Intent().putExtra(ServerConfig.EXTRA_HOST, host ?: ""))
        i.action = null
        val msg = if (host != null) "Server set to $host by the developer console. Choose Play Online to sign in."
                  else "The developer console sent an invalid server address."
        if (ttsReady) speak(msg) else { pendingGreeting = false; ui.postDelayed({ speak(msg) }, 1500) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.US
            ttsReady = true
            audio.playAppStart()
            speak("EchoStrike. Swipe up or down to browse the menu. Double tap to select.")
            announceCurrentItem(queue = true)
        }
    }

    private fun navigate(dir: Int) {
        if (inWeapons) {
            val n = WeaponRegistry.ALL_WEAPONS.size
            weaponIndex = (weaponIndex + dir + n) % n
            audio.playFocusRing(weaponIndex)
            announceWeapon()
            return
        }
        quitArmedUntil = 0L
        val next = (menuIndex + dir).coerceIn(0, menuItems.lastIndex)
        if (next == menuIndex) audio.playLast() else { menuIndex = next; audio.playMenuFocus(menuIndex) }
        announceCurrentItem()
    }

    private fun announceCurrentItem(queue: Boolean = false) {
        if (inWeapons) { announceWeapon(); return }
        val item = menuItems[menuIndex]
        val host = ServerConfig.host(this)
        val hint = when (item) {
            "Play Offline" -> "$item. Practice against bots on this phone. No internet needed."
            "Play Online" -> "$item. Sign in or create an account and play on a main server."
            "Host Game" -> "$item. Host a game on this device. Friends must be able to reach your network."
            "Find LAN Game" -> "$item. Searches your WiFi for open EchoStrike games."
            "Weapons" -> "$item. Browse all ${WeaponRegistry.ALL_WEAPONS.size} weapons. All unlocked. Infinite ammo."
            "Settings" -> "$item. Player name, bots, and difficulty."
            "About" -> "$item. Version info."
            "Quit" -> "$item. Exit the application. Select twice to quit."
            else -> item
        }
        speak(hint, queue)
    }

    private fun selectMenuItem() {
        if (inWeapons) { closeWeapons(); return }
        audio.playFinalize()
        when (menuItems[menuIndex]) {
            "Play Offline" -> playOffline()
            "Play Online" -> startActivity(Intent(this, ConnectActivity::class.java))
            "Host Game" -> hostGame()
            "Find LAN Game" -> findLanGame()
            "Weapons" -> openWeapons()
            "Settings" -> openSettings()
            "About" -> about()
            "Quit" -> confirmQuit()
        }
    }

    // ── OFFLINE ──────────────────────────────────────────────────────────
    private fun playOffline() {
        speak("Starting offline game.")
        startActivity(Intent(this, GameActivity::class.java).apply {
            putExtra("offline", true)
            putExtra("bots", prefs().getInt("offline_bots", 3))
            putExtra("difficulty", prefs().getInt("difficulty", 2))
        })
    }

    private fun prefs() = getSharedPreferences("echostrike", MODE_PRIVATE)

    // ── HOST ─────────────────────────────────────────────────────────────
    private fun hostGame() {
        if (joining) return
        joining = true
        speak("Starting private server. Please wait.")
        network.hostAndJoin(
            displayName = getDisplayName(),
            options = HostOptions(
                serverName = getDisplayName() + "'s game",
                botCount = prefs().getInt("host_bots", 0),
                botDifficulty = BotBrain.Difficulty.fromLevel(prefs().getInt("difficulty", 2))
            ),
            onReady = { ip ->
                joining = false
                audio.playConnected()
                speak("Server running. Your IP is ${ip.replace(".", " dot ")}. " +
                      "Share this with friends so they can join. Starting game.")
                launchGame(isHost = true)
            },
            onRejected = { reason ->
                joining = false
                network.shutdown()
                audio.playNoText()
                speak("Could not start server. $reason")
                Toast.makeText(this, "Server error: $reason", Toast.LENGTH_LONG).show()
            }
        )
    }

    // ── CLOUD MULTIPLAYER ────────────────────────────────────────────────
    private fun connectCloud() {
        val host = ServerConfig.host(this)
        if (host.isBlank()) {
            speak("No cloud server is set. Opening the connect form.")
            startActivity(Intent(this, ConnectActivity::class.java))
            return
        }
        val token = getSharedPreferences("cloud_session", MODE_PRIVATE).getString("session_token", null)
        if (!token.isNullOrBlank()) {
            speak("Connecting to $host.")
            joinCloudWithToken(host, token, true)
        } else showCloudLogin(host)
    }

    private fun showCloudLogin(host: String) {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 8, 32, 8) }
        val username = EditText(this).apply {
            hint = "Account username (default Chaos)"
            setText("Chaos")
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val password = EditText(this).apply {
            hint = "Account password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        layout.addView(username); layout.addView(password)
        android.app.AlertDialog.Builder(this)
            .setTitle("EchoStrike Cloud Sign In")
            .setMessage("Server: $host\nUse the account set in the Developer Console.")
            .setView(layout)
            .setPositiveButton("Sign in") { _, _ ->
                val user = username.text.toString().trim()
                val pass = password.text.toString()
                if (user.isBlank() || pass.isBlank()) { speak("Enter your username and password."); return@setPositiveButton }
                speak("Signing in. Please wait.")
                thread {
                    var connection: HttpURLConnection? = null
                    val result: String = try {
                        val c = (URL("https://$host/api/login").openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"; connectTimeout = 10000; readTimeout = 10000; doOutput = true
                            setRequestProperty("Content-Type", "application/json")
                        }
                        connection = c
                        val payload = JSONObject().put("username", user).put("password", pass).toString()
                        c.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                        val code = c.responseCode
                        val stream = if (code in 200..299) c.inputStream else c.errorStream
                        val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                        if (code in 200..299) {
                            JSONObject(body).optString("token").ifBlank { "ERROR:The server did not return a session." }
                        } else {
                            val msg = try { JSONObject(body).optString("error") } catch (_: Exception) { "" }
                            "ERROR:" + msg.ifBlank { "Sign-in failed. Check the account and server setup." }
                        }
                    } catch (e: Exception) {
                        "ERROR:${e.message ?: "network error"}"
                    } finally {
                        connection?.disconnect()
                    }
                    runOnUiThread {
                        if (result.startsWith("ERROR:")) {
                            speak(result.removePrefix("ERROR:"))
                            Toast.makeText(this, result.removePrefix("ERROR:"), Toast.LENGTH_LONG).show()
                        } else {
                            // Only the revocable session token is stored, never the password.
                            getSharedPreferences("cloud_session", MODE_PRIVATE).edit().putString("session_token", result).apply()
                            speak("Signed in. Connecting to the cloud server.")
                            joinCloudWithToken(host, result, false)
                        }
                    }
                }
            }
            .setNegativeButton("Cancel") { _, _ -> speak("Sign in cancelled.") }
            .show()
    }

    private fun joinCloudWithToken(host: String, token: String, allowPrompt: Boolean) {
        if (joining) return
        joining = true
        network.join(
            host = host,
            displayName = getDisplayName(),
            authToken = token,
            onConnected = { joining = false; launchGame(isHost = false) },
            onRejected = { reason ->
                joining = false
                getSharedPreferences("cloud_session", MODE_PRIVATE).edit().remove("session_token").apply()
                speak("Cloud connection failed. $reason")
                Toast.makeText(this, reason, Toast.LENGTH_LONG).show()
                if (allowPrompt && reason.contains("sign in", ignoreCase = true)) showCloudLogin(host)
            }
        )
    }

    // ── FIND LAN GAME ────────────────────────────────────────────────────
    private fun findLanGame() {
        speak("Searching for games on your WiFi. Please wait.")
        val found = mutableListOf<FoundServer>()
        network.discover { server ->
            found.add(server)
            speak("Found game. Host IP ${server.ip.replace(".", " dot ")}. " +
                  "${server.players} of ${server.maxPlayers} players. Joining.")
            if (found.size == 1) joinServer(server.ip)
        }
        ui.postDelayed({
            if (found.isEmpty()) audio.playNoText()
            if (found.isEmpty()) speak("No games found on your WiFi. Ask your friend to start hosting, then try again.")
        }, 5500)
    }

    private fun joinServer(host: String) {
        if (joining) return
        joining = true
        speak("Joining game at $host.")
        network.join(
            host = host,
            displayName = getDisplayName(),
            onConnected = { joining = false; audio.playConnected(); launchGame(isHost = false) },
            onRejected = { reason ->
                joining = false
                audio.playNoText()
                speak("Could not join. $reason")
                Toast.makeText(this, "Join failed: $reason", Toast.LENGTH_LONG).show()
            }
        )
    }

    // ── JOIN BY ADDRESS ──────────────────────────────────────────────────
    @Suppress("unused")
    private fun joinByAddress() {
        val et = EditText(this).apply {
            hint = "192.168.1.5 or a server name"
            // URI keyboard: letters, numbers, dots and dashes (a phone keypad can't type hostnames)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Enter Server Address")
            .setMessage("Enter your friend's IP address (LAN game).")
            .setView(et)
            .setPositiveButton("Join") { _, _ ->
                val address = et.text.toString().trim()
                if (address.isNotEmpty()) joinServer(address) else speak("No address entered.")
            }
            .setNegativeButton("Cancel") { _, _ -> speak("Cancelled.") }
            .show()
    }

    // ── WEAPONS ──────────────────────────────────────────────────────────
    private fun openWeapons() {
        inWeapons = true
        audio.playWindowOpen()
        weaponIndex = 0
        speak("Weapons. Swipe up or down to browse. Double tap or swipe sideways to go back.")
        ui.postDelayed({ if (inWeapons) announceWeapon(queue = true) }, 100)
    }

    private fun announceWeapon(queue: Boolean = false) {
        val w = WeaponRegistry.ALL_WEAPONS[weaponIndex]
        speak("${weaponIndex + 1} of ${WeaponRegistry.ALL_WEAPONS.size}. ${w.announce()}", queue)
    }

    private fun closeWeapons() {
        inWeapons = false
        audio.playCancelSoft()
        speak("Main menu.")
        announceCurrentItem(queue = true)
    }

    // ── SETTINGS ─────────────────────────────────────────────────────────
    private fun openSettings() {
        audio.playDialog()
        val pf = prefs()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 8, 32, 8) }
        fun lab(t: String) = TextView(this).apply { text = t; setPadding(0, 16, 0, 0) }
        val nameEt = EditText(this).apply {
            hint = "Player name"; setText(getDisplayName()); inputType = InputType.TYPE_CLASS_TEXT
        }
        val offBots = EditText(this).apply {
            hint = "Offline bots (1 to 12)"; setText(pf.getInt("offline_bots", 3).toString()); inputType = InputType.TYPE_CLASS_NUMBER
        }
        val hostBots = EditText(this).apply {
            hint = "Bots when you host (0 = none)"; setText(pf.getInt("host_bots", 0).toString()); inputType = InputType.TYPE_CLASS_NUMBER
        }
        val diff = EditText(this).apply {
            hint = "Bot difficulty 1 easy, 2 normal, 3 hard"; setText(pf.getInt("difficulty", 2).toString()); inputType = InputType.TYPE_CLASS_NUMBER
        }
        col.addView(lab("Player name")); col.addView(nameEt)
        col.addView(lab("Offline bots (1 to 12)")); col.addView(offBots)
        col.addView(lab("Bots added when you host. Use 0 for no bots.")); col.addView(hostBots)
        col.addView(lab("Bot difficulty: 1 easy, 2 normal, 3 hard")); col.addView(diff)
        android.app.AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(android.widget.ScrollView(this).apply { addView(col) })
            .setPositiveButton("Save") { _, _ ->
                val name = nameEt.text.toString().trim().take(20)
                val e = pf.edit()
                if (name.isNotEmpty()) e.putString("display_name", name)
                e.putInt("offline_bots", (offBots.text.toString().toIntOrNull() ?: 3).coerceIn(1, 12))
                e.putInt("host_bots", (hostBots.text.toString().toIntOrNull() ?: 0).coerceIn(0, 12))
                e.putInt("difficulty", (diff.text.toString().toIntOrNull() ?: 2).coerceIn(1, 3))
                e.apply()
                audio.playCheckboxOn()
                speak("Settings saved.")
            }
            .setNegativeButton("Cancel") { _, _ -> audio.playCancelSoft(); speak("Cancelled.") }
            .show()
    }

    // ── ABOUT ────────────────────────────────────────────────────────────
    private fun about() {
        val host = ServerConfig.host(this)
        speak("EchoStrike version 1. Host a game on your phone, join one on your WiFi, or play on the cloud server. " +
              if (host.isBlank()) "No cloud server is set." else "Cloud server is $host.")
    }

    // ── QUIT ─────────────────────────────────────────────────────────────
    private fun confirmQuit() {
        val now = System.currentTimeMillis()
        if (now < quitArmedUntil) {
            audio.playExit()
            speak("Goodbye.")
            ui.postDelayed({ network.shutdown(); finishAffinity() }, 900)
        } else {
            quitArmedUntil = now + 5000
            speak("Quit EchoStrike? Select Quit again within five seconds to confirm.")
        }
    }

    // ── GAME ─────────────────────────────────────────────────────────────
    private fun launchGame(isHost: Boolean) {
        startActivity(Intent(this, GameActivity::class.java).apply {
            putExtra("isHost", isHost)
        })
    }

    private fun getDisplayName() =
        getSharedPreferences("echostrike", MODE_PRIVATE).getString("display_name", "Chaos") ?: "Chaos"

    private fun speak(text: String, queue: Boolean = false) {
        if (ttsReady) tts.speak(text, if (queue) TextToSpeech.QUEUE_ADD else TextToSpeech.QUEUE_FLUSH, null, null)
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        tts.shutdown()
        audio.release()
        if (isFinishing) network.shutdown()
    }
}
