package com.echostrike.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.media.audiofx.EnvironmentalReverb
import android.media.audiofx.Equalizer
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.*
import com.echostrike.weapons.WeaponRegistry
import java.io.File
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.*

/**
 * EchoAudioEngine — BGT-inspired 3D spatial audio engine for Android.
 *
 * Mimics BGT's sound object model:
 *   - Each sound has X/Y/Z position in 3D space
 *   - Listener has a position and angle (facing direction)
 *   - Distance falloff, panning, pitch shifting all automatic
 *   - Environment presets (indoor, outdoor, cave, etc.)
 *
 * Sound file → Gesture mapping (from VoiceOver_2025_by_mkhize_ pack):
 *   gesture_begin.ogg    → Any gesture starts
 *   gesture_end.ogg      → Any gesture ends
 *   click.ogg            → Single tap / select
 *   long_clicked.ogg     → Long press
 *   scroll_down.ogg      → Swipe down (menu navigate down)
 *   KeyboardUp.ogg       → Swipe up (menu navigate up)
 *   KeyboardDown.ogg     → Swipe down secondary / move backward in game
 *   window_state.ogg     → Screen/menu open
 *   dialog.ogg           → Dialog/popup opened
 *   start.ogg            → Game session start
 *   Start.mp3            → App startup splash
 *   finalize.ogg         → Action confirmed / match found
 *   cancel.ogg           → Back / cancel gesture
 *   exit.mp3             → Exit/quit game
 *   button.wav           → Button focused
 *   listitem.wav         → List item focused (swipe up/down in menus)
 *   checkbox.wav         → Checkbox unfocused
 *   checkbox_checked.wav → Checkbox toggled on
 *   combobox.wav         → Dropdown focused
 *   link.wav             → Link/navigation item focused
 *   caret.wav            → Text cursor moved
 *   focus0.ogg           → Primary focus change
 *   focus2.ogg           → Secondary focus change
 *   enfoque 1.mp3        → Focus ring appear (Spanish: enfoque = focus)
 *   enfoque 2.ogg        → Focus highlight move
 *   enfoque 3.ogg        → Focus confirm
 *   last.wav             → Last item in list reached
 *   notext.wav           → No text / empty field
 *   listening.ogg        → Voice input active
 *   pause.ogg            → Game paused
 *   ReceivedMessage.ogg  → Chat message received
 *   SiriAutoSend_Haptic.ogg → Chat message sent
 *   ScreenCapture.ogg    → Screenshot (kill confirmed sound in game)
 *   window_state.ogg     → Window/menu state change
 */
class EchoAudioEngine(private val context: Context) {

    companion object {
        private const val TAG = "EchoAudioEngine"
        const val MAX_STREAMS = 32
        const val MAX_DISTANCE = 80f       // meters, beyond this volume = 0
        const val REF_DISTANCE = 1f        // full volume within this distance
        const val ROLLOFF_FACTOR = 0.3f    // how fast volume drops with distance (low = far sounds stay audible)

        // Environment presets
        const val ENV_OUTDOOR = 0
        const val ENV_INDOOR = 1
        const val ENV_CAVE = 2
        const val ENV_CORRIDOR = 3
        const val ENV_ARENA = 4

        @Volatile
        private var instance: EchoAudioEngine? = null

        fun getInstance(context: Context): EchoAudioEngine {
            return instance ?: synchronized(this) {
                instance ?: EchoAudioEngine(context.applicationContext).also { instance = it }
            }
        }
    }

    // ─── SoundPool ────────────────────────────────────────────────────────────
    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(MAX_STREAMS)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val loadedSounds = ConcurrentHashMap<String, Int>()   // assetPath → soundId
    private val activeSounds = ConcurrentHashMap<Int, SoundInstance>() // streamId → instance
    // SoundPool loads asynchronously; a sound can only be played once it is in this set.
    private val readySounds: MutableSet<Int> = ConcurrentHashMap.newKeySet()
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // ─── Listener state ───────────────────────────────────────────────────────
    var listenerX = 0f
    var listenerY = 0f
    var listenerZ = 0f
    var listenerAngle = 0f   // degrees, 0=north, 90=east, 180=south, 270=west
    var currentEnvironment = ENV_OUTDOOR

    // ─── TTS ──────────────────────────────────────────────────────────────────
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // ─── Reverb ───────────────────────────────────────────────────────────────
    private var reverb: EnvironmentalReverb? = null

    init {
        soundPool.setOnLoadCompleteListener { _, soundId, status ->
            if (status == 0) readySounds.add(soundId)
        }
        initTTS()
        initReverb()
        preloadMenuSounds()
    }

    // ── TTS ───────────────────────────────────────────────────────────────────
    private fun initTTS() {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                ttsReady = true
            }
        }
    }

    fun speak(text: String, interrupt: Boolean = true) {
        if (!ttsReady) return
        val queueMode = if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        tts?.speak(text, queueMode, null, UUID.randomUUID().toString())
    }

    fun stopSpeaking() = tts?.stop()

    // ── Reverb ────────────────────────────────────────────────────────────────
    private fun initReverb() {
        try {
            reverb = EnvironmentalReverb(0, 0)
            reverb?.enabled = true
        } catch (e: Exception) {
            Log.w(TAG, "Reverb not available: ${e.message}")
        }
    }

    fun setEnvironment(env: Int) {
        currentEnvironment = env
        reverb?.apply {
            when (env) {
                ENV_OUTDOOR -> {
                    roomLevel = -1000
                    decayTime = 1500
                    reverbLevel = -2602
                }
                ENV_INDOOR -> {
                    roomLevel = -1000
                    decayTime = 2500
                    reverbLevel = -1000
                }
                ENV_CAVE -> {
                    roomLevel = -1000
                    decayTime = 4000
                    reverbLevel = -500
                }
                ENV_CORRIDOR -> {
                    roomLevel = -1000
                    decayTime = 1800
                    reverbLevel = -500
                }
                ENV_ARENA -> {
                    roomLevel = -1000
                    decayTime = 3800
                    reverbLevel = -1000
                }
            }
        }
    }

    // ── Sound Loading ─────────────────────────────────────────────────────────
    private fun preloadMenuSounds() {
        scope.launch {
            val menuSounds = listOf(
                "sounds/menu/gesture_begin.ogg",
                "sounds/menu/gesture_end.ogg",
                "sounds/menu/click.ogg",
                "sounds/menu/long_clicked.ogg",
                "sounds/menu/scroll_down.ogg",
                "sounds/menu/KeyboardUp.ogg",
                "sounds/menu/KeyboardDown.ogg",
                "sounds/menu/window_state.ogg",
                "sounds/menu/dialog.ogg",
                "sounds/menu/start.ogg",
                "sounds/menu/Start.mp3",
                "sounds/menu/finalize.ogg",
                "sounds/menu/cancel.ogg",
                "sounds/menu/exit.mp3",
                "sounds/menu/button.wav",
                "sounds/menu/listitem.wav",
                "sounds/menu/checkbox.wav",
                "sounds/menu/checkbox_checked.wav",
                "sounds/menu/combobox.wav",
                "sounds/menu/link.wav",
                "sounds/menu/caret.wav",
                "sounds/menu/focus0.ogg",
                "sounds/menu/focus2.ogg",
                "sounds/menu/enfoque 1.mp3",
                "sounds/menu/enfoque 2.ogg",
                "sounds/menu/enfoque 3.ogg",
                "sounds/menu/last.wav",
                "sounds/menu/notext.wav",
                "sounds/menu/listening.ogg",
                "sounds/menu/pause.ogg",
                "sounds/menu/ReceivedMessage.ogg",
                "sounds/menu/SiriAutoSend_Haptic.ogg",
                "sounds/menu/ScreenCapture.ogg",
                "sounds/menu/cargador conectado.mp3",
                "sounds/menu/cancel.m4a"
            )
            menuSounds.forEach { path -> loadSound(path) }

            // Weapon, footstep and hit sounds. Real files in assets/sounds/... are used when
            // present; otherwise FallbackSynth generates a stand-in so the game is never silent.
            val gameSounds = LinkedHashSet<String>()
            WeaponRegistry.ALL_WEAPONS.forEach {
                gameSounds.add(it.fireSoundAsset); gameSounds.add(it.reloadSoundAsset)
                gameSounds.add(it.emptySoundAsset); gameSounds.add(it.equipSoundAsset)
            }
            gameSounds.addAll(listOf(
                "sounds/ambient/footstep.ogg", "sounds/ambient/footstep_crouch.ogg",
                "sounds/ambient/footstep_enemy.ogg", "sounds/weapons/enemy_hit.ogg",
                "sounds/weapons/enemy_death.ogg", "sounds/weapons/ak47_fire.ogg",
                "sounds/weapons/knife_swing.ogg", "sounds/weapons/pistol_fire.ogg"
            ))
            gameSounds.forEach { path -> loadSound(path) }
        }
    }

    @Synchronized
    fun loadSound(assetPath: String): Int {
        loadedSounds[assetPath]?.let { return it }
        // 1) the real asset file, if the project contains it
        try {
            context.assets.openFd(assetPath).use { afd ->
                val soundId = soundPool.load(afd, 1)
                loadedSounds[assetPath] = soundId
                return soundId
            }
        } catch (_: Exception) {
            // fall through to the synthesized stand-in
        }
        // 2) a synthesized stand-in generated from the file name
        return try {
            val dir = File(context.cacheDir, "synth").apply { mkdirs() }
            val f = File(dir, "s${assetPath.hashCode().toUInt()}.wav")
            if (!f.exists() || f.length() == 0L) f.writeBytes(FallbackSynth.wavFor(assetPath))
            val soundId = soundPool.load(f.absolutePath, 1)
            loadedSounds[assetPath] = soundId
            soundId
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load sound: $assetPath — ${e.message}")
            -1
        }
    }

    // ── 3D Spatial Playback ───────────────────────────────────────────────────
    /**
     * Play a sound in 3D space at world coordinates (x, y, z).
     * Automatically calculates left/right pan and volume based on
     * listener position and facing angle — exactly like BGT's sound objects.
     */
    fun playSound3D(
        assetPath: String,
        x: Float,
        y: Float,
        z: Float = 0f,
        loop: Boolean = false,
        pitchMultiplier: Float = 1f
    ): Int {
        val soundId = loadedSounds[assetPath] ?: loadSound(assetPath)
        if (soundId < 0 || !readySounds.contains(soundId)) return -1

        val (leftVol, rightVol) = calculate3DVolumes(x, y, z)
        val rate = pitchMultiplier.coerceIn(0.5f, 2.0f)
        val loopFlag = if (loop) -1 else 0

        val streamId = soundPool.play(soundId, leftVol, rightVol, 1, loopFlag, rate)
        if (streamId > 0) {
            activeSounds[streamId] = SoundInstance(streamId, soundId, x, y, z, assetPath, loop)
        }
        return streamId
    }

    /**
     * Play a 2D UI sound (no 3D positioning, full volume both channels).
     */
    fun playUI(assetPath: String, volume: Float = 1f): Int {
        val soundId = loadedSounds[assetPath] ?: loadSound(assetPath)
        if (soundId < 0 || !readySounds.contains(soundId)) return -1
        return soundPool.play(soundId, volume, volume, 2, 0, 1f)
    }

    /**
     * Update a looping 3D sound's position (for moving entities).
     */
    fun updateSoundPosition(streamId: Int, x: Float, y: Float, z: Float = 0f) {
        val instance = activeSounds[streamId] ?: return
        instance.x = x; instance.y = y; instance.z = z
        val (lv, rv) = calculate3DVolumes(x, y, z)
        soundPool.setVolume(streamId, lv, rv)
    }

    fun stopSound(streamId: Int) {
        soundPool.stop(streamId)
        activeSounds.remove(streamId)
    }

    fun stopAllSounds() {
        activeSounds.keys.forEach { soundPool.stop(it) }
        activeSounds.clear()
    }

    fun pauseAll() = soundPool.autoPause()
    fun resumeAll() = soundPool.autoResume()

    // ── Volume Calculation ────────────────────────────────────────────────────
    /**
     * BGT-style 3D audio math:
     * 1. Calculate distance from listener to sound source.
     * 2. Apply inverse-distance rolloff for volume.
     * 3. Calculate angle from listener facing direction to sound source.
     * 4. Convert angle to left/right stereo pan.
     */
    private fun calculate3DVolumes(sx: Float, sy: Float, sz: Float): Pair<Float, Float> {
        val dx = sx - listenerX
        val dy = sy - listenerY
        val dz = sz - listenerZ

        val distance = sqrt(dx * dx + dy * dy + dz * dz)

        // Distance-based volume (OpenAL inverse distance model)
        val volume = if (distance <= REF_DISTANCE) {
            1f
        } else if (distance >= MAX_DISTANCE) {
            0f
        } else {
            (REF_DISTANCE / (REF_DISTANCE + ROLLOFF_FACTOR * (distance - REF_DISTANCE)))
                .coerceIn(0f, 1f)
        }

        // Horizontal angle from listener to sound (2D top-down)
        val angleToSound = Math.toDegrees(atan2(dx.toDouble(), dy.toDouble())).toFloat()
        val relativeAngle = ((angleToSound - listenerAngle + 360) % 360)

        // Convert relative angle to stereo pan [-1, 1]
        val panRad = Math.toRadians(relativeAngle.toDouble())
        val pan = sin(panRad).toFloat()  // -1=full left, 0=center, +1=full right

        // Height cue: elevation slightly lowers pitch (handled separately)
        // Elevation factor for volume modification
        val elevationFactor = 1f - (abs(dz) / MAX_DISTANCE * 0.3f).coerceIn(0f, 0.3f)
        val finalVolume = (volume * elevationFactor).coerceIn(0f, 1f)

        val leftVol  = (finalVolume * (1f - pan.coerceIn(0f, 1f))).coerceIn(0f, 1f)
        val rightVol = (finalVolume * (1f + pan.coerceIn(-1f, 0f))).coerceIn(0f, 1f)

        return Pair(leftVol, rightVol)
    }

    // ── Convenience — Gesture Sound Shortcuts ─────────────────────────────────
    fun playGestureBegin()   = playUI("sounds/menu/gesture_begin.ogg")
    fun playGestureEnd()     = playUI("sounds/menu/gesture_end.ogg")
    fun playClick()          = playUI("sounds/menu/click.ogg")
    fun playLongClick()      = playUI("sounds/menu/long_clicked.ogg")
    fun playScrollDown()     = playUI("sounds/menu/scroll_down.ogg")
    fun playScrollUp()       = playUI("sounds/menu/KeyboardUp.ogg")
    fun playMoveBack()       = playUI("sounds/menu/KeyboardDown.ogg")
    fun playWindowOpen()     = playUI("sounds/menu/window_state.ogg")
    fun playDialog()         = playUI("sounds/menu/dialog.ogg")
    fun playGameStart()      = playUI("sounds/menu/start.ogg")
    fun playAppStart()       = playUI("sounds/menu/Start.mp3")
    fun playFinalize()       = playUI("sounds/menu/finalize.ogg")
    fun playCancel()         = playUI("sounds/menu/cancel.ogg")
    fun playExit()           = playUI("sounds/menu/exit.mp3")
    fun playButton()         = playUI("sounds/menu/button.wav")
    fun playListItem()       = playUI("sounds/menu/listitem.wav")
    fun playFocus()          = playUI("sounds/menu/focus0.ogg")
    fun playFocusAlt()       = playUI("sounds/menu/focus2.ogg")
    fun playPause()          = playUI("sounds/menu/pause.ogg")
    fun playMessageReceived()= playUI("sounds/menu/ReceivedMessage.ogg")
    fun playMessageSent()    = playUI("sounds/menu/SiriAutoSend_Haptic.ogg")
    fun playKillConfirmed()  = playUI("sounds/menu/ScreenCapture.ogg")
    fun playListening()      = playUI("sounds/menu/listening.ogg")
    fun playCheckbox()       = playUI("sounds/menu/checkbox.wav")
    fun playCheckboxOn()     = playUI("sounds/menu/checkbox_checked.wav")
    fun playLast()           = playUI("sounds/menu/last.wav")
    fun playNoText()         = playUI("sounds/menu/notext.wav")
    fun playCombobox()       = playUI("sounds/menu/combobox.wav")
    fun playLink()           = playUI("sounds/menu/link.wav")
    fun playCaret()          = playUI("sounds/menu/caret.wav")
    fun playFocusRing1()     = playUI("sounds/menu/enfoque 1.mp3")
    fun playFocusRing2()     = playUI("sounds/menu/enfoque 2.ogg")
    fun playFocusRing3()     = playUI("sounds/menu/enfoque 3.ogg")
    fun playConnected()      = playUI("sounds/menu/cargador conectado.mp3")
    fun playCancelSoft()     = playUI("sounds/menu/cancel.m4a")

    fun playFocusRing(i: Int) = when (i % 3) { 0 -> playFocusRing1(); 1 -> playFocusRing2(); else -> playFocusRing3() }

    /** A different focus sound for each main-menu position, so you can tell where you are by ear. */
    fun playMenuFocus(index: Int) = when (index % 8) {
        0 -> playButton()
        1 -> playLink()
        2 -> playCombobox()
        3 -> playCaret()
        4 -> playListItem()
        5 -> playCheckbox()
        6 -> playFocus()
        else -> playFocusAlt()
    }

    // ── Cleanup ───────────────────────────────────────────────────────────────
    fun release() {
        scope.cancel()
        soundPool.release()
        reverb?.release()
        tts?.stop()
        tts?.shutdown()
        instance = null
    }

    // ── Data class ────────────────────────────────────────────────────────────
    data class SoundInstance(
        val streamId: Int,
        val soundId: Int,
        var x: Float,
        var y: Float,
        var z: Float,
        val assetPath: String,
        val looping: Boolean
    )
}
