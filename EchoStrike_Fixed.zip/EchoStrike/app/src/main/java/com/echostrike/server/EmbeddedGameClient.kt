package com.echostrike.server

import android.content.Context
import android.util.Log
import com.echostrike.security.APKValidator
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.*
import java.net.*

/**
 * EmbeddedGameClient — connects to an EmbeddedGameServer.
 * Handles LAN auto-discovery, handshake, TCP events, UDP positions.
 */
class EmbeddedGameClient(private val context: Context) {

    companion object {
        private const val TAG = "EchoClient"
        const val CONNECT_TIMEOUT = 5000
    }

    private var tcp: Socket?      = null
    private var udp: DatagramSocket? = null
    private var writer: PrintWriter? = null
    private var reader: BufferedReader? = null
    private var scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    @Volatile private var serverAddr: InetAddress? = null

    /** disconnect() cancels the scope; create a fresh one so the client can connect again. */
    private fun ensureScope() {
        if (!scope.isActive) scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    }

    var myId: String? = null
    var serverHost: String? = null

    // ── callbacks (set before calling connect) ────────────────────────────
    var onConnected:    ((String) -> Unit)?                         = null
    var onRejected:     ((String) -> Unit)?                         = null
    var onDisconnected: (() -> Unit)?                               = null
    var onWorldState:   ((List<RemotePlayer>) -> Unit)?             = null
    var onFired:        ((String, Float, Float, Float, String) -> Unit)? = null
    var onKillEvent:    ((String, String, String, String) -> Unit)? = null
    var onYouHit:       ((Int, Int) -> Unit)?                       = null
    var onHitConfirmed: ((String, Int) -> Unit)?                    = null
    var onRespawned:    ((Float, Float) -> Unit)?                   = null
    var onChat:         ((String, String, String) -> Unit)?         = null
    var onFriendReq:    ((String, String) -> Unit)?                 = null
    var onLeaderboard:  ((List<LeaderRow>) -> Unit)?                = null
    var onServerFound:  ((FoundServer) -> Unit)?                    = null

    // ── LAN discovery ─────────────────────────────────────────────────────
    fun discover(timeoutMs: Long = 5000) {
        ensureScope()
        scope.launch {
            val seen = mutableSetOf<String>()
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket(null as SocketAddress?).apply {
                    reuseAddress = true; broadcast = true; soTimeout = timeoutMs.toInt()
                    bind(InetSocketAddress(EmbeddedGameServer.DISC_PORT))
                }
                val buf = ByteArray(1024)
                val deadline = System.currentTimeMillis() + timeoutMs
                while (System.currentTimeMillis() < deadline) {
                    val pkt = DatagramPacket(buf, buf.size)
                    try { sock.receive(pkt) } catch (_: SocketTimeoutException) { break }
                    val j = JSONObject(String(pkt.data, 0, pkt.length))
                    if (j.optString("magic") != EmbeddedGameServer.PROTOCOL_MAGIC) continue
                    if (j.optInt("ver")   != EmbeddedGameServer.PROTOCOL_VER)   continue
                    val key = "${j.optString("ip")}:${j.optInt("port")}"
                    if (seen.add(key)) {
                        val s = FoundServer(j.optString("ip"), j.optInt("port"),
                            j.optInt("players"), j.optInt("max"))
                        withContext(Dispatchers.Main) { onServerFound?.invoke(s) }
                    }
                }
            } catch (e: Exception) { Log.d(TAG, "Discovery: ${e.message}") }
            finally { sock?.close() }
        }
    }

    // ── connect ───────────────────────────────────────────────────────────
    fun connect(host: String, port: Int = EmbeddedGameServer.TCP_PORT,
                displayName: String, room: String = "default", authToken: String? = null,
                user: String? = null, pass: String? = null, register: Boolean = false) {
        // drop any previous connection first, then start with a fresh scope
        try { udp?.close(); tcp?.close() } catch (_: Exception) {}
        ensureScope()
        scope.launch {
            try {
                val addr = InetAddress.getByName(host)
                val sock = Socket().apply {
                    connect(InetSocketAddress(addr, port), CONNECT_TIMEOUT)
                }
                tcp = sock; serverHost = host; serverAddr = addr
                writer = PrintWriter(BufferedWriter(OutputStreamWriter(sock.getOutputStream())), true)
                reader = BufferedReader(InputStreamReader(sock.getInputStream()))

                // handshake
                val token = APKValidator.computeToken(context)
                writer!!.println(JSONObject().apply {
                    put("magic", EmbeddedGameServer.PROTOCOL_MAGIC)
                    put("ver",   EmbeddedGameServer.PROTOCOL_VER)
                    put("token", token)
                    if (!authToken.isNullOrBlank()) put("authToken", authToken)
                    if (!user.isNullOrBlank()) { put("user", user); put("pass", pass ?: ""); if (register) put("register", true) }
                    put("name",  displayName.take(20))
                    put("room",  room)
                })

                val resp = JSONObject(reader!!.readLine() ?: throw IOException("No response"))
                when (resp.optString("type")) {
                    "welcome" -> {
                        myId = resp.optString("id")
                        val u = DatagramSocket()
                        udp = u
                        withContext(Dispatchers.Main) { onConnected?.invoke(myId!!) }
                        // UDP snapshots (world_state) arrive on the UDP socket, not the TCP one
                        launch { udpReadLoop(u) }
                        // keep-alive: the server drops TCP clients that are silent for 30 s
                        launch { while (isActive) { delay(10_000); sendPing() } }
                        readLoop()
                    }
                    "rejected" -> {
                        sock.close()
                        withContext(Dispatchers.Main) { onRejected?.invoke(resp.optString("reason","Rejected")) }
                    }
                    else -> { sock.close(); withContext(Dispatchers.Main) { onRejected?.invoke("Unexpected response") } }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { onRejected?.invoke("Connection failed: ${e.message}") }
            }
        }
    }

    private suspend fun readLoop() = withContext(Dispatchers.IO) {
        try {
            while (true) {
                val line = reader?.readLine() ?: break
                dispatch(JSONObject(line))
            }
        } catch (e: Exception) { Log.d(TAG, "Read loop: ${e.message}") }
        finally { withContext(Dispatchers.Main) { onDisconnected?.invoke() } }
    }

    private suspend fun udpReadLoop(sock: DatagramSocket) = withContext(Dispatchers.IO) {
        val buf = ByteArray(8192)
        while (!sock.isClosed) {
            try {
                val pkt = DatagramPacket(buf, buf.size)
                sock.receive(pkt)
                dispatch(JSONObject(String(pkt.data, 0, pkt.length)))
            } catch (e: SocketException) { break }
            catch (e: Exception) { Log.d(TAG, "UDP read: ${e.message}") }
        }
    }

    private suspend fun dispatch(m: JSONObject) = withContext(Dispatchers.Main) {
        when (m.optString("type")) {
            "world_state" -> {
                val arr = m.optJSONArray("players") ?: return@withContext
                val list = (0 until arr.length()).map { i ->
                    val p = arr.getJSONObject(i)
                    RemotePlayer(p.getString("id"), p.getDouble("x").toFloat(),
                        p.getDouble("y").toFloat(), p.getDouble("a").toFloat(), p.getInt("hp"))
                }
                onWorldState?.invoke(list)
            }
            "player_fired"   -> onFired?.invoke(m.getString("id"),
                m.getDouble("x").toFloat(), m.getDouble("y").toFloat(),
                m.getDouble("a").toFloat(), m.optString("weapon","pistol"))
            "kill_event"     -> onKillEvent?.invoke(m.getString("killerId"), m.getString("killerName"),
                m.getString("victimId"), m.getString("victimName"))
            "you_hit"        -> onYouHit?.invoke(m.getInt("damage"), m.getInt("health"))
            "hit_confirmed"  -> onHitConfirmed?.invoke(m.getString("victimId"), m.getInt("damage"))
            "respawned"      -> onRespawned?.invoke(m.getDouble("x").toFloat(), m.getDouble("y").toFloat())
            "chat"           -> onChat?.invoke(m.getString("id"), m.getString("name"), m.getString("text"))
            "friend_request" -> onFriendReq?.invoke(m.getString("fromId"), m.getString("fromName"))
            "leaderboard"    -> {
                val arr = m.optJSONArray("entries") ?: return@withContext
                onLeaderboard?.invoke((0 until arr.length()).map { i ->
                    val e = arr.getJSONObject(i); LeaderRow(e.getString("name"), e.getInt("score"))
                })
            }
        }
    }

    // ── send helpers ──────────────────────────────────────────────────────
    fun sendPositionFast(x: Float, y: Float, angle: Float) {
        val addr = serverAddr ?: return; val id = myId ?: return
        scope.launch(Dispatchers.IO) {
            try {
                val data = JSONObject().apply {
                    put("pid",id); put("x",x.toDouble()); put("y",y.toDouble()); put("a",angle.toDouble())
                }.toString().toByteArray()
                udp?.send(DatagramPacket(data, data.size, addr, EmbeddedGameServer.UDP_PORT))
            } catch (_: Exception) {}
        }
    }

    fun sendFire(x: Float, y: Float, angle: Float, weapon: String) = send(JSONObject().apply {
        put("type","fire"); put("x",x); put("y",y); put("a",angle); put("weapon",weapon)
    })
    fun sendChat(text: String) = send(JSONObject().apply { put("type","chat"); put("text",text) })
    fun sendPing() = send(JSONObject().apply { put("type","ping"); put("ts",System.currentTimeMillis()) })
    fun requestLeaderboard() = send(JSONObject().apply { put("type","leaderboard") })
    fun sendFriendRequest(targetId: String) = send(JSONObject().apply {
        put("type","friend_request"); put("targetId",targetId)
    })

    private fun send(j: JSONObject) {
        scope.launch(Dispatchers.IO) {
            try { writer?.println(j.toString()) } catch (e: Exception) { Log.w(TAG, "Send: ${e.message}") }
        }
    }

    fun disconnect() {
        scope.cancel()
        try { udp?.close() } catch (_: Exception) {}
        try { tcp?.close() } catch (_: Exception) {}
        myId = null
    }
}

data class RemotePlayer(val id: String, val x: Float, val y: Float, val angle: Float, val health: Int)
data class FoundServer(val ip: String, val port: Int, val players: Int, val maxPlayers: Int)
data class LeaderRow(val name: String, val score: Int)
