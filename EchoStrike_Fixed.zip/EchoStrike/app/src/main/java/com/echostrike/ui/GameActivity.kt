package com.echostrike.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.echostrike.game.BotBrain
import com.echostrike.game.GameMode
import com.echostrike.game.SwipeTracker
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.echostrike.audio.EchoAudioEngine
import com.echostrike.game.EchoGestureHandler
import com.echostrike.game.Enemy
import com.echostrike.game.GameEngine
import com.echostrike.network.NetworkManager
import com.echostrike.server.RemotePlayer
import com.echostrike.weapons.WeaponRegistry

/**
 * GameActivity — the in-game screen.
 *
 * It uses the SAME NetworkManager (and therefore the same server connection) that the
 * main menu created. All gameplay events (move, fire, kill, chat) go through it.
 *
 * Gestures (EchoGestureHandler):
 *   Swipe up/down      → move forward / backward
 *   Swipe left/right   → turn
 *   Double tap         → fire
 *   Long press         → status (health, weapon, facing, nearest player)
 *   2-finger swipe     → next / previous weapon (left/right), volume (up/down)
 *   3-finger tap       → pause menu
 *   Pinch              → crouch
 *   Shake              → melee
 *   Back button        → press twice to leave the game
 */
class GameActivity : AppCompatActivity() {

    private lateinit var audio: EchoAudioEngine
    private lateinit var engine: GameEngine
    private lateinit var network: NetworkManager
    private lateinit var gestures: EchoGestureHandler

    private var isHost = false
    private var offline = false
    private val phrases = listOf(
        "Hello everyone", "Good game", "Nice shot", "Enemy behind me", "Cover me",
        "Follow me", "Need help", "Thank you", "Sorry", "Let's go", "Good luck"
    )
    private var phraseIndex = 0
    private val chatLog = ArrayList<String>()
    private var recognizer: SpeechRecognizer? = null
    private var paused = false
    private var backArmedUntil = 0L
    private var leaving = false

    private val ui = Handler(Looper.getMainLooper())
    private val lastFootstep = HashMap<String, Long>()
    private val lastPos = HashMap<String, Pair<Float, Float>>()

    // Send position to the server every 100 ms
    private val positionRunnable = object : Runnable {
        override fun run() {
            if (!paused) network.sendMove(engine.playerX, engine.playerY, engine.playerAngle)
            ui.postDelayed(this, 100)
        }
    }

    private val myId: String? get() = network.client.myId

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        isHost = intent.getBooleanExtra("isHost", false)
        offline = intent.getBooleanExtra("offline", false)

        val root = View(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        setContentView(root)

        audio = EchoAudioEngine(this)
        engine = GameEngine(audio)
        engine.multiplayer = !offline
        network = NetworkManager.shared(this)
        audio.listenerX = engine.playerX
        audio.listenerY = engine.playerY
        audio.listenerAngle = engine.playerAngle

        if (!offline) wireNetwork()
        wireGestures()

        root.setOnTouchListener { _, ev: MotionEvent -> gestures.onTouchEvent(ev); true }

        // The speech engine needs a moment to start
        if (offline) {
            engine.onDeath = {
                ui.post {
                    ui.postDelayed({
                        if (!leaving) {
                            engine.respawnAt(0f, 0f)
                            audio.speak("Respawned. Health full.")
                        }
                    }, 3000)
                }
            }
            ui.postDelayed({
                val bots = intent.getIntExtra("bots", 3)
                val diff = BotBrain.Difficulty.fromLevel(intent.getIntExtra("difficulty", 2))
                engine.startGame(GameMode.DEATHMATCH, bots, diff)
            }, 1800)
        } else {
            ui.postDelayed({
                audio.playConnected()
                audio.speak(if (isHost) "Game started. You are hosting. Waiting for players. Long press for status. Four finger swipe up sends chat."
                            else "Joined game. Good luck. Long press for status. Four finger swipe up sends chat.")
            }, 1200)
            ui.post(positionRunnable)
        }
    }

    // ── Server events → game and audio ───────────────────────────────────
    private fun wireNetwork() {
        network.onDisconnect = {
            if (!leaving) {
                audio.speak("Disconnected from server.")
                leaveGame(announce = false)
            }
        }
        network.client.apply {
            onWorldState = { players -> updateRemotePlayers(players) }
            onFired = { id, x, y, _, weaponId ->
                if (id != myId) {
                    val asset = WeaponRegistry.getById(weaponId)?.fireSoundAsset ?: "sounds/weapons/pistol_fire.ogg"
                    audio.playSound3D(asset, x, y)
                }
            }
            onYouHit = { damage, remaining ->
                engine.playerHealth = remaining
                audio.playUI("sounds/weapons/enemy_hit.ogg")
                audio.speak("Hit! Took $damage damage. Health $remaining.")
            }
            onHitConfirmed = { _, damage ->
                audio.playKillConfirmed()
                audio.speak("Hit! $damage damage.", interrupt = false)
            }
            onKillEvent = { killerId, killerName, victimId, victimName ->
                audio.playUI("sounds/weapons/enemy_death.ogg")
                when {
                    victimId == myId -> audio.speak("You were killed by $killerName!")
                    killerId == myId -> audio.speak("You killed $victimName!")
                    else -> audio.speak("$killerName killed $victimName.", interrupt = false)
                }
            }
            onRespawned = { x, y ->
                engine.respawnAt(x, y)
                audio.speak("Respawned. Health full.")
            }
            onChat = { _, name, text ->
                chatLog.add("$name: $text"); if (chatLog.size > 20) chatLog.removeAt(0)
                audio.playMessageReceived()
                audio.speak("$name says: $text", interrupt = false)
            }
        }
    }

    private fun updateRemotePlayers(players: List<RemotePlayer>) {
        val me = myId
        val others = players.filter { it.id != me }
        engine.enemies.clear()
        val now = System.currentTimeMillis()
        for (p in others) {
            engine.enemies.add(
                Enemy(id = p.id, x = p.x, y = p.y, health = p.health, isAlive = p.health > 0,
                    angle = p.angle, aggroRange = 0f, isBot = false, name = p.id)
            )
            // positional footsteps for players nearby (at most one step sound per 450 ms each)
            val dx = p.x - engine.playerX
            val dy = p.y - engine.playerY
            val prev = lastPos[p.id]
            lastPos[p.id] = Pair(p.x, p.y)
            val moved = prev != null && (Math.abs(prev.first - p.x) + Math.abs(prev.second - p.y)) > 0.05f
            if (moved && p.health > 0 && dx * dx + dy * dy < 30f * 30f && now - (lastFootstep[p.id] ?: 0L) > 450) {
                lastFootstep[p.id] = now
                audio.playSound3D("sounds/ambient/footstep_enemy.ogg", p.x, p.y)
            }
        }
    }

    // ── Gestures ─────────────────────────────────────────────────────────
    private fun wireGestures() {
        gestures = EchoGestureHandler(this, audio)
        gestures.mode = EchoGestureHandler.GestureMode.GAME
        gestures.gameEngine = engine
        gestures.onPauseMenu = { togglePause() }
        gestures.onMenuSelect = { if (paused) togglePause() }
        gestures.onMenuBack = { if (paused) leaveGame(announce = true) }

        if (!offline) {
            engine.onShotFired = { w -> network.sendFire(engine.playerX, engine.playerY, engine.playerAngle, w.id) }
            engine.onMeleeSwing = { network.sendFire(engine.playerX, engine.playerY, engine.playerAngle, "knife") }
        }
        gestures.onChatSwipe = { dir, fingers -> handleChatSwipe(dir, fingers) }
    }

    // ── Chat ─────────────────────────────────────────────────────────────
    //  4 fingers swipe left/right: pick a quick phrase   4 fingers swipe up: send it
    //  4 fingers swipe down: speak a message (voice)      3 fingers swipe left: read recent chat
    private fun handleChatSwipe(dir: SwipeTracker.Direction, fingers: Int): Boolean {
        if (paused) return false
        if (fingers == 3 && dir == SwipeTracker.Direction.LEFT) {
            if (offline) audio.speak("Chat is only available online.")
            else if (chatLog.isEmpty()) { audio.playNoText(); audio.speak("No messages yet.") }
            else audio.speak(chatLog.takeLast(5).joinToString(". "))
            return true
        }
        if (fingers < 4) return false
        if (offline) { audio.speak("Chat is only available online."); return true }
        when (dir) {
            SwipeTracker.Direction.RIGHT -> {
                phraseIndex = (phraseIndex + 1) % phrases.size
                audio.playMenuFocus(phraseIndex); audio.speak(phrases[phraseIndex])
            }
            SwipeTracker.Direction.LEFT -> {
                phraseIndex = (phraseIndex - 1 + phrases.size) % phrases.size
                audio.playMenuFocus(phraseIndex); audio.speak(phrases[phraseIndex])
            }
            SwipeTracker.Direction.UP -> sendChatText(phrases[phraseIndex])
            SwipeTracker.Direction.DOWN -> startVoiceChat()
        }
        return true
    }

    private fun sendChatText(text: String) {
        network.sendChat(text)
        audio.playMessageSent()
        audio.speak("Sent: $text", interrupt = false)
    }

    private fun startVoiceChat() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { audio.speak("Voice input is not available on this phone."); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 77)
            audio.speak("Allow the microphone, then try again.")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) { audio.playNoText(); audio.speak("I did not hear anything.") }
                else sendChatText(text.take(120))
            }
            override fun onError(error: Int) { audio.playNoText(); audio.speak("Voice chat did not work. Try again.") }
            override fun onReadyForSpeech(params: Bundle?) { audio.playListening() }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        })
    }

    private fun togglePause() {
        paused = !paused
        gestures.mode = if (paused) EchoGestureHandler.GestureMode.MENU else EchoGestureHandler.GestureMode.GAME
        audio.playPause()
        audio.speak(
            if (paused) "Paused. Tap to resume. Swipe left or right to leave the game."
            else "Resumed."
        )
    }

    private fun leaveGame(announce: Boolean) {
        if (leaving) return
        leaving = true
        if (announce) audio.playExit()
        if (!offline) network.shutdown()
        finish()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        val now = System.currentTimeMillis()
        if (now < backArmedUntil) {
            leaveGame(announce = true)
        } else {
            backArmedUntil = now + 3000
            audio.speak("Press back again to leave the game.")
        }
    }

    override fun onResume() {
        super.onResume()
        gestures.registerSensors()
    }

    override fun onPause() {
        super.onPause()
        gestures.unregisterSensors()
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        network.onDisconnect = null
        network.client.apply {
            onWorldState = null; onFired = null; onYouHit = null; onHitConfirmed = null
            onKillEvent = null; onRespawned = null; onChat = null
        }
        recognizer?.destroy()
        engine.endGame()
        // let the exit sound finish before the audio engine is released
        val a = audio
        Handler(Looper.getMainLooper()).postDelayed({ a.release() }, 1500)
    }
}
