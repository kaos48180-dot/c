package com.echostrike.audio

import java.io.ByteArrayOutputStream
import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * FallbackSynth — generates simple game sounds in code.
 *
 * The project ships menu sounds but no weapon / footstep / hit sounds. Whenever an
 * asset file is missing, EchoAudioEngine asks this class for a synthesized WAV based on
 * the asset's file name (e.g. "sounds/weapons/deagle_fire.ogg" → a deep gunshot).
 * If you later add a real file with the same name, the real file is used instead.
 */
object FallbackSynth {
    private const val RATE = 22050

    fun wavFor(assetPath: String): ByteArray {
        val name = assetPath.substringAfterLast('/').substringBeforeLast('.').lowercase()
        val rnd = Random(name.hashCode().toLong())
        val pcm: ShortArray = when {
            name.contains("footstep") -> footstep(rnd, quiet = name.contains("crouch"), enemy = name.contains("enemy"))
            name.contains("enemy_hit") -> hit(rnd)
            name.contains("enemy_death") -> death()
            name.contains("empty") -> click(rnd, 1)
            name.contains("reload") -> click(rnd, 3)
            name.contains("equip") -> equip(rnd)
            name.contains("knife") || name.contains("swing") -> swish(rnd)
            name.contains("grenade") || name.contains("rocket") || name.contains("rpg") ||
                name.contains("stinger") || name.contains("explo") -> boom(rnd)
            name.contains("fire") || name.contains("shot") || name.contains("suppressed") ||
                name.contains("launch") -> gunshot(rnd, name)
            else -> beep()
        }
        return toWav(pcm)
    }

    private fun gunshot(rnd: Random, name: String): ShortArray {
        val heavy = listOf("deagle", "sniper", "awp", "barrett", "sv98", "rifle_heavy", "shotgun", "lmg", "minigun")
            .any { name.contains(it) }
        val soft = name.contains("suppressed") || name.contains("pistol") || name.contains("smg")
        val seconds = if (heavy) 0.55 else if (soft) 0.22 else 0.35
        val n = (RATE * seconds).toInt()
        val out = ShortArray(n)
        val thumpHz = (if (heavy) 55.0 else 90.0) + rnd.nextInt(40)
        val decay = if (heavy) 7.0 else if (soft) 20.0 else 12.0
        var lp = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            val env = exp(-decay * t)
            val noise = rnd.nextDouble() * 2 - 1
            lp += (noise - lp) * (if (soft) 0.25 else 0.5)
            val thump = sin(2 * PI * thumpHz * t) * exp(-18.0 * t)
            val crack = if (t < 0.012) noise else 0.0
            out[i] = s((lp * env * 0.7 + thump * 0.6 + crack * 0.4) * 0.9)
        }
        return out
    }

    private fun boom(rnd: Random): ShortArray {
        val n = (RATE * 0.9).toInt()
        val out = ShortArray(n)
        var lp = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            lp += ((rnd.nextDouble() * 2 - 1) - lp) * 0.12
            out[i] = s((lp * exp(-4.0 * t) * 1.4 + sin(2 * PI * 45.0 * t) * exp(-5.0 * t) * 0.6) * 0.9)
        }
        return out
    }

    private fun footstep(rnd: Random, quiet: Boolean, enemy: Boolean): ShortArray {
        val n = (RATE * 0.16).toInt()
        val out = ShortArray(n)
        val amp = if (quiet) 0.3 else if (enemy) 0.8 else 0.6
        val hz = if (enemy) 70.0 else 95.0
        var lp = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            lp += ((rnd.nextDouble() * 2 - 1) - lp) * 0.2
            out[i] = s((lp * 0.5 + sin(2 * PI * hz * t) * 0.8) * exp(-30.0 * t) * amp)
        }
        return out
    }

    private fun hit(rnd: Random): ShortArray {
        val n = (RATE * 0.12).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            out[i] = s((sin(2 * PI * 180.0 * t) * 0.7 + (rnd.nextDouble() * 2 - 1) * 0.3) * exp(-28.0 * t))
        }
        return out
    }

    private fun death(): ShortArray {
        val n = (RATE * 0.6).toInt()
        val out = ShortArray(n)
        var phase = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            phase += 2 * PI * (320.0 - 260.0 * t / 0.6) / RATE
            out[i] = s(sin(phase) * exp(-3.0 * t) * 0.7)
        }
        return out
    }

    private fun click(rnd: Random, count: Int): ShortArray {
        val gap = (RATE * 0.18).toInt()
        val out = ShortArray(gap * count + 400)
        for (c in 0 until count) {
            val start = c * gap
            for (i in 0 until 400) {
                val t = i.toDouble() / RATE
                out[start + i] = s(((rnd.nextDouble() * 2 - 1) * 0.6 + sin(2 * PI * 1800.0 * t) * 0.4) * exp(-220.0 * t))
            }
        }
        return out
    }

    private fun equip(rnd: Random): ShortArray {
        val n = (RATE * 0.25).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            val env = min(1.0, t * 60) * exp(-9.0 * t)
            out[i] = s(((rnd.nextDouble() * 2 - 1) * 0.35 + sin(2 * PI * 900.0 * t) * 0.25) * env)
        }
        return out
    }

    private fun swish(rnd: Random): ShortArray {
        val n = (RATE * 0.25).toInt()
        val out = ShortArray(n)
        var lp = 0.0
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            val k = 0.05 + 0.5 * (t / 0.25)
            lp += ((rnd.nextDouble() * 2 - 1) - lp) * k
            val env = sin(PI * t / 0.25)
            out[i] = s(lp * env * 0.9)
        }
        return out
    }

    private fun beep(): ShortArray {
        val n = (RATE * 0.12).toInt()
        val out = ShortArray(n)
        for (i in 0 until n) {
            val t = i.toDouble() / RATE
            out[i] = s(sin(2 * PI * 660.0 * t) * exp(-15.0 * t) * 0.6)
        }
        return out
    }

    private fun s(v: Double): Short = (v.coerceIn(-1.0, 1.0) * 32000).toInt().toShort()

    private fun toWav(pcm: ShortArray): ByteArray {
        val dataLen = pcm.size * 2
        val b = ByteArrayOutputStream(44 + dataLen)
        fun i32(v: Int) { b.write(v and 0xff); b.write((v shr 8) and 0xff); b.write((v shr 16) and 0xff); b.write((v shr 24) and 0xff) }
        fun i16(v: Int) { b.write(v and 0xff); b.write((v shr 8) and 0xff) }
        b.write("RIFF".toByteArray()); i32(36 + dataLen); b.write("WAVE".toByteArray())
        b.write("fmt ".toByteArray()); i32(16); i16(1); i16(1); i32(RATE); i32(RATE * 2); i16(2); i16(16)
        b.write("data".toByteArray()); i32(dataLen)
        for (v in pcm) i16(v.toInt())
        return b.toByteArray()
    }
}
