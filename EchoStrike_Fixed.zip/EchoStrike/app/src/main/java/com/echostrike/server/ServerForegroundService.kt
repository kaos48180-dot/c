package com.echostrike.server

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.echostrike.ui.MainActivity

/**
 * Keeps the embedded server alive when screen turns off.
 * Without this Android kills the process after ~1 minute.
 */
class ServerForegroundService : Service() {

    companion object {
        const val CHANNEL_ID  = "echo_server_channel"
        const val NOTIF_ID    = 1001
        const val ACTION_STOP = "com.echostrike.STOP_SERVER"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY
        }
        createChannel()
        val stopIntent = Intent(this, ServerForegroundService::class.java).apply { action = ACTION_STOP }
        val stopPi    = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE)
        val openPi    = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("EchoStrike Server Running")
            .setContentText("Friends can connect to your game")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_delete, "Stop Server", stopPi)
            .setOngoing(true)
            .build()

        startForeground(NOTIF_ID, notif)
        return START_STICKY
    }

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Game Server",
            NotificationManager.IMPORTANCE_LOW).apply {
            description = "Shows while EchoStrike is hosting a game"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
