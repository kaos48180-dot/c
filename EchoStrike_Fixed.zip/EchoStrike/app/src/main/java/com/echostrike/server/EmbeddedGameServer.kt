package com.echostrike.server

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import com.echostrike.security.APKValidator
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.hypot

/**
 * EmbeddedGameServer
 * ──────────────────
 * Runs INSIDE the APK. No external server. No internet required.
 * One player hosts, others connect by LAN auto-discovery or direct IP.
 *
 * Security: clients must present a token derived from the APK signing
 * certificate. A different APK = different token = rejected instantly.
 *
 * Ports:
 *   TCP 17550 — reliable game events (fire, kill, chat, handshake)
 *   UDP 17551 — fast position snapshots at 20 Hz
 *   UDP 17552 — LAN discovery broadcasts every 2 s
 */
class EmbeddedGameServer(private val context: Context) {

    companion object {
        private const val TAG = "EchoServer"
        const val TCP_PORT       = 17550
        const val UDP_PORT       = 17551
        const val DISC_PORT      = 17552
        const val MAX_PLAYERS    = 16
        const val TICK_MS        = 50L   // 20 Hz
        const val DISC_MS        = 2000L
        const val PROTOCOL_MAGIC = "ECHO2025"
        const val PROTOCOL_VER   = 2
    }

    // ── sockets ──────────────────────────────────────────────────────────
    private var tcpServer:   ServerSocket?   = null
    private var udpSocket:   DatagramSocket? = null
    private var discSocket:  DatagramSocket? = null

    private var scope   = CoroutineScope(Dispatchers.IO + SupervisorJob())
    val  players = ConcurrentHashMap<String, ServerPlayer>()
    private val rooms   = ConcurrentHashMap<String, ServerRoom>()
    private val nextId  = AtomicInteger(1)

    @Volatile var isRunning = false

    // derived once from THIS APK's signing cert
    private val apkToken: String by lazy { APKValidator.computeToken(context) }

    // ── host callbacks ────────────────────────────────────────────────────
    var onPlayerJoined:  ((String) -> Unit)?       = null
    var onPlayerLeft:    ((String) -> Unit)?        = null
    var onStatusUpdate:  ((ServerStatus) -> Unit)?  = null

    // ═════════════════════════════════════════════════════════════════════
    // START
    // ═════════════════════════════════════════════════════════════════════
    fun start(onError: ((String) -> Unit)? = null, onReady: (ip: String, port: Int) -> Unit) {
        if (isRunning) return
        isRunning = true
        // stop() cancels the scope; make a fresh one so hosting works a second time
        if (!scope.isActive) scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

        scope.launch {
            try {
                tcpServer  = ServerSocket().apply {
                    reuseAddress = true; bind(InetSocketAddress(TCP_PORT))
                }
                udpSocket  = DatagramSocket(null as SocketAddress?).apply {
                    reuseAddress = true; bind(InetSocketAddress(UDP_PORT))
                }
                discSocket = DatagramSocket(null as SocketAddress?).apply {
                    reuseAddress = true; broadcast = true; bind(InetSocketAddress(DISC_PORT))
                }

                val ip = localIP()
                Log.i(TAG, "Server started on $ip:$TCP_PORT")

                launch { tcpAcceptLoop() }
                launch { udpReceiveLoop() }
                launch { discoveryBroadcastLoop() }
                launch { tickLoop() }

                withContext(Dispatchers.Main) { onReady(ip, TCP_PORT) }
            } catch (e: Exception) {
                Log.e(TAG, "Server start failed: ${e.message}")
                isRunning = false
                try { tcpServer?.close(); udpSocket?.close(); discSocket?.close() } catch (_: Exception) {}
                withContext(Dispatchers.Main) { onError?.invoke(e.message ?: "could not open the game ports") }
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // STOP
    // ═════════════════════════════════════════════════════════════════════
    fun stop() {
        isRunning = false
        players.values.forEach { it.close() }
        players.clear(); rooms.clear()
        tcpServer?.close(); udpSocket?.close(); discSocket?.close()
        scope.cancel()
        Log.i(TAG, "Server stopped")
    }

    // ═════════════════════════════════════════════════════════════════════
    // TCP ACCEPT LOOP
    // ═════════════════════════════════════════════════════════════════════
    private suspend fun tcpAcceptLoop() = withContext(Dispatchers.IO) {
        while (isRunning) {
            try {
                val sock = tcpServer?.accept() ?: break
                launch { handleClient(sock) }
            } catch (_: SocketException) { break }
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // CLIENT HANDLER — handshake then message loop
    // ═════════════════════════════════════════════════════════════════════
    private suspend fun handleClient(sock: Socket) = withContext(Dispatchers.IO) {
        sock.soTimeout = 6000
        val reader = BufferedReader(InputStreamReader(sock.getInputStream()))
        val writer = PrintWriter(BufferedWriter(OutputStreamWriter(sock.getOutputStream())), true)

        var player: ServerPlayer? = null
        try {
            // ── handshake ────────────────────────────────────────────────
            val hello = JSONObject(reader.readLine() ?: return@withContext)

            if (hello.optString("magic") != PROTOCOL_MAGIC) {
                writer.println(reject("Bad magic — wrong app?")); sock.close(); return@withContext
            }
            if (hello.optInt("ver") != PROTOCOL_VER) {
                writer.println(reject("Version mismatch — update your game")); sock.close(); return@withContext
            }
            if (!APKValidator.validateToken(hello.optString("token"), apkToken)) {
                Log.w(TAG, "Rejected ${sock.inetAddress} — bad APK token")
                writer.println(reject("Access denied. Only genuine EchoStrike APKs can connect."))
                sock.close(); return@withContext
            }
            if (players.size >= MAX_PLAYERS) {
                writer.println(reject("Server full ($MAX_PLAYERS max)")); sock.close(); return@withContext
            }

            // ── accept ───────────────────────────────────────────────────
            val id      = "P${nextId.getAndIncrement()}"
            val name    = hello.optString("name", "Player").take(20)
            val roomId  = hello.optString("room", "default")
            sock.soTimeout = 30_000

            player = ServerPlayer(id, name, sock, writer, reader, roomId)
            players[id] = player
            rooms.getOrPut(roomId) { ServerRoom(roomId) }.addPlayer(id)

            writer.println(JSONObject().apply {
                put("type", "welcome")
                put("id", id); put("room", roomId)
                put("tickHz", 1000 / TICK_MS)
                put("serverIp", localIP())
            })

            broadcastRoom(roomId, JSONObject().apply {
                put("type", "player_joined"); put("id", id); put("name", name)
            }, exclude = id)

            withContext(Dispatchers.Main) { onPlayerJoined?.invoke(name) }
            Log.i(TAG, "Player joined: $name ($id) → room $roomId  [total: ${players.size}]")

            // ── message loop ─────────────────────────────────────────────
            sock.soTimeout = 30_000
            while (isRunning && !sock.isClosed) {
                val line = reader.readLine() ?: break
                handleMessage(player, line)
            }

        } catch (e: Exception) {
            Log.d(TAG, "Client disconnected: ${e.message}")
        } finally {
            player?.let { p ->
                players.remove(p.id)
                rooms[p.roomId]?.removePlayer(p.id)
                broadcastRoom(p.roomId, JSONObject().apply {
                    put("type", "player_left"); put("id", p.id); put("name", p.displayName)
                })
                withContext(Dispatchers.Main) { onPlayerLeft?.invoke(p.displayName) }
                Log.i(TAG, "Player left: ${p.displayName}  [total: ${players.size}]")
            }
            sock.close()
            updateStatus()
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // MESSAGE DISPATCH
    // ═════════════════════════════════════════════════════════════════════
    private fun handleMessage(player: ServerPlayer, raw: String) {
        val msg = try { JSONObject(raw) } catch (_: Exception) { return }
        when (msg.optString("type")) {

            "move" -> {
                player.x     = msg.optDouble("x", player.x.toDouble()).toFloat()
                player.y     = msg.optDouble("y", player.y.toDouble()).toFloat()
                player.angle = msg.optDouble("a", player.angle.toDouble()).toFloat()
            }

            "fire" -> {
                val weapon = msg.optString("weapon", "pistol")
                val fx = msg.optDouble("x").toFloat()
                val fy = msg.optDouble("y").toFloat()
                val fa = msg.optDouble("a").toFloat()

                val hit = serverRaycast(player, fa)
                broadcastRoom(player.roomId, JSONObject().apply {
                    put("type","player_fired"); put("id", player.id)
                    put("x",fx); put("y",fy); put("a",fa)
                    put("weapon",weapon); put("hit", hit != null)
                }, exclude = player.id)
                hit?.let { applyDamage(player, it, weapon) }
            }

            "chat" -> {
                val text = msg.optString("text","").take(200).trim()
                if (text.isNotEmpty()) {
                    broadcastRoom(player.roomId, JSONObject().apply {
                        put("type","chat"); put("id",player.id); put("name",player.displayName)
                        put("text",text); put("ts", System.currentTimeMillis())
                    })
                }
            }

            "ping" -> player.writer.println(
                JSONObject().put("type","pong").put("ts", msg.optLong("ts"))
            )

            "leaderboard" -> sendLeaderboard(player)

            "friend_request" -> {
                val target = players[msg.optString("targetId")] ?: return
                target.writer.println(JSONObject().apply {
                    put("type","friend_request"); put("fromId",player.id); put("fromName",player.displayName)
                })
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // SERVER-SIDE HIT DETECTION
    // ═════════════════════════════════════════════════════════════════════
    private fun serverRaycast(shooter: ServerPlayer, angleDeg: Float): ServerPlayer? {
        return players.values
            .filter { it.id != shooter.id && it.roomId == shooter.roomId && it.health > 0 }
            .filter { t ->
                val dist = hypot((t.x-shooter.x).toDouble(), (t.y-shooter.y).toDouble()).toFloat()
                if (dist > 150f) return@filter false
                val bearingDeg = Math.toDegrees(
                    Math.atan2((t.x-shooter.x).toDouble(), (t.y-shooter.y).toDouble())
                ).toFloat()
                Math.abs(((bearingDeg - angleDeg + 540) % 360) - 180) < 12f
            }
            .minByOrNull { hypot((it.x-shooter.x).toDouble(), (it.y-shooter.y).toDouble()) }
    }

    private fun applyDamage(shooter: ServerPlayer, victim: ServerPlayer, weapon: String) {
        val dmg = WEAPON_DAMAGE[weapon] ?: 35
        victim.health = (victim.health - dmg).coerceAtLeast(0)

        victim.writer.println(JSONObject().apply {
            put("type","you_hit"); put("fromId",shooter.id); put("fromName",shooter.displayName)
            put("damage",dmg); put("health",victim.health)
        })
        shooter.writer.println(JSONObject().apply {
            put("type","hit_confirmed"); put("victimId",victim.id); put("damage",dmg)
        })

        if (victim.health <= 0) handleKill(shooter, victim)
    }

    private fun handleKill(killer: ServerPlayer, victim: ServerPlayer) {
        killer.kills++; victim.deaths++
        val room = rooms[killer.roomId] ?: return
        room.scores[killer.id] = (room.scores[killer.id] ?: 0) + 100

        broadcastRoom(killer.roomId, JSONObject().apply {
            put("type","kill_event")
            put("killerId",killer.id); put("killerName",killer.displayName)
            put("victimId",victim.id); put("victimName",victim.displayName)
        })

        scope.launch {
            delay(3000)
            if (players.containsKey(victim.id)) {
                victim.health = 100
                victim.x = (Math.random() * 90 + 5).toFloat()
                victim.y = (Math.random() * 90 + 5).toFloat()
                victim.writer.println(JSONObject().apply {
                    put("type","respawned"); put("x",victim.x); put("y",victim.y)
                })
            }
        }
    }

    private fun sendLeaderboard(player: ServerPlayer) {
        val room = rooms[player.roomId] ?: return
        val arr = JSONArray()
        room.scores.entries.sortedByDescending { it.value }.take(10).forEach { (pid, score) ->
            arr.put(JSONObject().apply {
                put("name", players[pid]?.displayName ?: "Unknown"); put("score", score)
            })
        }
        player.writer.println(JSONObject().apply { put("type","leaderboard"); put("entries",arr) })
    }

    // ═════════════════════════════════════════════════════════════════════
    // UDP POSITION SNAPSHOTS (20 Hz tick)
    // ═════════════════════════════════════════════════════════════════════
    private suspend fun udpReceiveLoop() = withContext(Dispatchers.IO) {
        val buf = ByteArray(512)
        while (isRunning) {
            try {
                val pkt = DatagramPacket(buf, buf.size)
                udpSocket?.receive(pkt)
                val msg = JSONObject(String(pkt.data, 0, pkt.length))
                val p   = players[msg.optString("pid")] ?: continue
                p.x     = msg.optDouble("x").toFloat()
                p.y     = msg.optDouble("y").toFloat()
                p.angle = msg.optDouble("a").toFloat()
                p.udpAddr = pkt.address; p.udpPort = pkt.port
            } catch (_: Exception) {}
        }
    }

    private suspend fun tickLoop() = withContext(Dispatchers.IO) {
        while (isRunning) {
            delay(TICK_MS)
            rooms.values.forEach { room ->
                val inRoom = players.values.filter { it.roomId == room.id && it.health > 0 }
                if (inRoom.size < 2) return@forEach
                val arr = JSONArray()
                inRoom.forEach { p -> arr.put(JSONObject().apply {
                    put("id",p.id); put("x",p.x); put("y",p.y); put("a",p.angle); put("hp",p.health)
                })}
                val bytes = JSONObject().apply {
                    put("type","world_state"); put("ts",System.currentTimeMillis()); put("players",arr)
                }.toString().toByteArray()
                inRoom.forEach { p ->
                    val addr = p.udpAddr ?: return@forEach
                    try { udpSocket?.send(DatagramPacket(bytes, bytes.size, addr, p.udpPort)) }
                    catch (_: Exception) {}
                }
            }
            updateStatus()
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // LAN DISCOVERY — broadcasts every 2 s so clients auto-find us
    // ═════════════════════════════════════════════════════════════════════
    private suspend fun discoveryBroadcastLoop() = withContext(Dispatchers.IO) {
        val broadcast = InetAddress.getByName("255.255.255.255")
        while (isRunning) {
            try {
                val bytes = JSONObject().apply {
                    put("type","echo_server"); put("magic",PROTOCOL_MAGIC); put("ver",PROTOCOL_VER)
                    put("ip",localIP()); put("port",TCP_PORT)
                    put("players",players.size); put("max",MAX_PLAYERS)
                }.toString().toByteArray()
                discSocket?.send(DatagramPacket(bytes, bytes.size, broadcast, DISC_PORT))
            } catch (_: Exception) {}
            delay(DISC_MS)
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // HELPERS
    // ═════════════════════════════════════════════════════════════════════
    private fun broadcastRoom(roomId: String, msg: JSONObject, exclude: String? = null) {
        val line = msg.toString()
        players.values.filter { it.roomId == roomId && it.id != exclude }
            .forEach { try { it.writer.println(line) } catch (_: Exception) {} }
    }

    private fun reject(reason: String) =
        JSONObject().apply { put("type","rejected"); put("reason",reason) }.toString()

    fun localIP(): String = try {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip = wm.connectionInfo.ipAddress
        "%d.%d.%d.%d".format(ip and 0xff, ip shr 8 and 0xff, ip shr 16 and 0xff, ip shr 24 and 0xff)
            .also { if (it == "0.0.0.0") throw Exception("wifi ip zero") }
    } catch (_: Exception) {
        NetworkInterface.getNetworkInterfaces()?.toList()
            ?.flatMap { it.inetAddresses.toList() }
            ?.firstOrNull { !it.isLoopbackAddress && it is Inet4Address }
            ?.hostAddress ?: "127.0.0.1"
    }

    private fun updateStatus() {
        onStatusUpdate?.invoke(ServerStatus(players.size, rooms.size, localIP(), TCP_PORT))
    }

    // ═════════════════════════════════════════════════════════════════════
    // AUTHORITATIVE WEAPON DAMAGE TABLE
    // ═════════════════════════════════════════════════════════════════════
    private val WEAPON_DAMAGE = mapOf(
        "glock17" to 35,    "deagle" to 75,      "usp45" to 42,
        "p250" to 38,       "revolver" to 85,
        "mp5" to 26,        "uzi" to 22,          "p90" to 24,
        "mac10" to 20,      "kriss" to 29,
        "m870" to 120,      "spas12" to 130,      "aa12" to 100,   "judge" to 115,
        "ak47" to 40,       "m4a1" to 35,         "scar_h" to 48,
        "aug" to 36,        "g36c" to 34,          "fal" to 50,    "tar21" to 37,
        "m14" to 58,        "mk17" to 60,
        "m249" to 38,       "minigun" to 20,       "mg42" to 36,
        "awp" to 115,       "barrett" to 200,      "sv98" to 95,   "dmr" to 65,
        "rpg7" to 300,      "stinger" to 500,      "m79" to 250,
        "knife" to 80
    )
}

// ── data classes ─────────────────────────────────────────────────────────────

data class ServerPlayer(
    val id: String, val displayName: String,
    val socket: Socket, val writer: PrintWriter, val reader: BufferedReader,
    val roomId: String,
    var x: Float = 50f, var y: Float = 50f, var angle: Float = 0f,
    var health: Int = 100, var kills: Int = 0, var deaths: Int = 0,
    var udpAddr: InetAddress? = null, var udpPort: Int = 0
) { fun close() = try { socket.close() } catch (_: Exception) {} }

class ServerRoom(val id: String) {
    private val ids = ConcurrentHashMap.newKeySet<String>()
    val scores = ConcurrentHashMap<String, Int>()
    fun addPlayer(id: String) { ids.add(id); scores.putIfAbsent(id, 0) }
    fun removePlayer(id: String) { ids.remove(id) }
}

data class ServerStatus(val players: Int, val rooms: Int, val ip: String, val port: Int)
