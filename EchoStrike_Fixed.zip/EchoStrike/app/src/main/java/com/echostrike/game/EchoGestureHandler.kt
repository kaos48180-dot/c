package com.echostrike.game

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import com.echostrike.audio.EchoAudioEngine
import kotlin.math.sqrt

/**
 * EchoGestureHandler — Full accessibility gesture system.
 *
 * Complete gesture → action mapping:
 *
 * IN-GAME GESTURES:
 *   Single swipe RIGHT          → Turn right
 *   Single swipe LEFT           → Turn left
 *   Single swipe UP             → Move forward
 *   Single swipe DOWN           → Move backward
 *   Double tap                  → Fire weapon
 *   Long press                  → Status report (health, weapon, facing, enemies)
 *   Two-finger swipe RIGHT      → Next weapon
 *   Two-finger swipe LEFT       → Previous weapon
 *   Two-finger swipe UP         → Increase volume
 *   Two-finger swipe DOWN       → Decrease volume
 *   Two-finger double tap       → Reload (cosmetic)
 *   Pinch in/out                → Toggle crouch
 *   Three-finger tap            → Open pause menu
 *   Three-finger swipe UP       → Say current health
 *   Three-finger swipe DOWN     → Say enemy count
 *   Four-finger tap             → Say weapon info
 *   Shake device                → Melee attack
 *
 * MENU GESTURES:
 *   Single swipe UP             → Navigate up in list (plays listitem.wav)
 *   Single swipe DOWN           → Navigate down in list (plays scroll_down.ogg)
 *   Single tap                  → Activate / select (plays click.ogg)
 *   Double tap                  → Confirm / enter (plays finalize.ogg)
 *   Long press                  → Context info (plays long_clicked.ogg)
 *   Two-finger swipe left/right → Switch tabs (plays window_state.ogg)
 *   Swipe right from edge       → Back (plays cancel.ogg)
 *   Three-finger tap            → Main menu
 */
class EchoGestureHandler(
    private val context: Context,
    private val audio: EchoAudioEngine
) : SensorEventListener {

    enum class GestureMode { MENU, GAME }

    var mode = GestureMode.MENU
    var gameEngine: GameEngine? = null

    // Callbacks for menu navigation
    var onMenuUp: (() -> Unit)? = null
    var onMenuDown: (() -> Unit)? = null
    var onMenuSelect: (() -> Unit)? = null
    var onMenuBack: (() -> Unit)? = null
    var onMenuLongPress: (() -> Unit)? = null
    var onMenuTabSwitch: ((Int) -> Unit)? = null
    var onPauseMenu: (() -> Unit)? = null
    /** Chat gestures (3+ fingers). Return true if handled. */
    var onChatSwipe: ((SwipeTracker.Direction, Int) -> Boolean)? = null

    // Shake detection
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var lastShakeTime = 0L
    private var lastAccel = 0f
    private val SHAKE_THRESHOLD = 12f

    private var volumeLevel = 1.0f

    // ─── Swipes and multi-finger taps ──────────────────────────────────────
    private val swipes = SwipeTracker(
        minDistancePx = 64f * context.resources.displayMetrics.density,
        onSwipe = { dir, fingers -> handleSwipe(dir, fingers) },
        onMultiTap = { fingers -> handleMultiTap(fingers) }
    )

    private fun handleMultiTap(fingers: Int) {
        when {
            fingers >= 4 -> gameEngine?.let {
                audio.speak(it.currentWeapon.run {
                    "$displayName. Damage $damage. Range ${rangeMeters.toInt()} meters. " +
                        if (isAutomatic) "Automatic." else "Semi-auto."
                })
            }
            fingers == 3 -> {
                if (mode == GestureMode.GAME && onPauseMenu == null) gameEngine?.openPauseMenu()
                else { audio.playWindowOpen(); onPauseMenu?.invoke() }
            }
            else -> if (mode == GestureMode.GAME) gameEngine?.reload()
        }
    }

    private fun handleSwipe(dir: SwipeTracker.Direction, fingers: Int) {
        val horizontal = dir == SwipeTracker.Direction.LEFT || dir == SwipeTracker.Direction.RIGHT
        if (mode == GestureMode.GAME) {
            if (fingers >= 3 && onChatSwipe?.invoke(dir, fingers) == true) return
            when {
                fingers >= 3 && dir == SwipeTracker.Direction.UP ->
                    gameEngine?.let { audio.speak("Health: ${it.playerHealth}") }
                fingers >= 3 && dir == SwipeTracker.Direction.DOWN ->
                    gameEngine?.let { audio.speak("${it.getAliveEnemyCount()} enemies remaining.") }
                fingers == 2 && dir == SwipeTracker.Direction.RIGHT -> gameEngine?.nextWeapon()
                fingers == 2 && dir == SwipeTracker.Direction.LEFT -> gameEngine?.prevWeapon()
                fingers == 2 && dir == SwipeTracker.Direction.UP -> {
                    volumeLevel = (volumeLevel + 0.1f).coerceIn(0f, 1f)
                    audio.speak("Volume ${(volumeLevel * 100).toInt()} percent.")
                }
                fingers == 2 && dir == SwipeTracker.Direction.DOWN -> {
                    volumeLevel = (volumeLevel - 0.1f).coerceIn(0f, 1f)
                    audio.speak("Volume ${(volumeLevel * 100).toInt()} percent.")
                }
                dir == SwipeTracker.Direction.RIGHT -> gameEngine?.turnRight()
                dir == SwipeTracker.Direction.LEFT -> gameEngine?.turnLeft()
                dir == SwipeTracker.Direction.UP -> { audio.playScrollUp(); gameEngine?.moveForward() }
                dir == SwipeTracker.Direction.DOWN -> { audio.playScrollDown(); gameEngine?.moveBackward() }
            }
        } else {
            when {
                fingers >= 2 && horizontal -> {
                    audio.playWindowOpen()
                    onMenuTabSwitch?.invoke(if (dir == SwipeTracker.Direction.RIGHT) 1 else -1)
                }
                horizontal -> { audio.playCancel(); onMenuBack?.invoke() }
                dir == SwipeTracker.Direction.UP -> { audio.playScrollUp(); onMenuUp?.invoke() }
                dir == SwipeTracker.Direction.DOWN -> { audio.playScrollDown(); onMenuDown?.invoke() }
            }
        }
    }

    // ─── Taps, double taps, long press (single finger) ─────────────────────
    val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (swipes.multiTouch) return true
            audio.playClick()
            onMenuSelect?.invoke()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (swipes.multiTouch) return true
            if (mode == GestureMode.GAME) {
                val hit = gameEngine?.fire() ?: false
                if (!hit && gameEngine?.multiplayer != true) audio.speak("Missed.")
            } else {
                audio.playFinalize()
                onMenuSelect?.invoke()
            }
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            if (swipes.multiTouch) return
            if (mode == GestureMode.GAME) {
                gameEngine?.statusReport()
            } else {
                audio.playLongClick()
                onMenuLongPress?.invoke()
            }
        }
    })

    // ─── Pinch → crouch (toggle once when the pinch ends) ──────────────────
    val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        private var total = 1f
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean { total = 1f; return true }
        override fun onScale(detector: ScaleGestureDetector): Boolean { total *= detector.scaleFactor; return true }
        override fun onScaleEnd(detector: ScaleGestureDetector) {
            // only a clear pinch counts, not the small span change of a two-finger swipe
            if (mode == GestureMode.GAME && (total < 0.75f || total > 1.33f)) gameEngine?.toggleCrouch()
        }
    })

    fun onTouchEvent(event: MotionEvent): Boolean {
        swipes.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        return true
    }

    // ─── Shake Detection ───────────────────────────────────────────────────
    fun registerSensors() {
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME)
    }

    fun unregisterSensors() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]; val y = event.values[1]; val z = event.values[2]
        val accel = sqrt(x * x + y * y + z * z)
        val delta = accel - lastAccel
        lastAccel = accel

        if (delta > SHAKE_THRESHOLD) {
            val now = System.currentTimeMillis()
            if (now - lastShakeTime > 800) {
                lastShakeTime = now
                if (mode == GestureMode.GAME) {
                    gameEngine?.meleeAttack()
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
