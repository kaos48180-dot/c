package com.echostrike.security

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Base64
import android.util.Log
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import java.security.MessageDigest

/**
 * APKValidator — locks the embedded server to APKs signed with YOUR keystore.
 *
 * How it works:
 *   1. Read this APK's signing certificate fingerprint (unique to your keystore).
 *   2. HMAC-SHA256 it with a salt baked into the code → "token".
 *   3. Server computes its token at startup.
 *   4. Client sends its token in the handshake.
 *   5. Tokens match → same keystore → ACCESS GRANTED.
 *   6. Different APK → different fingerprint → different token → REJECTED.
 *
 * Changing TOKEN_SALT invalidates all existing tokens (version-gate old clients).
 */
object APKValidator {
    private const val TAG        = "APKValidator"
    private const val TOKEN_SALT = "EchoStrike_EmbeddedServer_v2_Salt_2025"

    @Volatile private var cache: String? = null

    fun computeToken(context: Context): String {
        cache?.let { return it }
        return try {
            val sig = getSignatureHash(context)
            hmac(sig, TOKEN_SALT).also { cache = it; Log.d(TAG, "Token: ${it.take(8)}…") }
        } catch (e: Exception) {
            Log.e(TAG, "Token error: ${e.message}")
            "debug_fallback_token"
        }
    }

    /** Constant-time comparison — prevents timing side-channel attacks */
    fun validateToken(clientToken: String, serverToken: String): Boolean {
        if (clientToken.isEmpty() || serverToken.isEmpty()) return false
        val a = clientToken.padEnd(64, '0')
        val b = serverToken.padEnd(64, '0')
        var diff = 0
        for (i in 0 until minOf(a.length, b.length)) diff = diff or (a[i].code xor b[i].code)
        return diff == 0
    }

    @Suppress("DEPRECATION")
    private fun getSignatureHash(context: Context): String {
        val pm = context.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                .signingInfo?.apkContentsSigners ?: emptyArray()
        } else {
            pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
        }
        val md = MessageDigest.getInstance("SHA-256")
        sigs.forEach { md.update(it.toByteArray()) }
        return Base64.encodeToString(md.digest(), Base64.NO_WRAP)
    }

    private fun hmac(data: String, key: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key.toByteArray(), "HmacSHA256"))
        return mac.doFinal(data.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}
