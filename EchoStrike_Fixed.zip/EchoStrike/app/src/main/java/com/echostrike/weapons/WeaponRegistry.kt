package com.echostrike.weapons

import com.echostrike.audio.EchoAudioEngine

/**
 * Complete weapon roster — every gun available from game start, infinite ammo.
 * Each weapon has:
 *   - Unique 3D spatial fire sound
 *   - Reload sound (even with infinite ammo, plays for realism)
 *   - Unique fire rate, range, damage
 *   - Spatial audio properties (how loud it is at distance)
 */
enum class WeaponCategory {
    PISTOL, SMG, SHOTGUN, ASSAULT_RIFLE, BATTLE_RIFLE,
    LMG, SNIPER, MARKSMAN, ROCKET, GRENADE_LAUNCHER, MELEE
}

data class Weapon(
    val id: String,
    val displayName: String,
    val category: WeaponCategory,
    val damage: Int,
    val fireRateRpm: Int,               // rounds per minute
    val rangeMeters: Float,
    val magazineSize: Int,              // cosmetic only — infinite ammo
    val fireSoundAsset: String,         // in sounds/weapons/
    val reloadSoundAsset: String,
    val emptySoundAsset: String,
    val equipSoundAsset: String,
    val isAutomatic: Boolean,
    val pellets: Int = 1,               // for shotguns
    val audioRadius: Float = 30f        // how far the shot can be heard
)

object WeaponRegistry {

    // All weapons available from the start
    val ALL_WEAPONS: List<Weapon> = listOf(

        // ── PISTOLS ──────────────────────────────────────────────────────────
        Weapon(
            id = "glock17",
            displayName = "Glock 17",
            category = WeaponCategory.PISTOL,
            damage = 35,
            fireRateRpm = 400,
            rangeMeters = 30f,
            magazineSize = 17,
            fireSoundAsset = "sounds/weapons/pistol_fire.ogg",
            reloadSoundAsset = "sounds/weapons/pistol_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/pistol_equip.ogg",
            isAutomatic = false,
            audioRadius = 25f
        ),
        Weapon(
            id = "deagle",
            displayName = "Desert Eagle",
            category = WeaponCategory.PISTOL,
            damage = 75,
            fireRateRpm = 200,
            rangeMeters = 40f,
            magazineSize = 7,
            fireSoundAsset = "sounds/weapons/deagle_fire.ogg",
            reloadSoundAsset = "sounds/weapons/pistol_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/pistol_equip.ogg",
            isAutomatic = false,
            audioRadius = 35f
        ),
        Weapon(
            id = "usp45",
            displayName = "USP .45",
            category = WeaponCategory.PISTOL,
            damage = 42,
            fireRateRpm = 350,
            rangeMeters = 28f,
            magazineSize = 12,
            fireSoundAsset = "sounds/weapons/pistol_suppressed.ogg",
            reloadSoundAsset = "sounds/weapons/pistol_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/pistol_equip.ogg",
            isAutomatic = false,
            audioRadius = 10f  // suppressed
        ),
        Weapon(
            id = "p250",
            displayName = "P250",
            category = WeaponCategory.PISTOL,
            damage = 38,
            fireRateRpm = 380,
            rangeMeters = 25f,
            magazineSize = 13,
            fireSoundAsset = "sounds/weapons/pistol_fire.ogg",
            reloadSoundAsset = "sounds/weapons/pistol_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/pistol_equip.ogg",
            isAutomatic = false,
            audioRadius = 22f
        ),
        Weapon(
            id = "revolver",
            displayName = ".357 Magnum Revolver",
            category = WeaponCategory.PISTOL,
            damage = 85,
            fireRateRpm = 150,
            rangeMeters = 45f,
            magazineSize = 6,
            fireSoundAsset = "sounds/weapons/revolver_fire.ogg",
            reloadSoundAsset = "sounds/weapons/revolver_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/pistol_equip.ogg",
            isAutomatic = false,
            audioRadius = 40f
        ),

        // ── SMGS ─────────────────────────────────────────────────────────────
        Weapon(
            id = "mp5",
            displayName = "MP5",
            category = WeaponCategory.SMG,
            damage = 26,
            fireRateRpm = 800,
            rangeMeters = 25f,
            magazineSize = 30,
            fireSoundAsset = "sounds/weapons/smg_fire.ogg",
            reloadSoundAsset = "sounds/weapons/smg_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/smg_equip.ogg",
            isAutomatic = true,
            audioRadius = 20f
        ),
        Weapon(
            id = "uzi",
            displayName = "Uzi",
            category = WeaponCategory.SMG,
            damage = 22,
            fireRateRpm = 950,
            rangeMeters = 20f,
            magazineSize = 32,
            fireSoundAsset = "sounds/weapons/smg_fire.ogg",
            reloadSoundAsset = "sounds/weapons/smg_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/smg_equip.ogg",
            isAutomatic = true,
            audioRadius = 18f
        ),
        Weapon(
            id = "p90",
            displayName = "P90",
            category = WeaponCategory.SMG,
            damage = 24,
            fireRateRpm = 900,
            rangeMeters = 28f,
            magazineSize = 50,
            fireSoundAsset = "sounds/weapons/smg_fire.ogg",
            reloadSoundAsset = "sounds/weapons/smg_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/smg_equip.ogg",
            isAutomatic = true,
            audioRadius = 20f
        ),
        Weapon(
            id = "mac10",
            displayName = "MAC-10",
            category = WeaponCategory.SMG,
            damage = 20,
            fireRateRpm = 1100,
            rangeMeters = 15f,
            magazineSize = 30,
            fireSoundAsset = "sounds/weapons/smg_fast.ogg",
            reloadSoundAsset = "sounds/weapons/smg_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/smg_equip.ogg",
            isAutomatic = true,
            audioRadius = 16f
        ),
        Weapon(
            id = "kriss_vector",
            displayName = "Kriss Vector",
            category = WeaponCategory.SMG,
            damage = 29,
            fireRateRpm = 1200,
            rangeMeters = 22f,
            magazineSize = 25,
            fireSoundAsset = "sounds/weapons/smg_heavy.ogg",
            reloadSoundAsset = "sounds/weapons/smg_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/smg_equip.ogg",
            isAutomatic = true,
            audioRadius = 22f
        ),

        // ── SHOTGUNS ─────────────────────────────────────────────────────────
        Weapon(
            id = "m870",
            displayName = "Remington 870",
            category = WeaponCategory.SHOTGUN,
            damage = 20,    // per pellet × 8 pellets
            fireRateRpm = 60,
            rangeMeters = 15f,
            magazineSize = 8,
            fireSoundAsset = "sounds/weapons/shotgun_fire.ogg",
            reloadSoundAsset = "sounds/weapons/shotgun_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/shotgun_equip.ogg",
            isAutomatic = false,
            pellets = 8,
            audioRadius = 35f
        ),
        Weapon(
            id = "spas12",
            displayName = "SPAS-12",
            category = WeaponCategory.SHOTGUN,
            damage = 22,
            fireRateRpm = 100,
            rangeMeters = 18f,
            magazineSize = 8,
            fireSoundAsset = "sounds/weapons/shotgun_heavy.ogg",
            reloadSoundAsset = "sounds/weapons/shotgun_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/shotgun_equip.ogg",
            isAutomatic = true,
            pellets = 8,
            audioRadius = 38f
        ),
        Weapon(
            id = "aa12",
            displayName = "AA-12 Auto Shotgun",
            category = WeaponCategory.SHOTGUN,
            damage = 18,
            fireRateRpm = 300,
            rangeMeters = 12f,
            magazineSize = 20,
            fireSoundAsset = "sounds/weapons/shotgun_auto.ogg",
            reloadSoundAsset = "sounds/weapons/shotgun_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/shotgun_equip.ogg",
            isAutomatic = true,
            pellets = 6,
            audioRadius = 30f
        ),
        Weapon(
            id = "judge",
            displayName = "Taurus Judge",
            category = WeaponCategory.SHOTGUN,
            damage = 25,
            fireRateRpm = 80,
            rangeMeters = 10f,
            magazineSize = 5,
            fireSoundAsset = "sounds/weapons/shotgun_fire.ogg",
            reloadSoundAsset = "sounds/weapons/revolver_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/pistol_equip.ogg",
            isAutomatic = false,
            pellets = 5,
            audioRadius = 30f
        ),

        // ── ASSAULT RIFLES ────────────────────────────────────────────────────
        Weapon(
            id = "ak47",
            displayName = "AK-47",
            category = WeaponCategory.ASSAULT_RIFLE,
            damage = 40,
            fireRateRpm = 600,
            rangeMeters = 50f,
            magazineSize = 30,
            fireSoundAsset = "sounds/weapons/ak47_fire.ogg",
            reloadSoundAsset = "sounds/weapons/ak47_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/rifle_equip.ogg",
            isAutomatic = true,
            audioRadius = 40f
        ),
        Weapon(
            id = "m4a1",
            displayName = "M4A1",
            category = WeaponCategory.ASSAULT_RIFLE,
            damage = 35,
            fireRateRpm = 700,
            rangeMeters = 50f,
            magazineSize = 30,
            fireSoundAsset = "sounds/weapons/m4_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rifle_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/rifle_equip.ogg",
            isAutomatic = true,
            audioRadius = 38f
        ),
        Weapon(
            id = "scar_h",
            displayName = "SCAR-H",
            category = WeaponCategory.ASSAULT_RIFLE,
            damage = 48,
            fireRateRpm = 550,
            rangeMeters = 55f,
            magazineSize = 20,
            fireSoundAsset = "sounds/weapons/scar_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rifle_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/rifle_equip.ogg",
            isAutomatic = true,
            audioRadius = 42f
        ),
        Weapon(
            id = "aug",
            displayName = "Steyr AUG",
            category = WeaponCategory.ASSAULT_RIFLE,
            damage = 36,
            fireRateRpm = 680,
            rangeMeters = 50f,
            magazineSize = 30,
            fireSoundAsset = "sounds/weapons/aug_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rifle_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/rifle_equip.ogg",
            isAutomatic = true,
            audioRadius = 36f
        ),
        Weapon(
            id = "g36c",
            displayName = "HK G36C",
            category = WeaponCategory.ASSAULT_RIFLE,
            damage = 34,
            fireRateRpm = 750,
            rangeMeters = 48f,
            magazineSize = 30,
            fireSoundAsset = "sounds/weapons/g36_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rifle_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/rifle_equip.ogg",
            isAutomatic = true,
            audioRadius = 35f
        ),
        Weapon(
            id = "fal",
            displayName = "FN FAL",
            category = WeaponCategory.ASSAULT_RIFLE,
            damage = 50,
            fireRateRpm = 650,
            rangeMeters = 60f,
            magazineSize = 20,
            fireSoundAsset = "sounds/weapons/fal_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rifle_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/rifle_equip.ogg",
            isAutomatic = false,
            audioRadius = 42f
        ),
        Weapon(
            id = "tar21",
            displayName = "Tavor TAR-21",
            category = WeaponCategory.ASSAULT_RIFLE,
            damage = 37,
            fireRateRpm = 800,
            rangeMeters = 45f,
            magazineSize = 30,
            fireSoundAsset = "sounds/weapons/m4_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rifle_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/rifle_equip.ogg",
            isAutomatic = true,
            audioRadius = 36f
        ),

        // ── BATTLE RIFLES ─────────────────────────────────────────────────────
        Weapon(
            id = "m14",
            displayName = "M14 EBR",
            category = WeaponCategory.BATTLE_RIFLE,
            damage = 58,
            fireRateRpm = 450,
            rangeMeters = 80f,
            magazineSize = 20,
            fireSoundAsset = "sounds/weapons/m14_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rifle_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/rifle_equip.ogg",
            isAutomatic = false,
            audioRadius = 45f
        ),
        Weapon(
            id = "mk17",
            displayName = "Mk 17 SCAR",
            category = WeaponCategory.BATTLE_RIFLE,
            damage = 60,
            fireRateRpm = 400,
            rangeMeters = 75f,
            magazineSize = 20,
            fireSoundAsset = "sounds/weapons/scar_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rifle_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/rifle_equip.ogg",
            isAutomatic = false,
            audioRadius = 45f
        ),

        // ── LMGs ──────────────────────────────────────────────────────────────
        Weapon(
            id = "m249",
            displayName = "M249 SAW",
            category = WeaponCategory.LMG,
            damage = 38,
            fireRateRpm = 800,
            rangeMeters = 55f,
            magazineSize = 100,
            fireSoundAsset = "sounds/weapons/lmg_fire.ogg",
            reloadSoundAsset = "sounds/weapons/lmg_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/lmg_equip.ogg",
            isAutomatic = true,
            audioRadius = 45f
        ),
        Weapon(
            id = "minigun",
            displayName = "M134 Minigun",
            category = WeaponCategory.LMG,
            damage = 20,
            fireRateRpm = 3000,
            rangeMeters = 40f,
            magazineSize = 999,
            fireSoundAsset = "sounds/weapons/minigun_fire.ogg",
            reloadSoundAsset = "sounds/weapons/lmg_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/lmg_equip.ogg",
            isAutomatic = true,
            audioRadius = 50f
        ),
        Weapon(
            id = "mg42",
            displayName = "MG42",
            category = WeaponCategory.LMG,
            damage = 36,
            fireRateRpm = 1200,
            rangeMeters = 60f,
            magazineSize = 75,
            fireSoundAsset = "sounds/weapons/lmg_fire.ogg",
            reloadSoundAsset = "sounds/weapons/lmg_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/lmg_equip.ogg",
            isAutomatic = true,
            audioRadius = 48f
        ),

        // ── SNIPERS ───────────────────────────────────────────────────────────
        Weapon(
            id = "awp",
            displayName = "AWP",
            category = WeaponCategory.SNIPER,
            damage = 115,
            fireRateRpm = 40,
            rangeMeters = 150f,
            magazineSize = 5,
            fireSoundAsset = "sounds/weapons/awp_fire.ogg",
            reloadSoundAsset = "sounds/weapons/sniper_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/sniper_equip.ogg",
            isAutomatic = false,
            audioRadius = 50f
        ),
        Weapon(
            id = "barrett50",
            displayName = "Barrett M82A1 .50 Cal",
            category = WeaponCategory.SNIPER,
            damage = 200,
            fireRateRpm = 25,
            rangeMeters = 200f,
            magazineSize = 10,
            fireSoundAsset = "sounds/weapons/barrett_fire.ogg",
            reloadSoundAsset = "sounds/weapons/sniper_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/sniper_equip.ogg",
            isAutomatic = false,
            audioRadius = 50f
        ),
        Weapon(
            id = "sv98",
            displayName = "SV-98",
            category = WeaponCategory.SNIPER,
            damage = 95,
            fireRateRpm = 45,
            rangeMeters = 140f,
            magazineSize = 10,
            fireSoundAsset = "sounds/weapons/awp_fire.ogg",
            reloadSoundAsset = "sounds/weapons/sniper_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/sniper_equip.ogg",
            isAutomatic = false,
            audioRadius = 48f
        ),

        // ── MARKSMAN ─────────────────────────────────────────────────────────
        Weapon(
            id = "dmr",
            displayName = "MK12 DMR",
            category = WeaponCategory.MARKSMAN,
            damage = 65,
            fireRateRpm = 180,
            rangeMeters = 90f,
            magazineSize = 20,
            fireSoundAsset = "sounds/weapons/m14_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rifle_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/rifle_equip.ogg",
            isAutomatic = false,
            audioRadius = 44f
        ),

        // ── ROCKETS ─────────────────────────────────────────────────────────
        Weapon(
            id = "rpg7",
            displayName = "RPG-7",
            category = WeaponCategory.ROCKET,
            damage = 300,
            fireRateRpm = 8,
            rangeMeters = 100f,
            magazineSize = 1,
            fireSoundAsset = "sounds/weapons/rpg_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rpg_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/lmg_equip.ogg",
            isAutomatic = false,
            audioRadius = 50f
        ),
        Weapon(
            id = "stinger",
            displayName = "FIM-92 Stinger",
            category = WeaponCategory.ROCKET,
            damage = 500,
            fireRateRpm = 4,
            rangeMeters = 300f,
            magazineSize = 1,
            fireSoundAsset = "sounds/weapons/missile_fire.ogg",
            reloadSoundAsset = "sounds/weapons/rpg_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/lmg_equip.ogg",
            isAutomatic = false,
            audioRadius = 50f
        ),

        // ── GRENADE LAUNCHER ─────────────────────────────────────────────────
        Weapon(
            id = "m79",
            displayName = "M79 Grenade Launcher",
            category = WeaponCategory.GRENADE_LAUNCHER,
            damage = 250,
            fireRateRpm = 20,
            rangeMeters = 80f,
            magazineSize = 1,
            fireSoundAsset = "sounds/weapons/grenade_launch.ogg",
            reloadSoundAsset = "sounds/weapons/grenade_reload.ogg",
            emptySoundAsset = "sounds/weapons/empty_click.ogg",
            equipSoundAsset = "sounds/weapons/lmg_equip.ogg",
            isAutomatic = false,
            audioRadius = 50f
        ),

        // ── MELEE ─────────────────────────────────────────────────────────────
        Weapon(
            id = "knife",
            displayName = "Combat Knife",
            category = WeaponCategory.MELEE,
            damage = 80,
            fireRateRpm = 120,
            rangeMeters = 2f,
            magazineSize = 1,
            fireSoundAsset = "sounds/weapons/knife_swing.ogg",
            reloadSoundAsset = "sounds/weapons/knife_swing.ogg",
            emptySoundAsset = "sounds/weapons/knife_swing.ogg",
            equipSoundAsset = "sounds/weapons/knife_equip.ogg",
            isAutomatic = false,
            audioRadius = 3f
        )
    )

    fun getById(id: String): Weapon? = ALL_WEAPONS.find { it.id == id }

    fun getByCategory(category: WeaponCategory): List<Weapon> =
        ALL_WEAPONS.filter { it.category == category }

    // Announcement text for TTS when switching weapons
    fun Weapon.announce(): String =
        "$displayName equipped. ${if (isAutomatic) "Automatic" else "Semi-automatic"}. " +
        "Damage ${damage}. Range ${rangeMeters.toInt()} meters."
}
