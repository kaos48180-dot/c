package com.echostrike.network

import android.content.Context
import android.content.Intent
import com.echostrike.server.*
import kotlinx.coroutines.*

/**
 * NetworkManager — thin wrapper that wires the UI to the embedded server/client.
 * Firebase is completely gone. Everything runs peer-to-peer.
 *
 * HOST flow:  NetworkManager.startServer() → server binds ports → broadcasts on LAN
 * JOIN flow:  NetworkManager.discover()   → finds hosts → NetworkManager.join(ip)
 *             OR NetworkManager.join(ip)  → direct IP connect
 */
class NetworkManager private constructor(private val context: Context) {

    companion object {
        @Volatile private var instance: NetworkManager? = null

        /** One shared manager, so the menu and the game screen use the SAME connection. */
        fun shared(context: Context): NetworkManager =
            instance ?: synchronized(this) {
                instance ?: NetworkManager(context.applicationContext).also { instance = it }
            }
    }

    /** Called (on the main thread) whenever the connection to the server is lost or closed. */
    var onDisconnect: (() -> Unit)? = null

    val server = EmbeddedGameServer(context)
    val client = EmbeddedGameClient(context)

    var isHost = false
    var isConnected = false

    // ── HOST ──────────────────────────────────────────────────────────────
    fun startServer(
        onReady:        (ip: String, port: Int) -> Unit,
        onPlayerJoined: (String) -> Unit,
        onPlayerLeft:   (String) -> Unit,
        onStatus:       (ServerStatus) -> Unit,
        onError:        (String) -> Unit = {}
    ) {
        server.onPlayerJoined  = onPlayerJoined
        server.onPlayerLeft    = onPlayerLeft
        server.onStatusUpdate  = onStatus

        server.start(onError = { reason -> onError(reason) }) { ip, port ->
            isHost = true
            // Start foreground service so server survives screen-off
            try {
                val svc = Intent(context, ServerForegroundService::class.java)
                context.startForegroundService(svc)
            } catch (_: Exception) { /* hosting still works while the app is open */ }
            onReady(ip, port)
        }
    }

    // ── DISCOVER (LAN) ────────────────────────────────────────────────────
    fun discover(onFound: (FoundServer) -> Unit) {
        client.onServerFound = onFound
        client.discover()
    }

    // ── JOIN ──────────────────────────────────────────────────────────────
    fun join(
        host:        String,
        displayName: String,
        room:        String = "default",
        authToken:   String? = null,
        onConnected: (String) -> Unit,
        onRejected:  (String) -> Unit
    ) {
        client.onConnected    = { id -> isConnected = true; onConnected(id) }
        client.onRejected     = { reason -> onRejected(reason) }
        client.onDisconnected = { isConnected = false; onDisconnect?.invoke() }
        client.connect(host, displayName = displayName, room = room, authToken = authToken)
    }

    // ── SEND (client side) ────────────────────────────────────────────────
    fun sendMove(x: Float, y: Float, angle: Float) = client.sendPositionFast(x, y, angle)
    fun sendFire(x: Float, y: Float, angle: Float, weapon: String) = client.sendFire(x, y, angle, weapon)
    fun sendChat(text: String) = client.sendChat(text)
    fun sendChatMessage(text: String) = client.sendChat(text)
    fun requestLeaderboard()   = client.requestLeaderboard()

    // ── CLEANUP ───────────────────────────────────────────────────────────
    fun shutdown() {
        onDisconnect = null
        client.disconnect()
        if (isHost) {
            server.stop()
            context.stopService(Intent(context, ServerForegroundService::class.java))
            isHost = false
        }
        isConnected = false
    }

    // ── CONVENIENCE: host AND connect as a local client ───────────────────
    /** Host a game and also put yourself in it as a player */
    fun hostAndJoin(
        displayName: String,
        onReady:     (ip: String) -> Unit,
        onRejected:  (String) -> Unit
    ) {
        startServer(
            onReady        = { ip, port ->
                // Give server 500 ms to bind then connect locally
                CoroutineScope(Dispatchers.IO).launch {
                    delay(500)
                    join("127.0.0.1", displayName, onConnected = { onReady(ip) }, onRejected = onRejected)
                }
            },
            onPlayerJoined = {},
            onPlayerLeft   = {},
            onStatus       = {},
            onError        = { reason -> onRejected("Could not start the server: $reason") }
        )
    }

    val serverIP   get() = server.localIP()
    val playerCount get() = server.players.size
}
