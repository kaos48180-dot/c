package com.echostrike.network

import android.content.Context
import com.echostrike.BuildConfig

/**
 * Which cloud server this app talks to.
 *
 * Priority: 1) the address sent by the EchoStrike Developer Console app (saved here),
 *           2) the hostname baked into this build (ECHO_SERVER_HOST).
 */
object ServerConfig {
    private const val PREFS = "server_config"
    private const val KEY_HOST = "host"

    fun host(context: Context): String {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_HOST, null)
        return (if (!saved.isNullOrBlank()) saved else BuildConfig.ECHO_SERVER_HOST).trim()
    }

    /** Accepts "https://name.fly.dev/", "name.fly.dev" etc. and stores the bare hostname. */
    fun save(context: Context, address: String): String? {
        val host = clean(address) ?: return null
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_HOST, host).apply()
        return host
    }

    fun clean(address: String): String? {
        val h = address.trim().removePrefix("https://").removePrefix("http://").trimEnd('/').substringBefore('/')
        return if (Regex("^[A-Za-z0-9.-]{3,253}(:[0-9]{1,5})?$").matches(h)) h else null
    }

    /** Only an address the console sent (never the baked-in cloud name). */
    fun savedHost(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_HOST, null)?.trim().orEmpty()

    const val ACTION_CONFIGURE = "com.echostrike.action.CONFIGURE_SERVER"
    const val EXTRA_HOST = "host"
    const val CONSOLE_PACKAGE = "com.echostrike.developer"
}
