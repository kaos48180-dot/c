package com.echostrike.game

import com.echostrike.audio.EchoAudioEngine
import com.echostrike.weapons.Weapon
import com.echostrike.weapons.WeaponRegistry
import com.echostrike.weapons.WeaponRegistry.announce
import kotlinx.coroutines.*
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.*
import kotlin.random.Random

/**
 * Core game engine — manages player state, world simulation,
 * and audio-driven combat loop.
 */
class GameEngine(private val audio: EchoAudioEngine) {

    // ── Constants ──────────────────────────────────────────────────────────
    companion object {
        const val ARENA_SIZE = 100f
        const val PLAYER_SPEED = 3f        // meters per second
        const val TURN_SPEED = 15f         // degrees per swipe
        const val MAX_HEALTH = 100
        const val FOOTSTEP_INTERVAL_MS = 400L
        const val ENEMY_UPDATE_MS = 100L
    }

    // ── Player State ─────────────────────────────────────────────────────
    var playerX = ARENA_SIZE / 2f
    var playerY = ARENA_SIZE / 2f
    var playerHealth = MAX_HEALTH
    var playerAngle = 0f       // facing direction in degrees
    var isCrouching = false
    var isRunning = false

    // ── Weapon State ─────────────────────────────────────────────────────
    private val allWeapons = WeaponRegistry.ALL_WEAPONS.toMutableList()
    private var currentWeaponIndex = 0
    val currentWeapon: Weapon get() = allWeapons[currentWeaponIndex]

    // ── Enemy State ─────────────────────────────────────────────────────
    val enemies: MutableList<Enemy> = CopyOnWriteArrayList()
    private val botStates = HashMap<String, BotBrain.State>()
    private val lastEnemyStep = HashMap<String, Long>()
    private var botDifficulty = BotBrain.Difficulty.NORMAL
    private var botCount = 3
    private var wave = 0
    private val botRandom = java.util.Random()

    // ── Kill tracking ─────────────────────────────────────────────────────
    var kills = 0
    var deaths = 0
    var score = 0

    // ── Game loop ─────────────────────────────────────────────────────────
    private val gameScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var isRunningGame = false
    private var footstepJob: Job? = null
    private var enemyJob: Job? = null

    // Fire rate throttling
    private var lastFireTime = 0L

    // ── Callbacks for UI ─────────────────────────────────────────────────
    var onHealthChanged: ((Int) -> Unit)? = null
    var onKill: ((String) -> Unit)? = null
    var onDeath: (() -> Unit)? = null
    var onEnemyNearby: ((Enemy, Float) -> Unit)? = null
    var onScoreChanged: ((Int) -> Unit)? = null
    var onWeaponChanged: ((Weapon) -> Unit)? = null

    /** True when playing against other people: the server decides hits, not this engine. */
    var multiplayer = false
    /** Called whenever a shot is actually fired (after fire-rate limiting) so the UI can tell the server. */
    var onShotFired: ((Weapon) -> Unit)? = null
    /** Called when the player swings the knife. */
    var onMeleeSwing: (() -> Unit)? = null

    // ─────────────────────────────────────────────────────────────────────
    // GAME CONTROL
    // ─────────────────────────────────────────────────────────────────────

    /** Start an offline game against computer-controlled bots. */
    fun startGame(mode: GameMode, bots: Int = 3, difficulty: BotBrain.Difficulty = BotBrain.Difficulty.NORMAL) {
        isRunningGame = true
        botCount = bots.coerceIn(1, 12)
        botDifficulty = difficulty
        wave = 1
        audio.setEnvironment(EchoAudioEngine.ENV_ARENA)
        spawnEnemies()
        startEnemyLoop()
        audio.playGameStart()
        audio.speak("Offline game. ${mode.displayName} mode against $botCount bots on ${difficulty.label}. " +
            "You have ${currentWeapon.displayName}. All weapons available. Listen for footsteps.")
    }

    fun pauseGame() {
        isRunningGame = false
        footstepJob?.cancel()
        audio.playPause()
        audio.pauseAll()
        audio.speak("Game paused.")
    }

    fun resumeGame() {
        isRunningGame = true
        audio.resumeAll()
        audio.speak("Game resumed.")
    }

    fun endGame() {
        isRunningGame = false
        footstepJob?.cancel()
        enemyJob?.cancel()
        audio.stopAllSounds()
        gameScope.cancel()
    }

    // ─────────────────────────────────────────────────────────────────────
    // GESTURE → GAME ACTIONS
    // ─────────────────────────────────────────────────────────────────────

    /** Swipe right → turn right */
    fun turnRight() {
        playerAngle = (playerAngle + TURN_SPEED) % 360f
        audio.listenerAngle = playerAngle
        announceDirection()
    }

    /** Swipe left → turn left */
    fun turnLeft() {
        playerAngle = ((playerAngle - TURN_SPEED) + 360f) % 360f
        audio.listenerAngle = playerAngle
        announceDirection()
    }

    /** Swipe up → move forward */
    fun moveForward() {
        val dx = sin(Math.toRadians(playerAngle.toDouble())).toFloat() * PLAYER_SPEED
        val dy = cos(Math.toRadians(playerAngle.toDouble())).toFloat() * PLAYER_SPEED
        val newX = (playerX + dx).coerceIn(0f, ARENA_SIZE)
        val newY = (playerY + dy).coerceIn(0f, ARENA_SIZE)
        playerX = newX; playerY = newY
        audio.listenerX = playerX; audio.listenerY = playerY
        playFootstep()
    }

    /** Swipe down → move backward */
    fun moveBackward() {
        val dx = sin(Math.toRadians(playerAngle.toDouble())).toFloat() * PLAYER_SPEED
        val dy = cos(Math.toRadians(playerAngle.toDouble())).toFloat() * PLAYER_SPEED
        val newX = (playerX - dx).coerceIn(0f, ARENA_SIZE)
        val newY = (playerY - dy).coerceIn(0f, ARENA_SIZE)
        playerX = newX; playerY = newY
        audio.listenerX = playerX; audio.listenerY = playerY
        playFootstep()
    }

    /** Double tap → fire */
    fun fire(): Boolean {
        val now = System.currentTimeMillis()
        val fireIntervalMs = (60000L / currentWeapon.fireRateRpm)
        if (now - lastFireTime < fireIntervalMs) return false
        lastFireTime = now
        onShotFired?.invoke(currentWeapon)

        // Play fire sound at player position (heard by enemies)
        audio.playSound3D(
            "sounds/weapons/${currentWeapon.fireSoundAsset.substringAfterLast("/")}",
            playerX, playerY, pitchMultiplier = if (isCrouching) 0.95f else 1f
        )

        // Check hit detection (ray cast against enemies)
        val hit = if (multiplayer) null else performRayCast()
        if (hit != null) {
            applyDamage(hit, currentWeapon.damage * if (currentWeapon.pellets > 1)
                (Random.nextInt(currentWeapon.pellets) + 1) else 1)
        }
        return hit != null
    }

    /** Two-finger swipe left → previous weapon */
    fun prevWeapon() {
        currentWeaponIndex = (currentWeaponIndex - 1 + allWeapons.size) % allWeapons.size
        onWeaponChanged?.invoke(currentWeapon)
        audio.playClick()
        audio.speak(currentWeapon.announce())
    }

    /** Two-finger swipe right → next weapon */
    fun nextWeapon() {
        currentWeaponIndex = (currentWeaponIndex + 1) % allWeapons.size
        onWeaponChanged?.invoke(currentWeapon)
        audio.playClick()
        audio.speak(currentWeapon.announce())
    }

    /** Long press → current status */
    fun statusReport() {
        audio.playLongClick()
        val nearestEnemy = enemies.filter { it.isAlive }.minByOrNull { distanceTo(it) }
        val nearestDist = nearestEnemy?.let { distanceTo(it) }
        audio.speak(
            buildString {
                append("Health ${playerHealth}. ")
                append("Weapon: ${currentWeapon.displayName}. ")
                append("Score ${score}. Kills ${kills}. ")
                append("Facing ${compassDirection(playerAngle)}. ")
                if (nearestEnemy != null) {
                    val dir = angleToEnemy(nearestEnemy)
                    append("Nearest enemy ${nearestDist?.toInt()} meters to the ${compassDirection(dir)}. ")
                }
                append(if (isCrouching) "Crouching." else "Standing.")
            }
        )
    }

    /** Pinch → toggle crouch */
    fun toggleCrouch() {
        isCrouching = !isCrouching
        audio.playGestureBegin()
        audio.speak(if (isCrouching) "Crouching." else "Standing.")
        audio.playGestureEnd()
    }

    /** Three-finger tap → pause menu */
    fun openPauseMenu() {
        audio.playWindowOpen()
        pauseGame()
    }

    /** Two-finger double tap → reload (cosmetic, infinite ammo) */
    fun reload() {
        audio.speak("Reloading.")
        gameScope.launch {
            delay(1500)
            audio.speak("Ready.")
        }
    }

    /** Shake device → melee attack */
    fun meleeAttack() {
        onMeleeSwing?.invoke()
        val knifeWeapon = WeaponRegistry.getById("knife")!!
        val hit = if (multiplayer) null else enemies.filter { it.isAlive && distanceTo(it) <= knifeWeapon.rangeMeters }
            .minByOrNull { distanceTo(it) }
        if (hit != null) {
            applyDamage(hit, knifeWeapon.damage)
            audio.playSound3D("sounds/weapons/knife_swing.ogg", hit.x, hit.y)
        } else {
            audio.playSound3D("sounds/weapons/knife_swing.ogg", playerX, playerY)
            if (!multiplayer) audio.speak("Miss.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // COMBAT
    // ─────────────────────────────────────────────────────────────────────

    private fun performRayCast(): Enemy? {
        val angleRad = Math.toRadians(playerAngle.toDouble())
        val dirX = sin(angleRad).toFloat()
        val dirY = cos(angleRad).toFloat()

        // Check each alive enemy for hit within weapon range and ~15 degree cone
        return enemies.filter { it.isAlive }.filter { enemy ->
            val dist = distanceTo(enemy)
            if (dist > currentWeapon.rangeMeters) return@filter false
            val toEnemyAngle = angleToEnemy(enemy)
            val angleDiff = abs(((toEnemyAngle - playerAngle + 540) % 360) - 180)
            angleDiff < 15f
        }.minByOrNull { distanceTo(it) }
    }

    private fun applyDamage(enemy: Enemy, damage: Int) {
        enemy.health -= damage
        if (enemy.health <= 0) {
            enemy.isAlive = false
            kills++
            score += 100
            onKill?.invoke(enemy.id)
            audio.playKillConfirmed()
            audio.playSound3D("sounds/weapons/enemy_death.ogg", enemy.x, enemy.y)
            audio.speak("Enemy down! ${kills} kills.")
            onScoreChanged?.invoke(score)

            if (getAliveEnemyCount() == 0 && !multiplayer) {
                audio.speak("All bots down. Next wave in three seconds.", interrupt = false)
                nextWave()
            }
        } else {
            audio.playSound3D("sounds/weapons/enemy_hit.ogg", enemy.x, enemy.y)
        }
    }

    fun takeDamage(damage: Int, fromX: Float, fromY: Float) {
        if (playerHealth <= 0) return
        audio.playUI("sounds/weapons/enemy_hit.ogg")
        playerHealth -= damage
        onHealthChanged?.invoke(playerHealth)

        if (playerHealth <= 0) {
            playerHealth = 0
            deaths++
            onDeath?.invoke()
            audio.speak("You were killed.")
        } else {
            val dir = compassDirection(
                Math.toDegrees(atan2((fromX - playerX).toDouble(),
                    (fromY - playerY).toDouble())).toFloat()
            )
            audio.speak("Hit from the $dir! Health ${playerHealth}.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // ENEMY AI
    // ─────────────────────────────────────────────────────────────────────

    private fun spawnEnemies() {
        enemies.clear(); botStates.clear(); lastEnemyStep.clear()
        repeat(botCount) { i ->
            // keep new bots at least 25 m away from the player so you hear them coming
            var x: Float; var y: Float; var tries = 0
            do {
                x = 5f + Random.nextFloat() * (ARENA_SIZE - 10f)
                y = 5f + Random.nextFloat() * (ARENA_SIZE - 10f)
                tries++
            } while (tries < 20 && hypot((x - playerX).toDouble(), (y - playerY).toDouble()) < 25.0)
            val id = "bot_${wave}_$i"
            enemies.add(Enemy(id = id, x = x, y = y, health = 100, isAlive = true,
                angle = Random.nextFloat() * 360f, aggroRange = botDifficulty.sightRange, isBot = true,
                name = "Bot ${i + 1}"))
            botStates[id] = BotBrain.State(x, y)
        }
    }

    private fun startEnemyLoop() {
        enemyJob?.cancel()
        enemyJob = gameScope.launch {
            while (isRunningGame) {
                delay(ENEMY_UPDATE_MS)
                updateEnemies()
            }
        }
    }

    private fun updateEnemies() {
        val now = System.currentTimeMillis()
        val dt = ENEMY_UPDATE_MS / 1000f
        val playerAlive = playerHealth > 0
        for (enemy in enemies) {
            if (!enemy.isAlive) continue
            val st = botStates[enemy.id] ?: continue
            val oldX = enemy.x; val oldY = enemy.y
            st.x = enemy.x; st.y = enemy.y; st.angle = enemy.angle
            val r = BotBrain.step(
                st, if (playerAlive) playerX else null, if (playerAlive) playerY else null,
                dt, now, botDifficulty, botRandom, ARENA_SIZE
            )
            enemy.x = st.x; enemy.y = st.y; enemy.angle = st.angle

            val dist = distanceTo(enemy)
            // footsteps: only while the bot is actually walking, and loud enough to hear from afar
            if ((enemy.x != oldX || enemy.y != oldY) && dist < 45f &&
                now - (lastEnemyStep[enemy.id] ?: 0L) > 420L) {
                lastEnemyStep[enemy.id] = now
                audio.playSound3D("sounds/ambient/footstep_enemy.ogg", enemy.x, enemy.y)
            }
            if (r.fired) {
                audio.playSound3D("sounds/weapons/ak47_fire.ogg", enemy.x, enemy.y)
                if (r.hit) {
                    val dmg = (Random.nextInt(10, 23) * botDifficulty.damageScale).toInt().coerceAtLeast(1)
                    takeDamage(dmg, enemy.x, enemy.y)
                }
            }
            if (r.chasing && dist < botDifficulty.sightRange) onEnemyNearby?.invoke(enemy, dist)
        }
    }

    private fun nextWave() {
        wave++
        gameScope.launch {
            delay(3000)
            if (!isRunningGame) return@launch
            spawnEnemies()
            audio.speak("Wave $wave. ${enemies.size} bots incoming.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // FOOTSTEPS
    // ─────────────────────────────────────────────────────────────────────

    private fun playFootstep() {
        val asset = if (isCrouching) "sounds/ambient/footstep_crouch.ogg"
        else "sounds/ambient/footstep.ogg"
        audio.playUI(asset, if (isCrouching) 0.55f else 1.0f)
    }

    // ─────────────────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────────────────

    fun distanceTo(enemy: Enemy) =
        sqrt((enemy.x - playerX).pow(2) + (enemy.y - playerY).pow(2))

    fun angleToEnemy(enemy: Enemy) =
        Math.toDegrees(atan2((enemy.x - playerX).toDouble(), (enemy.y - playerY).toDouble())).toFloat()

    private fun announceDirection() {
        // Only announce every ~45 degrees to avoid spam
        val sector = (playerAngle / 45).toInt() * 45
        if (sector % 45 == 0) audio.speak(compassDirection(playerAngle), interrupt = false)
    }

    fun compassDirection(angle: Float): String {
        val a = ((angle % 360) + 360) % 360
        return when {
            a < 22.5 || a >= 337.5 -> "North"
            a < 67.5  -> "Northeast"
            a < 112.5 -> "East"
            a < 157.5 -> "Southeast"
            a < 202.5 -> "South"
            a < 247.5 -> "Southwest"
            a < 292.5 -> "West"
            else       -> "Northwest"
        }
    }

    fun respawn() {
        playerHealth = MAX_HEALTH
        playerX = Random.nextFloat() * ARENA_SIZE
        playerY = Random.nextFloat() * ARENA_SIZE
        audio.listenerX = playerX; audio.listenerY = playerY
        audio.speak("Respawned. Health 100.")
        onHealthChanged?.invoke(playerHealth)
    }

    fun respawnAt(x: Float, y: Float) {
        playerHealth = MAX_HEALTH
        playerX = x; playerY = y
        audio.listenerX = x; audio.listenerY = y
        onHealthChanged?.invoke(playerHealth)
    }

    fun getAliveEnemyCount() = enemies.count { it.isAlive }
}

// ── Data classes ──────────────────────────────────────────────────────────────

data class Enemy(
    val id: String,
    var x: Float,
    var y: Float,
    var health: Int,
    var isAlive: Boolean,
    var angle: Float,
    val aggroRange: Float,
    val isBot: Boolean,
    var name: String = "Enemy"
)

enum class GameMode(val displayName: String) {
    DEATHMATCH("Deathmatch"),
    TEAM_DEATHMATCH("Team Deathmatch"),
    BATTLE_ROYALE("Battle Royale"),
    SURVIVAL("Survival"),
    CAPTURE_FLAG("Capture the Flag")
}
