package com.echostrike.game

import com.echostrike.audio.EchoAudioEngine
import com.echostrike.weapons.Weapon
import com.echostrike.weapons.WeaponRegistry
import com.echostrike.weapons.WeaponRegistry.announce
import kotlinx.coroutines.*
import kotlin.math.*
import kotlin.random.Random

/**
 * Core game engine — manages player state, world simulation,
 * and audio-driven combat loop.
 */
class GameEngine(private val audio: EchoAudioEngine) {

    // ── Constants ──────────────────────────────────────────────────────────
    companion object {
        const val ARENA_SIZE = 100f
        const val PLAYER_SPEED = 3f        // meters per second
        const val TURN_SPEED = 15f         // degrees per swipe
        const val MAX_HEALTH = 100
        const val FOOTSTEP_INTERVAL_MS = 400L
        const val ENEMY_UPDATE_MS = 100L
    }

    // ── Player State ─────────────────────────────────────────────────────
    var playerX = ARENA_SIZE / 2f
    var playerY = ARENA_SIZE / 2f
    var playerHealth = MAX_HEALTH
    var playerAngle = 0f       // facing direction in degrees
    var isCrouching = false
    var isRunning = false

    // ── Weapon State ─────────────────────────────────────────────────────
    private val allWeapons = WeaponRegistry.ALL_WEAPONS.toMutableList()
    private var currentWeaponIndex = 0
    val currentWeapon: Weapon get() = allWeapons[currentWeaponIndex]

    // ── Enemy State ─────────────────────────────────────────────────────
    val enemies = mutableListOf<Enemy>()
    private var enemyAudioStreams = mutableMapOf<String, Int>()   // enemyId → streamId

    // ── Kill tracking ─────────────────────────────────────────────────────
    var kills = 0
    var deaths = 0
    var score = 0

    // ── Game loop ─────────────────────────────────────────────────────────
    private val gameScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var isRunningGame = false
    private var footstepJob: Job? = null
    private var enemyJob: Job? = null

    // Fire rate throttling
    private var lastFireTime = 0L

    // ── Callbacks for UI ─────────────────────────────────────────────────
    var onHealthChanged: ((Int) -> Unit)? = null
    var onKill: ((String) -> Unit)? = null
    var onDeath: (() -> Unit)? = null
    var onEnemyNearby: ((Enemy, Float) -> Unit)? = null
    var onScoreChanged: ((Int) -> Unit)? = null
    var onWeaponChanged: ((Weapon) -> Unit)? = null

    /** True when playing against other people: the server decides hits, not this engine. */
    var multiplayer = false
    /** Called whenever a shot is actually fired (after fire-rate limiting) so the UI can tell the server. */
    var onShotFired: ((Weapon) -> Unit)? = null
    /** Called when the player swings the knife. */
    var onMeleeSwing: (() -> Unit)? = null

    // ─────────────────────────────────────────────────────────────────────
    // GAME CONTROL
    // ─────────────────────────────────────────────────────────────────────

    fun startGame(mode: GameMode) {
        isRunningGame = true
        audio.setEnvironment(EchoAudioEngine.ENV_ARENA)
        spawnEnemies(mode)
        startEnemyLoop()
        audio.playGameStart()
        audio.speak("Game started. ${mode.displayName} mode. You have ${currentWeapon.displayName}. All weapons available.")
    }

    fun pauseGame() {
        isRunningGame = false
        footstepJob?.cancel()
        audio.playPause()
        audio.pauseAll()
        audio.speak("Game paused.")
    }

    fun resumeGame() {
        isRunningGame = true
        audio.resumeAll()
        audio.speak("Game resumed.")
    }

    fun endGame() {
        isRunningGame = false
        footstepJob?.cancel()
        enemyJob?.cancel()
        audio.stopAllSounds()
        gameScope.cancel()
    }

    // ─────────────────────────────────────────────────────────────────────
    // GESTURE → GAME ACTIONS
    // ─────────────────────────────────────────────────────────────────────

    /** Swipe right → turn right */
    fun turnRight() {
        audio.playGestureBegin()
        playerAngle = (playerAngle + TURN_SPEED) % 360f
        audio.listenerAngle = playerAngle
        announceDirection()
        audio.playGestureEnd()
    }

    /** Swipe left → turn left */
    fun turnLeft() {
        audio.playGestureBegin()
        playerAngle = ((playerAngle - TURN_SPEED) + 360f) % 360f
        audio.listenerAngle = playerAngle
        announceDirection()
        audio.playGestureEnd()
    }

    /** Swipe up → move forward */
    fun moveForward() {
        audio.playGestureBegin()
        val dx = sin(Math.toRadians(playerAngle.toDouble())).toFloat() * PLAYER_SPEED
        val dy = cos(Math.toRadians(playerAngle.toDouble())).toFloat() * PLAYER_SPEED
        val newX = (playerX + dx).coerceIn(0f, ARENA_SIZE)
        val newY = (playerY + dy).coerceIn(0f, ARENA_SIZE)
        playerX = newX; playerY = newY
        audio.listenerX = playerX; audio.listenerY = playerY
        updateEnemyAudio()
        playFootstep()
        audio.playGestureEnd()
    }

    /** Swipe down → move backward */
    fun moveBackward() {
        audio.playGestureBegin()
        val dx = sin(Math.toRadians(playerAngle.toDouble())).toFloat() * PLAYER_SPEED
        val dy = cos(Math.toRadians(playerAngle.toDouble())).toFloat() * PLAYER_SPEED
        val newX = (playerX - dx).coerceIn(0f, ARENA_SIZE)
        val newY = (playerY - dy).coerceIn(0f, ARENA_SIZE)
        playerX = newX; playerY = newY
        audio.listenerX = playerX; audio.listenerY = playerY
        updateEnemyAudio()
        playFootstep()
        audio.playMoveBack()
        audio.playGestureEnd()
    }

    /** Double tap → fire */
    fun fire(): Boolean {
        val now = System.currentTimeMillis()
        val fireIntervalMs = (60000L / currentWeapon.fireRateRpm)
        if (now - lastFireTime < fireIntervalMs) return false
        lastFireTime = now
        onShotFired?.invoke(currentWeapon)

        // Play fire sound at player position (heard by enemies)
        audio.playSound3D(
            "sounds/weapons/${currentWeapon.fireSoundAsset.substringAfterLast("/")}",
            playerX, playerY, pitchMultiplier = if (isCrouching) 0.95f else 1f
        )

        // Check hit detection (ray cast against enemies)
        val hit = if (multiplayer) null else performRayCast()
        if (hit != null) {
            applyDamage(hit, currentWeapon.damage * if (currentWeapon.pellets > 1)
                (Random.nextInt(currentWeapon.pellets) + 1) else 1)
        }
        return hit != null
    }

    /** Two-finger swipe left → previous weapon */
    fun prevWeapon() {
        currentWeaponIndex = (currentWeaponIndex - 1 + allWeapons.size) % allWeapons.size
        onWeaponChanged?.invoke(currentWeapon)
        audio.playClick()
        audio.speak(currentWeapon.announce())
    }

    /** Two-finger swipe right → next weapon */
    fun nextWeapon() {
        currentWeaponIndex = (currentWeaponIndex + 1) % allWeapons.size
        onWeaponChanged?.invoke(currentWeapon)
        audio.playClick()
        audio.speak(currentWeapon.announce())
    }

    /** Long press → current status */
    fun statusReport() {
        audio.playLongClick()
        val nearestEnemy = enemies.filter { it.isAlive }.minByOrNull { distanceTo(it) }
        val nearestDist = nearestEnemy?.let { distanceTo(it) }
        audio.speak(
            buildString {
                append("Health ${playerHealth}. ")
                append("Weapon: ${currentWeapon.displayName}. ")
                append("Score ${score}. Kills ${kills}. ")
                append("Facing ${compassDirection(playerAngle)}. ")
                if (nearestEnemy != null) {
                    val dir = angleToEnemy(nearestEnemy)
                    append("Nearest enemy ${nearestDist?.toInt()} meters to the ${compassDirection(dir)}. ")
                }
                append(if (isCrouching) "Crouching." else "Standing.")
            }
        )
    }

    /** Pinch → toggle crouch */
    fun toggleCrouch() {
        isCrouching = !isCrouching
        audio.playGestureBegin()
        audio.speak(if (isCrouching) "Crouching." else "Standing.")
        audio.playGestureEnd()
    }

    /** Three-finger tap → pause menu */
    fun openPauseMenu() {
        audio.playWindowOpen()
        pauseGame()
    }

    /** Two-finger double tap → reload (cosmetic, infinite ammo) */
    fun reload() {
        audio.speak("Reloading.")
        gameScope.launch {
            delay(1500)
            audio.speak("Ready.")
        }
    }

    /** Shake device → melee attack */
    fun meleeAttack() {
        onMeleeSwing?.invoke()
        val knifeWeapon = WeaponRegistry.getById("knife")!!
        val hit = if (multiplayer) null else enemies.filter { it.isAlive && distanceTo(it) <= knifeWeapon.rangeMeters }
            .minByOrNull { distanceTo(it) }
        if (hit != null) {
            applyDamage(hit, knifeWeapon.damage)
            audio.playSound3D("sounds/weapons/knife_swing.ogg", hit.x, hit.y)
        } else {
            audio.playSound3D("sounds/weapons/knife_swing.ogg", playerX, playerY)
            if (!multiplayer) audio.speak("Miss.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // COMBAT
    // ─────────────────────────────────────────────────────────────────────

    private fun performRayCast(): Enemy? {
        val angleRad = Math.toRadians(playerAngle.toDouble())
        val dirX = sin(angleRad).toFloat()
        val dirY = cos(angleRad).toFloat()

        // Check each alive enemy for hit within weapon range and ~15 degree cone
        return enemies.filter { it.isAlive }.filter { enemy ->
            val dist = distanceTo(enemy)
            if (dist > currentWeapon.rangeMeters) return@filter false
            val toEnemyAngle = angleToEnemy(enemy)
            val angleDiff = abs(((toEnemyAngle - playerAngle + 540) % 360) - 180)
            angleDiff < 15f
        }.minByOrNull { distanceTo(it) }
    }

    private fun applyDamage(enemy: Enemy, damage: Int) {
        enemy.health -= damage
        if (enemy.health <= 0) {
            enemy.isAlive = false
            kills++
            score += 100
            onKill?.invoke(enemy.id)
            audio.playKillConfirmed()
            audio.playSound3D("sounds/weapons/enemy_death.ogg", enemy.x, enemy.y)
            audio.speak("Enemy down! ${kills} kills.")
            onScoreChanged?.invoke(score)

            // Stop enemy footstep audio
            enemyAudioStreams[enemy.id]?.let { audio.stopSound(it) }
        } else {
            audio.playSound3D("sounds/weapons/enemy_hit.ogg", enemy.x, enemy.y)
        }
    }

    fun takeDamage(damage: Int, fromX: Float, fromY: Float) {
        playerHealth -= damage
        onHealthChanged?.invoke(playerHealth)

        if (playerHealth <= 0) {
            playerHealth = 0
            deaths++
            onDeath?.invoke()
            audio.speak("You were killed.")
        } else {
            val dir = compassDirection(
                Math.toDegrees(atan2((fromX - playerX).toDouble(),
                    (fromY - playerY).toDouble())).toFloat()
            )
            audio.speak("Hit from the $dir! Health ${playerHealth}.")
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // ENEMY AI
    // ─────────────────────────────────────────────────────────────────────

    private fun spawnEnemies(mode: GameMode) {
        val count = when (mode) {
            GameMode.DEATHMATCH -> 8
            GameMode.TEAM_DEATHMATCH -> 5
            GameMode.BATTLE_ROYALE -> 20
            GameMode.SURVIVAL -> 10
            GameMode.CAPTURE_FLAG -> 6
        }
        repeat(count) { i ->
            val x = Random.nextFloat() * ARENA_SIZE
            val y = Random.nextFloat() * ARENA_SIZE
            enemies.add(
                Enemy(
                    id = "enemy_$i",
                    x = x, y = y,
                    health = 100,
                    isAlive = true,
                    angle = Random.nextFloat() * 360f,
                    aggroRange = 20f,
                    isBot = true
                )
            )
        }
        // Start footstep audio for each enemy
        enemies.forEach { enemy ->
            val streamId = audio.playSound3D(
                "sounds/ambient/footstep_enemy.ogg",
                enemy.x, enemy.y, loop = true
            )
            enemyAudioStreams[enemy.id] = streamId
        }
    }

    private fun startEnemyLoop() {
        enemyJob = gameScope.launch {
            while (isRunningGame) {
                delay(ENEMY_UPDATE_MS)
                updateEnemies()
            }
        }
    }

    private fun updateEnemies() {
        enemies.filter { it.isAlive }.forEach { enemy ->
            val dist = distanceTo(enemy)

            // Aggro — move toward player if in range
            if (dist < enemy.aggroRange && dist > 2f) {
                val angleToPlayer = Math.toDegrees(
                    atan2((playerX - enemy.x).toDouble(), (playerY - enemy.y).toDouble())
                ).toFloat()
                val speed = 1.5f * (ENEMY_UPDATE_MS / 1000f)
                enemy.x += sin(Math.toRadians(angleToPlayer.toDouble())).toFloat() * speed
                enemy.y += cos(Math.toRadians(angleToPlayer.toDouble())).toFloat() * speed
                enemy.x = enemy.x.coerceIn(0f, ARENA_SIZE)
                enemy.y = enemy.y.coerceIn(0f, ARENA_SIZE)

                // Update footstep audio position
                enemyAudioStreams[enemy.id]?.let { audio.updateSoundPosition(it, enemy.x, enemy.y) }

                // Fire at player
                if (dist < enemy.aggroRange * 0.7f && Random.nextFloat() < 0.1f) {
                    takeDamage(Random.nextInt(10, 25), enemy.x, enemy.y)
                    audio.playSound3D("sounds/weapons/ak47_fire.ogg", enemy.x, enemy.y)
                }

                onEnemyNearby?.invoke(enemy, dist)
            } else {
                // Random patrol
                enemy.x += (Random.nextFloat() - 0.5f) * 0.5f
                enemy.y += (Random.nextFloat() - 0.5f) * 0.5f
                enemy.x = enemy.x.coerceIn(0f, ARENA_SIZE)
                enemy.y = enemy.y.coerceIn(0f, ARENA_SIZE)
                enemyAudioStreams[enemy.id]?.let { audio.updateSoundPosition(it, enemy.x, enemy.y) }
            }
        }
    }

    private fun updateEnemyAudio() {
        enemies.filter { it.isAlive }.forEach { enemy ->
            enemyAudioStreams[enemy.id]?.let { audio.updateSoundPosition(it, enemy.x, enemy.y) }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // FOOTSTEPS
    // ─────────────────────────────────────────────────────────────────────

    private fun playFootstep() {
        val asset = if (isCrouching) "sounds/ambient/footstep_crouch.ogg"
        else "sounds/ambient/footstep.ogg"
        audio.playUI(asset, if (isCrouching) 0.3f else 0.6f)
    }

    // ─────────────────────────────────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────────────────────────────────

    fun distanceTo(enemy: Enemy) =
        sqrt((enemy.x - playerX).pow(2) + (enemy.y - playerY).pow(2))

    fun angleToEnemy(enemy: Enemy) =
        Math.toDegrees(atan2((enemy.x - playerX).toDouble(), (enemy.y - playerY).toDouble())).toFloat()

    private fun announceDirection() {
        // Only announce every ~45 degrees to avoid spam
        val sector = (playerAngle / 45).toInt() * 45
        if (sector % 45 == 0) audio.speak(compassDirection(playerAngle), interrupt = false)
    }

    fun compassDirection(angle: Float): String {
        val a = ((angle % 360) + 360) % 360
        return when {
            a < 22.5 || a >= 337.5 -> "North"
            a < 67.5  -> "Northeast"
            a < 112.5 -> "East"
            a < 157.5 -> "Southeast"
            a < 202.5 -> "South"
            a < 247.5 -> "Southwest"
            a < 292.5 -> "West"
            else       -> "Northwest"
        }
    }

    fun respawn() {
        playerHealth = MAX_HEALTH
        playerX = Random.nextFloat() * ARENA_SIZE
        playerY = Random.nextFloat() * ARENA_SIZE
        audio.listenerX = playerX; audio.listenerY = playerY
        audio.speak("Respawned. Health 100.")
        onHealthChanged?.invoke(playerHealth)
    }

    fun respawnAt(x: Float, y: Float) {
        playerHealth = MAX_HEALTH
        playerX = x; playerY = y
        audio.listenerX = x; audio.listenerY = y
        onHealthChanged?.invoke(playerHealth)
    }

    fun getAliveEnemyCount() = enemies.count { it.isAlive }
}

// ── Data classes ──────────────────────────────────────────────────────────────

data class Enemy(
    val id: String,
    var x: Float,
    var y: Float,
    var health: Int,
    var isAlive: Boolean,
    var angle: Float,
    val aggroRange: Float,
    val isBot: Boolean,
    var name: String = "Enemy"
)

enum class GameMode(val displayName: String) {
    DEATHMATCH("Deathmatch"),
    TEAM_DEATHMATCH("Team Deathmatch"),
    BATTLE_ROYALE("Battle Royale"),
    SURVIVAL("Survival"),
    CAPTURE_FLAG("Capture the Flag")
}
