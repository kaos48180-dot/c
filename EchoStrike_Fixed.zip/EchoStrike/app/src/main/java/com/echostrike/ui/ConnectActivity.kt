package com.echostrike.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.echostrike.network.NetworkManager

/**
 * A normal on-screen sign-in form (works with TalkBack - every field has a label and a hint).
 *
 *  Server address  (example 100.64.1.2  or  192.168.1.20  or  myserver.com:17550)
 *  Player name     (shown to other players)
 *  Username + password (only needed when the server asks for an account)
 *  "Create a new account" check box
 *  Connect button
 *
 * The last 5 servers are remembered so you only type them once.
 */
class ConnectActivity : AppCompatActivity() {

    private lateinit var network: NetworkManager
    private lateinit var status: TextView
    private lateinit var connect: Button
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        network = NetworkManager.shared(this)
        val prefs = getSharedPreferences("echostrike", MODE_PRIVATE)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(20), px(20), px(20))
            setBackgroundColor(Color.BLACK)
        }
        fun label(t: String) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 16f
            setPadding(0, px(14), 0, px(2))
        }
        fun field(hintText: String, value: String, type: Int) = EditText(this).apply {
            hint = hintText; setText(value); inputType = type
            setTextColor(Color.WHITE); setHintTextColor(0xFF9E9E9E.toInt()); textSize = 18f
            minHeight = px(52)
            contentDescription = hintText
        }

        col.addView(TextView(this).apply {
            text = "Connect to a server"; setTextColor(Color.WHITE); textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
            isFocusable = true
        })

        col.addView(label("Server address"))
        val address = field("Example 192.168.1.20 or 100.64.1.2", prefs.getString("last_server", "") ?: "",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI)
        col.addView(address)

        val saved = (prefs.getString("saved_servers", "") ?: "").split("\n").filter { it.isNotBlank() }
        if (saved.isNotEmpty()) {
            col.addView(label("Saved servers"))
            val spinner = Spinner(this)
            val items = listOf("Choose a saved server") + saved
            spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    if (pos > 0) address.setText(items[pos])
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            col.addView(spinner)
        }

        col.addView(label("Player name"))
        val name = field("Name other players will hear", prefs.getString("display_name", "Chaos") ?: "Chaos",
            InputType.TYPE_CLASS_TEXT)
        col.addView(name)

        col.addView(label("Account (only if the server needs one)"))
        val user = field("Username", prefs.getString("last_user", "") ?: "",
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS)
        col.addView(user)
        val pass = field("Password", "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        pass.imeOptions = EditorInfo.IME_ACTION_GO
        col.addView(pass)
        val create = CheckBox(this).apply {
            text = "Create a new account with this username and password"
            setTextColor(Color.WHITE); textSize = 16f
        }
        col.addView(create)

        status = TextView(this).apply {
            setTextColor(0xFFFFD54F.toInt()); textSize = 16f
            setPadding(0, px(14), 0, px(6))
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        col.addView(status)

        connect = Button(this).apply { text = "Connect"; textSize = 20f; minHeight = px(60) }
        col.addView(connect, LinearLayout.LayoutParams(-1, -2))
        val back = Button(this).apply { text = "Back to menu"; textSize = 16f }
        back.setOnClickListener { finish() }
        col.addView(back, LinearLayout.LayoutParams(-1, -2))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.BLACK); isFillViewport = true; addView(col)
        })

        val go = {
            if (!busy) {
                val addr = address.text.toString().trim()
                val nick = name.text.toString().trim().take(20).ifEmpty { "Chaos" }
                val u = user.text.toString().trim()
                val p = pass.text.toString()
                when {
                    addr.isEmpty() -> say("Type the server address first.")
                    u.isNotEmpty() && p.isEmpty() -> say("Type your password, or clear the username to join as a guest.")
                    create.isChecked && (u.isEmpty() || p.isEmpty()) -> say("To create an account, type a username and a password.")
                    else -> {
                        busy = true; connect.isEnabled = false
                        say("Connecting to $addr. Please wait.")
                        prefs.edit().putString("display_name", nick).putString("last_server", addr)
                            .putString("last_user", u).apply()
                        network.join(
                            host = addr, displayName = nick,
                            user = u.ifEmpty { null }, pass = p, register = create.isChecked,
                            onConnected = {
                                remember(addr)
                                runOnUiThread {
                                    busy = false
                                    startActivity(Intent(this, GameActivity::class.java).putExtra("isHost", false))
                                    finish()
                                }
                            },
                            onRejected = { reason ->
                                runOnUiThread {
                                    busy = false; connect.isEnabled = true
                                    say("Could not connect. $reason")
                                }
                            }
                        )
                    }
                }
            }
        }
        connect.setOnClickListener { go() }
        pass.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_GO) { go(); true } else false }
    }

    private fun say(text: String) {
        status.text = text
        status.announceForAccessibility(text)
    }

    private fun remember(addr: String) {
        val prefs = getSharedPreferences("echostrike", MODE_PRIVATE)
        val list = (prefs.getString("saved_servers", "") ?: "").split("\n").filter { it.isNotBlank() && it != addr }
        prefs.edit().putString("saved_servers", (listOf(addr) + list).take(5).joinToString("\n")).apply()
    }
}
