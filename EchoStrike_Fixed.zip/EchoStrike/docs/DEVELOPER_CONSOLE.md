# Developer Console (v1.2)

The console is an admin tool for YOUR EchoStrike Server (the server app). No admin token is used.

1. In the **Server app**: "Your developer account" -> type a username and password -> Save. Turn on "Require an account to join" and start the server.
2. In the **Developer Console**: type the server address, your developer username and password, tap Sign in. They are remembered on that phone, so it signs in by itself next time.
3. Tools: status, who is online, kick, say to everyone, accounts, delete account, and approving admin requests.

Players make their own accounts in the game: Play Online -> Create account and play. A player can tap "Ask for admin access"; the request shows in the server app and the console, and you approve or deny it.
Admins can also type chat commands in the game: /who, /kick name, /say message.

The old Fly.io cloud server files (cloud-server, fly.toml, deploy workflow) are no longer needed for the main world.
