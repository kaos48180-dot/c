# EchoStrike two-app build and developer console

The Android build workflow produces two APKs:

- `app-debug.apk`: EchoStrike player client.
- `developer-console-debug.apk`: developer-only utility to configure the main account on the cloud server.

## Server setup (optional - only for cloud play)

1. Choose a unique app name in `fly.toml` before deployment.
2. Create the Fly.io app once using Fly's official setup instructions.
3. Edit `.github/workflows/deploy-cloud-server.yml` and replace `echostrike-change-this-name` in `FLY_APP_NAME` with the same unique name as `fly.toml`. Create a persistent volume in the same region as the app: `fly volumes create echostrike_data --region ord --size 1 -a YOUR_APP_NAME`. If you change `primary_region`, use that region instead.
4. Generate a long random admin token (at least 32 random bytes). Add it to GitHub repository Settings → Secrets and variables → Actions as `ADMIN_TOKEN`. Also add your Fly deploy token as `FLY_API_TOKEN`. Do not commit either token.
5. In GitHub Actions, run `Deploy EchoStrike cloud server`.
7. Set repository Actions variable `ECHO_SERVER_HOST` to `YOUR_APP_NAME.fly.dev`, then run the Android build workflow.

## Configure main account

1. Install the developer console APK only on the developer's device.
2. Open it and enter `https://YOUR_APP_NAME.fly.dev`, the same `ADMIN_TOKEN`, the account username (defaults to `Chaos`), and a new password of at least 12 characters.
3. Tap Save Main Account on Server. The server stores a salted scrypt password hash on the mounted persistent volume; the plaintext password is not written to disk by the server. The app clears the password and admin token fields after the request.
4. The player login endpoint is `POST /api/login` and accepts JSON `{"username":"Chaos","password":"..."}`. The player app's **Cloud Multiplayer** menu item signs in through this endpoint and joins with the returned session token.

## Important limitations

- This developer console is not a game server running on Android; the actual cloud server runs in Fly.io from `cloud-server/`.
- The console only configures a main account; it cannot create a cloud server from nothing. First-time hosting account setup, Fly app creation, persistent volume creation, and GitHub secrets are manual steps.
- Never put `ADMIN_TOKEN`, Fly API tokens, or passwords in source code or public repository files.
- Build and deploy are not verified from this environment. Confirm both workflows succeed before use.


## Cloud account sign-in and automatic game connection

The player APK is built with the hostname from `fly.toml` (or the optional Actions variable `ECHO_SERVER_HOST`). On first launch, select **Cloud Multiplayer**, enter the account configured here (default username `Chaos`) and its password. The server returns a revocable session token; the player app stores only that token in its app-private preferences, not the password. Later, choosing Cloud Multiplayer reuses the saved session. If the server restarts or the token expires, sign in again.

The cloud server only accepts TCP game handshakes that include a valid login session token. The developer console's `ADMIN_TOKEN` authorizes account configuration and must be a strong secret stored only in GitHub Actions secrets and entered privately into the developer console. Never commit it to the repository or include it in the player APK.

**Build and deployment are not proof of a successful public connection.** Verify both GitHub Actions workflows and test the deployed host on a real Android device. This is a starter multiplayer server, not yet a production-grade anti-cheat or authoritative survival-game simulation.
