# EchoStrike audio assets (UI and footsteps)

This project currently contains menu sounds under `app/src/main/assets/sounds/menu/`. The movement code also expects these assets, which were missing from the supplied project:

- `app/src/main/assets/sounds/ambient/footstep.ogg`
- `app/src/main/assets/sounds/ambient/footstep_crouch.ogg`

## Free sound sources

Use only files whose licence page clearly permits game use. These sources offer CC0/public-domain audio:

- **UI buttons, menu clicks, confirm/cancel:** [Kenney UI Audio](https://kenney.nl/assets/ui-audio) — CC0.
- **More interface buttons and toggles:** [Kenney Interface Sounds](https://kenney.nl/assets/interface-sounds) — CC0.
- **Footsteps only:** [OpenGameArt — Footsteps by GboxMikeFozzy](https://opengameart.org/content/footsteps-0) — marked CC0, with six OGG files.

Recheck the licence on the source page when downloading. Do not copy random sounds from videos, streaming sites, or other games.

## Add the footsteps

1. Download two of the OGG files from the OpenGameArt footsteps page.
2. Rename one to `footstep.ogg` and the other to `footstep_crouch.ogg`.
3. Upload them to `app/src/main/assets/sounds/ambient/` in this repository.
4. Commit the files and run **Actions → Build EchoStrike Android APK**.

The game currently plays these files through `GameEngine.playFootstep()`. The crouched step is played at a lower volume.

## Replace menu sounds

1. Download Kenney's UI Audio pack from its official page.
2. Preview the files and choose the UI effects you want (click, focus, confirm, cancel, toggle).
3. Copy selected OGG files into `app/src/main/assets/sounds/menu/` and use the filenames expected by `EchoAudioEngine.kt`, or update that file to match the new filenames.
4. Keep a note of the source and licence in this file. Kenney's pack is CC0; attribution is not required.

This setup guide links to the sources but does not claim the downloaded packs are already bundled in this ZIP. No new third-party audio files were downloaded into this environment.
