# EchoStrike cloud server and two-APK setup

This project builds **two Android APKs** and includes a standalone Node.js cloud server. The player app defaults to the display name `Chaos`. After the first successful sign-in, it stores a revocable session token locally and automatically attempts to reconnect on later launches.

The server is a starter implementation compatible with EchoStrike's basic v2 newline-JSON TCP protocol. It supports session login, basic join/leave, chat, firing-event broadcast, simple leaderboard responses, and UDP position updates. It is not a production-grade authoritative survival game server or anti-cheat system; full combat/physics/gameplay authority still needs development and multi-device testing.

## What gets built

- `app/`: EchoStrike player APK.
- `developer-console/`: separate developer-only APK for setting the main account.
- `cloud-server/`: standalone Node.js TCP/UDP server plus HTTPS-proxied account API.
- `.github/workflows/deploy-cloud-server.yml`: creates/configures the Fly app, creates the persistent data volume if needed, and deploys the server.
- `.github/workflows/android-build.yml`: builds both APKs and automatically derives the server hostname from `fly.toml`.

## One-time setup from the beginning

1. Create a GitHub repository and upload the **contents** of this project folder to the repository root.
2. Create a Fly.io account at `https://fly.io/` and review its current pricing. Hosting is not guaranteed to be free; a running server can incur charges.
3. Edit `fly.toml` once. Replace `echostrike-change-this-name` with a globally unique Fly app name, for example `echostrike-chaos-4821` (choose a name that is available). The app name is used to derive the hostname `<app-name>.fly.dev`; do not put `https://` in the app name.
4. In Fly.io, create a deploy token using the documented `flyctl` command for your account. For example, after installing `flyctl` and signing in: `fly tokens create deploy -a YOUR_APP_NAME -x 720h`. Keep the token private.
5. In GitHub, open **Settings → Secrets and variables → Actions → New repository secret**. Add:
   - `FLY_API_TOKEN`: the Fly deployment token.
   - `ADMIN_TOKEN`: a strong random secret of at least 32 characters. Keep a private copy because you will enter it into the developer console.
6. Commit and push the project to `main` (or `master`). The deployment workflow will create the Fly app if needed, create the persistent volume if needed, set the admin secret, and deploy the server. The Android workflow builds both APKs with the hostname derived from `fly.toml`. The workflows run separately, so check that **both** Actions runs succeed.
7. Open the Fly dashboard and confirm the server is healthy. Its HTTPS admin/login base address is `https://YOUR_APP_NAME.fly.dev`; the game connection uses TCP `17550` and UDP `17551`. If Fly reports that UDP networking or public addresses need additional setup, follow Fly's current networking instructions and pricing before proceeding.
8. In the successful Android workflow run, download the artifact named `EchoStrike-and-Developer-Console-APKs` and extract both APKs.
9. Install **EchoStrike Developer Console** on your developer phone. Enter:
   - Server address: `https://YOUR_APP_NAME.fly.dev`
   - Admin token: the exact `ADMIN_TOKEN` GitHub secret value
   - Main account username: `Chaos` (or choose another allowed username)
   - Main account password: choose a strong password of at least 12 characters
   Tap **Save Main Account on Server**. A success message confirms the server accepted it.
10. Install **EchoStrike**. On first use, choose **Cloud Multiplayer**, enter the main account username and password, and sign in. The game should then connect to the server. The app stores only the session token in its private app storage, not the password. On later launches it automatically attempts to reconnect. If the server restarts or the session expires, sign in again.
11. Install the player APK on a second device and sign in with the configured account if the server's single-main-account setup is intended for testing. This starter's single account is for basic validation, not a full player account system. Test chat and movement and inspect server logs before relying on it.

## Updating the project

- Pushing changes to `cloud-server/` or `fly.toml` triggers server deployment.
- Pushing changes to the Android source triggers the APK build workflow.
- The Android workflow derives the hostname from `fly.toml`, so you do not need a separate `ECHO_SERVER_HOST` variable unless you deliberately want to override the hostname.

## Security and known limits

- Never commit `FLY_API_TOKEN`, `ADMIN_TOKEN`, passwords, or keystore credentials.
- The developer console uses `ADMIN_TOKEN` only for the private account-configuration endpoint. The player app never contains that admin token.
- Login returns a revocable session token that is held in server memory. Server restart invalidates existing sessions; the player app should ask the user to sign in again.
- This implementation is a starting point, not a full PlayFab integration and not a production-ready authoritative survival-game server. It still needs thorough Android builds, multiplayer testing, rate limiting, anti-cheat, authoritative damage/health rules, and load testing.
