# Task prompt for a coding agent

Use this prompt in GitHub Copilot Chat/agent mode from the EchoStrike repository after opening a Codespace. Review the actual source and make changes in small, testable steps. This is a development task request, not proof that a server already exists.

> Inspect EchoStrike's current networking implementation and create a separate, platform-neutral JVM server module suitable for running outside Android. Preserve the existing TCP/UDP protocol only where the protocol can be documented and tested. Remove all Android-only dependencies from the new server module. Add unit tests for handshake, joining/leaving, player updates, room handling, and malformed messages. Add a Dockerfile and a server-only build/test script. Make host and port configurable by environment variables, bind to 0.0.0.0, and implement graceful shutdown. Update the Android client so a user can enter a remote server host instead of relying on LAN broadcast discovery. Keep LAN discovery for local play if it still works. Do not add secrets to source. Do not claim deployment is complete: first make the module build and tests pass, then document the chosen hosting provider and deployment secrets needed. Add a separate GitHub Actions workflow that builds and tests the server container, but do not deploy to a provider until its endpoint and credentials are explicitly configured. Update the documentation with exact setup and test commands.

## Review checklist

- [ ] Server module builds without Android SDK classes.
- [ ] Automated tests pass.
- [ ] Docker image builds.
- [ ] Android app can connect using a configurable public endpoint.
- [ ] TCP/UDP ports and hosting requirements are documented.
- [ ] No credentials are committed.
- [ ] A real remote smoke test is documented and passed before calling it connected.
