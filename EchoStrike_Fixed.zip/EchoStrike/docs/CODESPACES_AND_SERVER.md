# Use GitHub Codespaces and GitHub Actions

## Open a Codespace

1. Push the contents of this project folder to the root of a GitHub repository (do not upload only a ZIP).
2. On the repository page, choose **Code → Codespaces → Create codespace on main**.
3. Codespaces will read `.devcontainer/devcontainer.json` and install Java 17, Gradle, Docker tooling, and the listed editor extensions.
4. In the Codespaces terminal, run:

   ```bash
   gradle --version
   gradle assembleDebug
   ```

5. Commit any changes with Source Control and push them to GitHub.

## Build the APK with Actions

1. Open the repository's **Actions** tab.
2. Select **Build EchoStrike Android APK**.
3. Choose **Run workflow**, or push a commit to `main`/`master`.
4. When the run succeeds, open it and download the `EchoStrike-debug-APK` artifact.

## Important server limitation

Codespaces does not automatically create and host a persistent public game server, and a workflow cannot safely invent a compatible server from the Android app. The current `EmbeddedGameServer.kt` depends on Android APIs and is designed to run inside the APK. It must be refactored into a separate platform-neutral server before a Docker image can be built and deployed.

The `.github/copilot-instructions.md` file provides implementation requirements for a coding agent to follow when asked to do that work. After the standalone server compiles and passes tests, add a separate server-container workflow and choose a hosting provider. Public internet hosting requires a provider, a configured endpoint, appropriate TCP/UDP support, and possibly billing. Port forwarding in Codespaces is for development/testing, not reliable permanent hosting.

Do not place PlayFab Developer Secret Keys, passwords, or private signing keys in the repository. Store deployment credentials in **Settings → Secrets and variables → Actions**.
