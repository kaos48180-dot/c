# EchoStrike repository instructions for coding agents

When asked to implement the cloud multiplayer server:

1. Inspect `app/src/main/java/com/echostrike/server/EmbeddedGameServer.kt`, `EmbeddedGameClient.kt`, and `NetworkManager.kt` before editing.
2. Do not claim the Android-hosted server is cloud-hostable: `EmbeddedGameServer` imports Android APIs and must not be launched as a desktop/cloud JVM process unchanged.
3. Create a separate platform-neutral JVM server module that preserves the existing wire protocol only after documenting and testing the protocol. Do not copy Android `Context`, `WifiManager`, `Log`, `APKValidator`, or `Intent` dependencies into the server module.
4. Create a Dockerfile and server build script only after the standalone module compiles. Bind to `0.0.0.0`, use a configurable port, implement graceful shutdown, and add protocol/unit tests.
5. Make the Android client endpoint configurable using a non-secret server URL/host setting. Do not hard-code a developer machine's IP or treat LAN broadcast discovery as internet discovery.
6. Never put credentials, PlayFab Developer Secret Keys, signing keys, or passwords in source code, artifacts, or logs. Store deployment secrets in GitHub Actions secrets.
7. Do not claim a cloud server is deployed until a real host is configured and a smoke test connects to it. GitHub Codespaces is a development environment, not a permanently running production host.
8. Keep the Android build workflow separate from server container build/deploy workflows. Deploy only when the repository has a working standalone server and an explicitly configured host.
9. Add tests and update `docs/FREE_MULTIPLAYER_SETUP.md` with the exact commands and required account/host setup. If an implementation detail is unknown, report it rather than inventing it.
