# EchoStrike v1.1 — phone-only build (three apps)

You get three apps from ONE zip and ONE workflow file:

| App | Install it on | What it does |
|---|---|---|
| **EchoStrike-Player.apk** | every player's phone | The game. Offline mode, Connect to Server sign-in form, host, LAN, chat. |
| **EchoStrike-Server.apk** | a spare phone or tablet (plugged in, on WiFi) | Runs the main world 24/7 where everyone walks around and shoots each other. Bots and accounts are optional. |
| **EchoStrike-Developer-Console.apk** | your phone (optional) | Admin tool for the cloud server. |

## Your part (same as before)
1. New or existing repository -> upload `EchoStrike_Fixed.zip` (do not unzip). When updating, delete the old zip first.
2. Create/replace `.github/workflows/build.yml` with the text of `BUILD_WORKFLOW.yml`.
3. Actions -> **Build EchoStrike (Player + Developer Console + Server)** -> Run workflow. Type a release tag like `v1.1` to get the three APKs under Releases.
4. Install over the old apps (same signing key, nothing is lost).

## Run the main server
1. Install EchoStrike-Server on the spare phone/tablet, open it, press **Start server**.
2. Choose bots (0 = none), difficulty, and whether players need accounts.
3. Players: Player app -> **Connect to Server** -> type the address the server app shows.
   - Same WiFi: use the 192.168.x.x address. Different places: install Tailscale on the server and every player and use the 100.x.x.x address (free, no card).
4. Leave the server device plugged in with battery optimisation off.

## Playing
- **Play Offline**: bots on your phone, no internet. Bots/difficulty are in Settings.
- Chat (online only): 4 fingers swipe left/right = choose phrase, up = send, down = speak a message; 3 fingers swipe left = read last messages.

See `docs/DEVELOPER_CONSOLE.md` for the optional cloud server. The signing key is public by design; do not reuse it elsewhere.
