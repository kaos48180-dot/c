# EchoStrike — phone-only build in 4 steps

1. Create a new GitHub repository and upload `EchoStrike_Fixed.zip` to it (do not unzip it).
2. In the repository choose Add file → Create new file. Name it `.github/workflows/build.yml` and paste the contents of `BUILD_WORKFLOW.yml` (it is inside this zip too; the same text was sent in chat).
3. Open the Actions tab → Build EchoStrike (both APKs) → Run workflow. (Optional: type a release tag such as `v1.0` to publish both APKs under Releases.)
4. When it finishes, open the run and download the `EchoStrike-APKs` artifact (or the Release files). Install **both** apps from the same build:
   - `EchoStrike-Player.apk` — the game
   - `EchoStrike-Developer-Console.apk` — admin tool

Both apps are signed with the same key (`signing/echostrike-shared.keystore`), so new builds install over old ones and the player app can verify the console.

## How the console connects to the game
- The console is pre-filled with the server name baked into the build, remembers the address you used, and has buttons to test the server, check your admin token, save the main account, and **send the server address to the EchoStrike app** (the game only accepts it from the console signed with the same key).
- Playing on your WiFi / phone-hosted games needs no server at all: Host Game / Find LAN Game / Join by Address.

## Notes
- The signing key is included so builds stay compatible. If your repository is public, that key is public too — fine for a personal game, but do not reuse it for anything sensitive.
- The cloud server (Fly.io) is optional; see `docs/DEVELOPER_CONSOLE.md`.
- Weapon, footstep and hit sounds are generated in code if no sound files exist under `app/src/main/assets/sounds/weapons|ambient`. Add real files with the same names to override them.
