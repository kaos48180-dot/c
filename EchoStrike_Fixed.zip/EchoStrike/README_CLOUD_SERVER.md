# EchoStrike cloud multiplayer setup

Follow [`docs/CLOUD_SERVER_DEPLOYMENT.md`](docs/CLOUD_SERVER_DEPLOYMENT.md) from top to bottom. The deployment requires a Fly.io account and a GitHub Actions secret named `FLY_API_TOKEN`. After the first server deployment, set the GitHub Actions variable `ECHO_SERVER_HOST` to the app's `YOUR_APP_NAME.fly.dev` hostname and build the APK again. The main menu's **Cloud Multiplayer** item then uses that configured server.

This is an initial protocol-compatible server starter, not a completed or verified production multiplayer backend. It does not validate the APK signing token and is not an anti-cheat system. Review provider pricing before deploying; a continuously running cloud VM may cost money.


## Two APKs: player app and developer console

The Android workflow builds both `app-debug.apk` (player client) and `developer-console-debug.apk` (developer-only account configuration utility). Read `docs/DEVELOPER_CONSOLE.md` for deployment, secret setup, and account configuration. The developer console requires the cloud server's `ADMIN_TOKEN` secret.
