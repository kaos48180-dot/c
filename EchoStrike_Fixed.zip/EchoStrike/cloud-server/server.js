'use strict';
const net = require('node:net');
const dgram = require('node:dgram');
const crypto = require('node:crypto');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const TCP_PORT = Number(process.env.TCP_PORT || 17550);
const UDP_PORT = Number(process.env.UDP_PORT || 17551);
const MAX_PLAYERS = Number(process.env.MAX_PLAYERS || 16);
const MAGIC = 'ECHO2025';
const VERSION = 2;
const players = new Map();
const rooms = new Map();
const sessions = new Map(); // bearer tokens issued by /api/login; memory-only and invalidated on restart
let nextId = 1;

function send(player, obj) {
  if (!player || player.socket.destroyed) return;
  player.socket.write(JSON.stringify(obj) + '\n');
}
function roomPlayers(room) { return [...players.values()].filter(p => p.room === room); }
function broadcast(room, obj, excludeId) {
  for (const p of roomPlayers(room)) if (p.id !== excludeId) send(p, obj);
}
function reject(socket, reason) { socket.write(JSON.stringify({type:'rejected', reason})+'\n'); socket.end(); }
function jsonLine(socket, line) {
  let msg; try { msg = JSON.parse(line); } catch { return; }
  let p = socket.player;
  if (!p) {
    if (msg.magic !== MAGIC) return reject(socket, 'Bad magic — wrong app?');
    if (Number(msg.ver) !== VERSION) return reject(socket, 'Version mismatch — update your game');
    if (players.size >= MAX_PLAYERS) return reject(socket, `Server full (${MAX_PLAYERS} max)`);
    const authToken = String(msg.authToken || '');
    const session = sessions.get(authToken);
    if (!session || session.expiresAt < Date.now()) {
      sessions.delete(authToken);
      return reject(socket, 'Login required or session expired. Return to the app and sign in again.');
    }
    const id = 'P' + nextId++;
    p = { id, name: String(msg.name || session.username || 'Player').slice(0,20), username: session.username, room: String(msg.room || 'default'),
          x: 0, y: 0, a: 0, hp: 100, score: 0, socket };
    socket.player = p; players.set(id, p);
    send(p, {type:'welcome', id, room:p.room, tickHz:20, serverIp:process.env.PUBLIC_HOST || ''});
    broadcast(p.room, {type:'player_joined', id, name:p.name}, id);
    console.log(`join ${p.name} ${id} room=${p.room} players=${players.size}`);
    return;
  }
  switch (msg.type) {
    case 'ping': send(p, {type:'pong', ts:msg.ts || Date.now()}); break;
    case 'chat': {
      const text = String(msg.text || '').slice(0,500);
      broadcast(p.room, {type:'chat', id:p.id, name:p.name, text, ts:Date.now()});
      break;
    }
    case 'fire': {
      p.x = Number(msg.x || p.x); p.y = Number(msg.y || p.y); p.a = Number(msg.a || p.a);
      broadcast(p.room, {type:'player_fired', id:p.id, x:p.x, y:p.y, a:p.a, weapon:String(msg.weapon || 'unknown').slice(0,40), hit:false});
      break;
    }
    case 'leaderboard': {
      const entries = roomPlayers(p.room).map(x => ({name:x.name, score:x.score})).sort((a,b)=>b.score-a.score).slice(0,20);
      send(p, {type:'leaderboard', entries}); break;
    }
    case 'friend_request': send(p, {type:'friend_request_result', ok:false, reason:'Friend requests are not implemented on the cloud starter server.'}); break;
  }
}
const tcp = net.createServer(socket => {
  socket.setNoDelay(true);
  socket.setTimeout(120000);
  let buf = '';
  socket.on('data', data => {
    buf += data.toString('utf8');
    if (buf.length > 65536) { socket.destroy(); return; }
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0,i).trim(); buf = buf.slice(i+1);
      if (line) jsonLine(socket, line);
    }
  });
  socket.on('timeout', () => socket.destroy());
  socket.on('error', err => console.warn('tcp socket:', err.message));
  socket.on('close', () => {
    const p = socket.player;
    if (p) { players.delete(p.id); broadcast(p.room, {type:'player_left', id:p.id, name:p.name}); console.log(`left ${p.name} ${p.id}`); }
  });
});
const udp = dgram.createSocket('udp4');
udp.on('message', (data, rinfo) => {
  let msg; try { msg = JSON.parse(data.toString('utf8')); } catch { return; }
  if (msg.pid) {
    const p = players.get(String(msg.pid));
    if (p) { p.x = Number(msg.x || 0); p.y = Number(msg.y || 0); p.a = Number(msg.a || 0); }
  }
});
// Match the Android client’s expected 20 Hz world-state UDP snapshots.
setInterval(() => {
  const byRoom = new Map();
  for (const p of players.values()) {
    if (!byRoom.has(p.room)) byRoom.set(p.room, []);
    byRoom.get(p.room).push({id:p.id, x:p.x, y:p.y, a:p.a, hp:p.hp});
  }
  for (const [room, state] of byRoom) {
    const payload = Buffer.from(JSON.stringify({type:'world_state', ts:Date.now(), players:state}));
    // Clients send UDP packets to the server from ephemeral ports. Track each TCP client’s last UDP source after position packets.
    for (const p of roomPlayers(room)) if (p.udpAddress && p.udpPort) udp.send(payload, p.udpPort, p.udpAddress);
  }
}, 50).unref();
// The legacy Android client does not send an explicit UDP registration; infer the player by the PID in position packets.
// Keep this server starter simple and safe: UDP positions are received, but outbound snapshots need explicit client registration.
udp.on('message', (data, rinfo) => {
  try { const msg=JSON.parse(data.toString('utf8')); if (msg.pid) { const p=players.get(String(msg.pid)); if(p){p.udpAddress=rinfo.address;p.udpPort=rinfo.port;} } } catch {}
});

// Private developer API. Exposed through the hosting provider's HTTPS proxy.
// The admin token must be configured as a hosting secret; never commit it.
const HTTP_PORT = Number(process.env.HTTP_PORT || 8080);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const ACCOUNT_FILE = process.env.ACCOUNT_FILE || '/data/main-account.json';
let mainAccount = null;
try { mainAccount = JSON.parse(fs.readFileSync(ACCOUNT_FILE, 'utf8')); } catch {}
function sendHttp(res, code, body) {
  res.writeHead(code, {'content-type':'application/json; charset=utf-8', 'cache-control':'no-store', 'access-control-allow-origin':'null'});
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data=''; req.on('data', chunk => { data += chunk; if (data.length > 8192) { reject(new Error('body too large')); req.destroy(); } });
    req.on('end', () => { try { resolve(JSON.parse(data || '{}')); } catch { reject(new Error('invalid JSON')); } });
    req.on('error', reject);
  });
}
function isAdmin(req) {
  if (!ADMIN_TOKEN) return false;
  const value = req.headers.authorization || '';
  const expected = 'Bearer ' + ADMIN_TOKEN;
  return value.length === expected.length && crypto.timingSafeEqual(Buffer.from(value), Buffer.from(expected));
}
function saveAccount(account) {
  fs.mkdirSync(path.dirname(ACCOUNT_FILE), {recursive:true});
  const temp = ACCOUNT_FILE + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(account), {mode:0o600});
  fs.renameSync(temp, ACCOUNT_FILE);
}
const adminHttp = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') { res.writeHead(204, {'access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'content-type,authorization'}); return res.end(); }
  if (req.method === 'GET' && req.url === '/health') return sendHttp(res, 200, {ok:true, service:'EchoStrike cloud server'});
  if (req.method === 'GET' && req.url === '/admin/account' ) {
    if (!isAdmin(req)) return sendHttp(res, 401, {ok:false, error:'Unauthorized'});
    return sendHttp(res, 200, {ok:true, username:mainAccount?.username || 'Chaos', configured:!!mainAccount});
  }
  if (req.method === 'POST' && req.url === '/admin/account') {
    if (!isAdmin(req)) return sendHttp(res, 401, {ok:false, error:'Unauthorized'});
    try {
      const body = await readBody(req);
      const username = String(body.username || '').trim();
      const password = String(body.password || '');
      if (!/^[A-Za-z0-9_. -]{3,32}$/.test(username)) return sendHttp(res, 400, {ok:false,error:'Username must be 3-32 simple characters.'});
      if (password.length < 12 || password.length > 256) return sendHttp(res, 400, {ok:false,error:'Password must be at least 12 characters.'});
      const salt = crypto.randomBytes(16);
      const hash = crypto.scryptSync(password, salt, 64);
      mainAccount = {username, salt:salt.toString('hex'), hash:hash.toString('hex'), updatedAt:new Date().toISOString()};
      saveAccount(mainAccount);
      return sendHttp(res, 200, {ok:true, username, message:'Main account saved on server.'});
    } catch (e) { return sendHttp(res, 400, {ok:false,error:e.message || 'Invalid request'}); }
  }
  if (req.method === 'POST' && req.url === '/api/login') {
    try {
      const body = await readBody(req);
      if (!mainAccount) return sendHttp(res, 503, {ok:false,error:'Main account has not been configured by the developer.'});
      const username = String(body.username || ''); const password = String(body.password || '');
      const salt = Buffer.from(mainAccount.salt, 'hex');
      const expected = Buffer.from(mainAccount.hash, 'hex');
      const got = crypto.scryptSync(password, salt, expected.length);
      const ok = username === mainAccount.username && got.length === expected.length && crypto.timingSafeEqual(got, expected);
      if (!ok) return sendHttp(res, 401, {ok:false, error:'Invalid username or password'});
      const token = crypto.randomBytes(32).toString('hex');
      sessions.set(token, {username, expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000});
      return sendHttp(res, 200, {ok:true, username, token, expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000});
    } catch { return sendHttp(res, 400, {ok:false,error:'Invalid request'}); }
  }
  return sendHttp(res, 404, {ok:false,error:'Not found'});
});
adminHttp.listen(HTTP_PORT, '0.0.0.0', () => console.log(`EchoStrike HTTPS-proxied admin API listening on ${HTTP_PORT}`));

tcp.listen(TCP_PORT, '0.0.0.0', () => console.log(`EchoStrike TCP listening on ${TCP_PORT}`));
// Fly.io only delivers public UDP to sockets bound to the special 'fly-global-services' address.
const UDP_BIND = process.env.UDP_BIND || (process.env.FLY_APP_NAME ? 'fly-global-services' : '0.0.0.0');
udp.bind(UDP_PORT, UDP_BIND, () => console.log(`EchoStrike UDP listening on ${UDP_BIND}:${UDP_PORT}`));
process.on('SIGTERM', () => { tcp.close(); udp.close(); process.exit(0); });
