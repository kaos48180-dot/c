# EchoStrike setup summary

This repository contains a player Android app, a separate developer-console Android app, and a Node.js cloud server starter.

1. Set a globally unique app name in `fly.toml`.
2. Add GitHub Actions secrets `FLY_API_TOKEN` and `ADMIN_TOKEN`.
3. Push to `main`. Check both **Deploy EchoStrike cloud server** and **Build EchoStrike Android APK** workflows.
4. Download the `EchoStrike-and-Developer-Console-APKs` artifact from the Android workflow.
5. Use the developer console to configure the main account on the deployed server.
6. Sign in once from the player app; later launches automatically try to reconnect using its saved session token.

See `docs/CLOUD_SERVER_DEPLOYMENT.md` for complete steps and limitations. This is a development starter; successful cloud deployment and real-device multiplayer still need to be verified.
