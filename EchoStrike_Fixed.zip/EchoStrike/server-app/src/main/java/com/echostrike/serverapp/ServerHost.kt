package com.echostrike.serverapp

import android.content.Context
import android.content.SharedPreferences
import com.echostrike.game.BotBrain
import com.echostrike.server.AccountStore
import com.echostrike.server.EmbeddedGameServer
import com.echostrike.server.HostOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/** Holds the running server so the screen and the background service share it. */
object ServerHost {
    private const val MAX_LOG = 300

    @Volatile var server: EmbeddedGameServer? = null
        private set
    @Volatile var accounts: AccountStore? = null
        private set

    val isRunning: Boolean get() = server?.isRunning == true

    private val lines = ArrayDeque<String>()
    @Volatile var logListener: ((String) -> Unit)? = null
    private val clock = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun prefs(ctx: Context): SharedPreferences = ctx.applicationContext.getSharedPreferences("serverapp", Context.MODE_PRIVATE)

    fun accounts(ctx: Context): AccountStore =
        accounts ?: synchronized(this) {
            accounts ?: AccountStore(File(ctx.applicationContext.filesDir, "accounts.txt")).also { accounts = it }
        }

    @Synchronized fun log(msg: String) {
        val line = "${clock.format(Date())}  $msg"
        lines.addLast(line)
        while (lines.size > MAX_LOG) lines.removeFirst()
        logListener?.invoke(line)
    }

    @Synchronized fun allLog(): String = lines.joinToString("\n")

    fun buildOptions(ctx: Context): HostOptions {
        val p = prefs(ctx)
        return HostOptions(
            serverName = p.getString("name", "EchoStrike Server") ?: "EchoStrike Server",
            maxPlayers = p.getInt("max", 16).coerceIn(1, 32),
            botCount = p.getInt("bots", 0).coerceIn(0, 8),
            botDifficulty = BotBrain.Difficulty.fromLevel(p.getInt("difficulty", 2)),
            requireLogin = p.getBoolean("login", true),
            allowRegistration = p.getBoolean("register", true),
            accounts = accounts(ctx)
        )
    }

    /** Starts the game server using the saved settings. */
    fun start(ctx: Context) {
        if (isRunning) return
        val s = EmbeddedGameServer(ctx.applicationContext)
        s.options = buildOptions(ctx)
        s.onLog = { log(it) }
        server = s
        s.start(onError = { reason -> log("Could not start: $reason (is another server already using the ports?)") }) { ip, port ->
            log("Ready. Players connect to $ip port $port")
        }
    }

    fun stop() {
        server?.stop()
        server = null
    }
}
