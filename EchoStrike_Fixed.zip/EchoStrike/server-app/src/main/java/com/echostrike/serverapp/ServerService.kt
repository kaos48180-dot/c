package com.echostrike.serverapp

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager

/** Keeps the server running when the screen is off or the app is in the background. */
class ServerService : Service() {

    companion object {
        const val ACTION_START = "com.echostrike.serverapp.START"
        const val ACTION_STOP = "com.echostrike.serverapp.STOP"
        private const val CHANNEL = "echostrike_server"
        private const val NOTIF_ID = 2001
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            ServerHost.stop()
            ServerHost.log("Server stopped")
            releaseLock()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        createChannel()
        val open = PendingIntent.getActivity(this, 0, Intent(this, ServerActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ServerService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("EchoStrike Server is running")
            .setContentText("Players can connect. Tap to open.")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "Stop server", stop).build())
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, notif)
        acquireLock()
        ServerHost.start(this)
        return START_NOT_STICKY
    }

    private fun acquireLock() {
        if (wakeLock == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "echostrike:server").apply { acquire() }
        }
    }

    private fun releaseLock() {
        try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Exception) {}
        wakeLock = null
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "EchoStrike Server", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onDestroy() {
        releaseLock()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
