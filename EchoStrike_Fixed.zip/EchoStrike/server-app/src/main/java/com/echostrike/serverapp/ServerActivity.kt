package com.echostrike.serverapp

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * EchoStrike Server — a dedicated server console for a second phone or tablet.
 * Start it, tell players the address, and everybody can walk around and shoot each other.
 */
class ServerActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var addressText: TextView
    private lateinit var playersText: TextView
    private lateinit var toggle: Button
    private lateinit var logText: TextView
    private lateinit var logScroll: ScrollView

    private lateinit var nameField: EditText
    private lateinit var maxField: EditText
    private lateinit var botsField: EditText
    private lateinit var diffField: EditText
    private lateinit var loginBox: CheckBox
    private lateinit var regBox: CheckBox

    private lateinit var kickField: EditText
    private lateinit var accUser: EditText
    private lateinit var accPass: EditText

    private val ui = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() { refreshStatus(); ui.postDelayed(this, 1000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = ServerHost.prefs(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
            setBackgroundColor(Color.BLACK)
        }
        fun title(t: String) = col.addView(TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 22f; setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(18), 0, dp(6))
        })
        fun text(t: String = "", size: Float = 17f): TextView = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = size
            col.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fun label(t: String) { text(t, 16f).apply { setPadding(0, dp(10), 0, 0); setTextColor(0xFFCCCCCC.toInt()) } }
        fun field(hint: String, value: String, number: Boolean = false, secret: Boolean = false): EditText = EditText(this).apply {
            this.hint = hint; setText(value); setTextColor(Color.WHITE); setHintTextColor(0xFF999999.toInt()); textSize = 18f
            contentDescription = hint
            inputType = when {
                number -> InputType.TYPE_CLASS_NUMBER
                secret -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                else -> InputType.TYPE_CLASS_TEXT
            }
            col.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fun button(t: String, onClick: () -> Unit): Button = Button(this).apply {
            text = t; textSize = 18f; contentDescription = t; setOnClickListener { onClick() }
            col.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fun check(t: String, checked: Boolean): CheckBox = CheckBox(this).apply {
            text = t; isChecked = checked; setTextColor(Color.WHITE); textSize = 17f
            col.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        title("EchoStrike Server")
        statusText = text("", 20f)
        addressText = text("", 17f)
        toggle = button("Start server") { toggleServer() }
        playersText = text("", 17f)

        title("Settings")
        text("Change these while the server is stopped.", 15f).setTextColor(0xFFAAAAAA.toInt())
        label("Server name")
        nameField = field("Server name", p.getString("name", "EchoStrike Server") ?: "")
        label("Maximum players (1 to 32)")
        maxField = field("Maximum players", p.getInt("max", 16).toString(), number = true)
        label("Bots (0 to 8). 0 means no bots.")
        botsField = field("Bots", p.getInt("bots", 0).toString(), number = true)
        label("Bot difficulty: 1 easy, 2 normal, 3 hard")
        diffField = field("Bot difficulty", p.getInt("difficulty", 2).toString(), number = true)
        loginBox = check("Require an account to join", p.getBoolean("login", false))
        regBox = check("Let new players create their own account", p.getBoolean("register", true))
        button("Save settings") { saveSettings(true) }

        title("Players")
        label("Name of a player to remove")
        kickField = field("Player name", "")
        button("Kick player") {
            val n = kickField.text.toString().trim()
            val ok = ServerHost.server?.kick(n) == true
            toast(if (ok) "Kicked $n." else "No player named \"$n\" is online.")
        }

        title("Accounts")
        val accounts = ServerHost.accounts(this)
        label("Username")
        accUser = field("Username", "")
        label("Password (8 or more characters)")
        accPass = field("Password", "", secret = true)
        button("Create account") {
            val err = accounts.create(accUser.text.toString().trim(), accPass.text.toString())
            toast(err ?: "Account created."); if (err == null) accPass.setText("")
        }
        button("Change password") {
            val err = accounts.setPassword(accUser.text.toString().trim(), accPass.text.toString())
            toast(err ?: "Password changed."); if (err == null) accPass.setText("")
        }
        button("Delete account") {
            val u = accUser.text.toString().trim()
            toast(if (accounts.remove(u)) "Deleted $u." else "No account named \"$u\".")
        }
        button("Show all account names") {
            val names = accounts.names()
            toast(if (names.isEmpty()) "There are no accounts yet." else names.joinToString(", "))
        }

        title("Server log")
        logScroll = ScrollView(this)
        logText = TextView(this).apply {
            setTextColor(0xFF66FF66.toInt()); typeface = Typeface.MONOSPACE; textSize = 13f
            text = ServerHost.allLog()
            setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(0xFF111111.toInt())
        }
        logScroll.addView(logText)
        col.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(260)))
        button("Copy log") {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("EchoStrike server log", ServerHost.allLog()))
            toast("Log copied.")
        }

        title("Tips")
        text("Keep this phone plugged in. In Android settings turn off battery optimisation for this app.\n\n" +
            "Players on your WiFi can join with the address above. For players elsewhere use Tailscale " +
            "(install it here and on their phones; use the 100.x.x.x address), or forward TCP 17550 and UDP 17551 on your router.", 15f)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(col)
        })

        ServerHost.logListener = { line ->
            ui.post {
                logText.append((if (logText.text.isEmpty()) "" else "\n") + line)
                logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
            }
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
        }
        refreshStatus()
    }

    override fun onResume() { super.onResume(); ui.post(refresh) }
    override fun onPause() { ui.removeCallbacks(refresh); super.onPause() }
    override fun onDestroy() { ServerHost.logListener = null; super.onDestroy() }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    private fun saveSettings(show: Boolean) {
        if (ServerHost.isRunning) { toast("Stop the server first, then change settings."); return }
        ServerHost.prefs(this).edit()
            .putString("name", nameField.text.toString().trim().ifEmpty { "EchoStrike Server" }.take(30))
            .putInt("max", (maxField.text.toString().toIntOrNull() ?: 16).coerceIn(1, 32))
            .putInt("bots", (botsField.text.toString().toIntOrNull() ?: 0).coerceIn(0, 8))
            .putInt("difficulty", (diffField.text.toString().toIntOrNull() ?: 2).coerceIn(1, 3))
            .putBoolean("login", loginBox.isChecked)
            .putBoolean("register", regBox.isChecked)
            .apply()
        if (show) toast("Settings saved.")
    }

    private fun toggleServer() {
        if (ServerHost.isRunning) {
            startService(Intent(this, ServerService::class.java).setAction(ServerService.ACTION_STOP))
        } else {
            saveSettings(false)
            if (loginBox.isChecked && ServerHost.accounts(this).count() == 0 && !regBox.isChecked) {
                toast("Sign-in is required but there are no accounts and new accounts are closed. Create an account or allow new accounts first.")
                return
            }
            startForegroundService(Intent(this, ServerService::class.java).setAction(ServerService.ACTION_START))
        }
        ui.postDelayed({ refreshStatus() }, 600)
    }

    private fun refreshStatus() {
        val s = ServerHost.server
        val running = ServerHost.isRunning
        statusText.text = if (running) "Status: RUNNING" else "Status: stopped"
        statusText.setTextColor(if (running) 0xFF66FF66.toInt() else 0xFFFF6666.toInt())
        toggle.text = if (running) "Stop server" else "Start server"
        val ips = s?.allIPs().orEmpty()
        addressText.text = if (running && ips.isNotEmpty())
            "Players connect to:\n" + ips.joinToString("\n") { "  $it   (port 17550)" }
        else "Start the server to see the address players should use."
        playersText.text = if (running && s != null) {
            val names = s.playerNames()
            "Online now: ${s.humanCount()}" + if (names.isNotEmpty()) "\n" + names.joinToString(", ") else ""
        } else ""
        val locked = running
        for (f in listOf(nameField, maxField, botsField, diffField)) f.isEnabled = !locked
        loginBox.isEnabled = !locked; regBox.isEnabled = !locked
    }
}
