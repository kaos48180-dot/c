# 🎮 EchoStrike — Online Audio Shooting Game for the Blind

**EchoStrike** is a fully accessible, gesture-controlled, online multiplayer shooting game designed entirely for blind and visually impaired players. Every element of the game is driven by 3D spatial audio and text-to-speech. No vision required.

---

## 📦 What's in This Package

```
EchoStrike/
├── app/                          Android app source code
│   └── src/main/
│       ├── java/com/echostrike/
│       │   ├── audio/            EchoAudioEngine (BGT-style 3D audio)
│       │   ├── game/             GameEngine + GestureHandler
│       │   ├── weapons/          All 30+ weapons
│       │   ├── network/          Firebase + WebSocket + Photon backends
│       │   ├── chat/             Voice chat + text chat
│       │   └── ui/               MainActivity + GameActivity
│       └── assets/sounds/
│           └── menu/             Your VoiceOver_2025 sound pack (all 35 files)
├── server/                       Node.js WebSocket server (custom backend)
│   ├── server.js
│   └── package.json
└── README.md                     This file
```

---

## 🎧 Sound File Assignments (from VoiceOver_2025_by_mkhize_)

All 35 sound files from your pack are used. Here is the complete mapping:

| Sound File | Assigned To |
|---|---|
| `gesture_begin.ogg` | **Any gesture starts** — plays at the very beginning of every swipe |
| `gesture_end.ogg` | **Any gesture ends** — confirmation that the gesture was registered |
| `click.ogg` | **Single tap / button select** |
| `long_clicked.ogg` | **Long press** — context info or status report |
| `scroll_down.ogg` | **Swipe down** — navigate down in menus / move backward in game |
| `KeyboardUp.ogg` | **Swipe up** — navigate up in menus / move forward in game |
| `KeyboardDown.ogg` | **Secondary swipe down** — move backward audio confirmation |
| `window_state.ogg` | **Menu/screen opened** — plays when any menu opens |
| `dialog.ogg` | **Dialog popup** — plays when sub-menus or dialogs appear |
| `start.ogg` | **Game session starts** — plays when match begins |
| `Start.mp3` | **App splash** — plays on first app launch |
| `finalize.ogg` | **Confirm / match found** — double-tap confirmation, match found |
| `cancel.ogg` | **Back / cancel** — swipe right to go back |
| `exit.mp3` | **Exit app** — plays when quitting the game |
| `button.wav` | **Button focused** — navigating to a primary action button |
| `listitem.wav` | **List item focused** — browsing weapons list, friends list, etc. |
| `checkbox.wav` | **Checkbox unfocused** — settings toggles |
| `checkbox_checked.wav` | **Checkbox toggled on** — setting enabled |
| `combobox.wav` | **Dropdown focused** — backend selector, game mode picker |
| `link.wav` | **Navigation link focused** |
| `caret.wav` | **Text cursor moved** — text input fields |
| `focus0.ogg` | **Primary focus change** — main focus ring movement |
| `focus2.ogg` | **Secondary focus** — alternate focus style |
| `enfoque 1.mp3` | **Focus ring appear** — focus gained on an element |
| `enfoque 2.ogg` | **Focus highlight move** |
| `enfoque 3.ogg` | **Focus confirm** |
| `last.wav` | **Last item in list reached** — you've scrolled to the end |
| `notext.wav` | **Empty field / no text** — text box is empty |
| `listening.ogg` | **Voice input active** — microphone open for chat |
| `pause.ogg` | **Game paused** |
| `ReceivedMessage.ogg` | **Chat message received** |
| `SiriAutoSend_Haptic.ogg` | **Chat message sent** |
| `ScreenCapture.ogg` | **Kill confirmed** — you eliminated an enemy |
| `SiriAutoSend_Haptic.ogg` | **Auto-send confirmation** |

---

## 👆 Complete Gesture Reference

### IN-GAME GESTURES

| Gesture | Action | Audio Feedback |
|---|---|---|
| **Swipe RIGHT** (1 finger) | Turn right | gesture_begin → compass TTS |
| **Swipe LEFT** (1 finger) | Turn left | gesture_begin → compass TTS |
| **Swipe UP** (1 finger) | Move forward | KeyboardUp.ogg + footstep sound |
| **Swipe DOWN** (1 finger) | Move backward | scroll_down.ogg + footstep sound |
| **Double tap** | Fire weapon | 3D gun fire sound |
| **Long press** | Status report | long_clicked → TTS: "Health X, Weapon Y, Facing Z, Enemy W meters to the North" |
| **Swipe RIGHT** (2 fingers) | Next weapon | click.ogg + TTS weapon name |
| **Swipe LEFT** (2 fingers) | Previous weapon | click.ogg + TTS weapon name |
| **Swipe UP** (2 fingers) | Increase volume | TTS volume percent |
| **Swipe DOWN** (2 fingers) | Decrease volume | TTS volume percent |
| **Double tap** (2 fingers) | Reload (cosmetic) | reload sound + TTS "Reloading. Ready." |
| **Pinch in or out** | Toggle crouch/stand | TTS "Crouching" or "Standing" |
| **Three-finger tap** | Open pause menu | window_state.ogg + pause.ogg |
| **Three-finger swipe UP** | Say current health | TTS "Health X" |
| **Three-finger swipe DOWN** | Say enemy count | TTS "X enemies remaining" |
| **Four-finger tap** | Weapon details | TTS full weapon stats |
| **Shake device** | Melee attack | knife swing sound |

### MENU GESTURES

| Gesture | Action | Audio Feedback |
|---|---|---|
| **Swipe UP** | Navigate up | KeyboardUp.ogg + item TTS |
| **Swipe DOWN** | Navigate down | scroll_down.ogg + item TTS |
| **Single tap** | Activate / enter | click.ogg |
| **Double tap** | Confirm selection | finalize.ogg |
| **Long press** | Item description | long_clicked.ogg + TTS description |
| **Swipe RIGHT** | Back / cancel | cancel.ogg |
| **Swipe LEFT** | Back / cancel | cancel.ogg |
| **Two-finger swipe RIGHT** | Next tab | window_state.ogg |
| **Two-finger swipe LEFT** | Previous tab | window_state.ogg |

---

## 🔫 Weapons (All Unlocked, Infinite Ammo)

All weapons are available from the very first launch. No unlocking needed. Infinite ammo always.

### Pistols
| Weapon | Damage | Fire Rate | Range |
|---|---|---|---|
| Glock 17 | 35 | 400 rpm | 30m |
| Desert Eagle | 75 | 200 rpm | 40m |
| USP .45 (suppressed) | 42 | 350 rpm | 28m |
| P250 | 38 | 380 rpm | 25m |
| .357 Magnum Revolver | 85 | 150 rpm | 45m |

### Submachine Guns
| Weapon | Damage | Fire Rate | Range |
|---|---|---|---|
| MP5 | 26 | 800 rpm | 25m |
| Uzi | 22 | 950 rpm | 20m |
| P90 | 24 | 900 rpm | 28m |
| MAC-10 | 20 | 1100 rpm | 15m |
| Kriss Vector | 29 | 1200 rpm | 22m |

### Shotguns
| Weapon | Damage | Fire Rate | Pellets |
|---|---|---|---|
| Remington 870 | 20×8 | 60 rpm | 8 |
| SPAS-12 | 22×8 | 100 rpm | 8 |
| AA-12 Auto | 18×6 | 300 rpm | 6 |
| Taurus Judge | 25×5 | 80 rpm | 5 |

### Assault Rifles
| Weapon | Damage | Fire Rate | Range |
|---|---|---|---|
| AK-47 | 40 | 600 rpm | 50m |
| M4A1 | 35 | 700 rpm | 50m |
| SCAR-H | 48 | 550 rpm | 55m |
| Steyr AUG | 36 | 680 rpm | 50m |
| HK G36C | 34 | 750 rpm | 48m |
| FN FAL (semi) | 50 | 650 rpm | 60m |
| Tavor TAR-21 | 37 | 800 rpm | 45m |

### Battle Rifles
| Weapon | Damage | Fire Rate | Range |
|---|---|---|---|
| M14 EBR | 58 | 450 rpm | 80m |
| Mk 17 SCAR | 60 | 400 rpm | 75m |

### Light Machine Guns
| Weapon | Damage | Fire Rate | Magazine |
|---|---|---|---|
| M249 SAW | 38 | 800 rpm | 100 |
| M134 Minigun | 20 | 3000 rpm | ∞ |
| MG42 | 36 | 1200 rpm | 75 |

### Sniper Rifles
| Weapon | Damage | Fire Rate | Range |
|---|---|---|---|
| AWP | 115 | 40 rpm | 150m |
| Barrett M82A1 .50 Cal | 200 | 25 rpm | 200m |
| SV-98 | 95 | 45 rpm | 140m |

### Marksman Rifles
| Weapon | Damage | Fire Rate |
|---|---|---|
| MK12 DMR | 65 | 180 rpm |

### Rockets & Launchers
| Weapon | Damage | Range |
|---|---|---|
| RPG-7 | 300 | 100m |
| FIM-92 Stinger | 500 | 300m |
| M79 Grenade Launcher | 250 | 80m |

### Melee
| Weapon | Damage | Range |
|---|---|---|
| Combat Knife | 80 | 2m (shake device) |

**Switch weapons:** Two-finger swipe left or right. Game announces weapon name and type via TTS.

---

## 🌐 Online Modes

### Game Modes
- **Deathmatch** — Free for all, 8 players, most kills wins
- **Team Deathmatch** — 2 teams, 5v5
- **Battle Royale** — Last player standing, 20 start
- **Survival** — Wave-based, hold out as long as possible
- **Capture the Flag** — Audio beacon marks the flag location

### Network Backends (choose in Settings)

#### Option 1: Firebase (Default — recommended)
- Free tier supports up to 100 simultaneous connections
- Real-time Database for positions, chat, scores
- Firebase Auth for accounts (anonymous or email)
- Setup: Create a Firebase project at https://console.firebase.google.com
  1. Create Android app with package name `com.echostrike`
  2. Download `google-services.json`
  3. Replace the template `app/google-services.json` with your real one
  4. Enable Realtime Database and Authentication in Firebase Console

#### Option 2: Photon Engine
- Free tier: 20 concurrent users
- No server to run
- Very low latency
- Setup: Get App ID at https://www.photonengine.com
  - Replace `PHOTON_APP_ID` in `NetworkManager.kt`

#### Option 3: Custom WebSocket Server
- Maximum control
- Run the included Node.js server
- Setup:
  ```bash
  cd server/
  npm install
  node server.js
  ```
- Then change `WEBSOCKET_URL` in `NetworkManager.kt` to your server IP
- Default port: 3001

---

## 💬 Chat System

- **Voice-to-text chat:** Long press mic icon or activate via three-finger tap → Chat
- **Text-to-speech:** All received messages are spoken aloud automatically
- **Quick phrases:** Pre-set tactical callouts (browse in Chat menu)
  - "Enemy spotted!", "Need backup!", "Flanking left/right", "Watch out!", "Good game!" and more
- **Proximity chat:** Hear enemy players via 3D spatial audio — enemies talking nearby sound closer
- **Chat history:** Swipe in chat to hear last 5 messages

---

## 👥 Friends System

1. **Add friends:** Enter player ID (shown in Settings → My Profile)
2. **Friend requests:** Notified via push notification and in-game audio
3. **Invite to game:** From Friends menu, invite friends directly to your match
4. **Online status:** Friends list shows who's currently online
5. **Friend voice:** Hear friends' audio from their actual in-game position

---

## 🏆 Leaderboard

- Global rankings by: Score, Kills, Wins
- Updated in real-time after each match
- Access from main menu: Swipe to Leaderboard → double tap
- Top 10 read aloud via TTS

---

## 🔉 3D Audio Engine Details

EchoStrike uses a BGT-style spatial audio model:

- **Distance falloff:** Sounds get quieter as enemies move away. Max hearing range: 50 meters in-game.
- **Panning:** Sounds pan left/right based on your facing direction. Enemy to your right → sound in right ear.
- **Elevation cues:** Sounds above or below you have subtle volume reduction.
- **Environment reverb:**
  - Outdoor arena: natural decay
  - Indoor rooms: reverb and echo
  - Cave: long reverb tail
  - Corridor: channeled echo
- **Enemy footsteps:** Every enemy constantly emits 3D footstep audio — track them by sound alone.
- **Gunfire audio radius:** Each weapon has a unique radius — Barrett .50 Cal can be heard 50m away; suppressed USP only 10m.

---

## 🔧 Building the App

### Requirements
- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Kotlin 1.9.x
- Java 17

### Steps
1. Open `EchoStrike/` in Android Studio
2. Replace `app/google-services.json` with your Firebase config
3. Let Gradle sync (it will download all dependencies)
4. Build → Run on device or emulator (API 26+)

### Minimum Android version
Android 8.0 (API 26) — required for AudioAttributes game mode.

---

## ♿ Accessibility Notes

- **TalkBack compatible:** All elements have `contentDescription`
- **No visual UI required:** The entire game is playable with the screen off
- **High contrast:** Dark background (#000000) with red (#E94560) accents for low-vision users
- **TTS speed control:** Adjustable in Settings
- **No time pressure in menus:** All menus wait for gestures, never auto-advance
- **Confirmation before destructive actions:** Quit always asks for confirmation

---

## 📜 Credits & License

Sound pack: **VoiceOver_2025_by_mkhize_** — used as the complete menu audio system.  
Audio engine: Android SoundPool + EnvironmentalReverb (BGT-inspired spatial model).  
Network: Firebase / Photon / Socket.IO — all free tiers.  
Game: Built with ❤️ for the blind gaming community.

MIT License — free to modify and redistribute.

---

## 🐛 Troubleshooting

**No sounds playing:** Check that `sounds/menu/` folder in assets contains all .ogg/.wav/.mp3 files.  
**Can't connect online:** Check `google-services.json` is your real Firebase config, not the template.  
**TTS not speaking:** Ensure Android TTS engine is installed (Settings → Accessibility → TTS).  
**Gestures not working:** Make sure the app has focus (tap the screen once to give focus).  
**WebSocket server:** Ensure port 3001 is open in your firewall. Check `/health` endpoint.  


## Two APKs and automatic cloud reconnect

The GitHub Actions workflow builds both the EchoStrike player APK and the separate EchoStrike Developer Console APK. Set a unique Fly.io app name once in `fly.toml`; the Android workflow derives the hostname from that value automatically. The player app defaults to the display name `Chaos`. First-time cloud sign-in uses the main account configured in the Developer Console; a session token is saved locally so later launches automatically reconnect. See `docs/DEVELOPER_CONSOLE.md` and `docs/CLOUD_SERVER_DEPLOYMENT.md`.

## Repository-ready setup (GitHub Actions)

This repository has two Android Gradle modules (`:app` and `:developer-console`), a standalone Node.js server in `cloud-server/`, Fly.io configuration in `fly.toml`, and separate GitHub Actions workflows for building the two APKs and deploying the server. Pushes to `main` or `master` run the Android build. The APK workflow embeds the hostname derived from `fly.toml`.

**Default Fly app name:** `echostrike-chaos-20261017`. Fly app names are globally unique. If Fly reports that this name is already taken, change the `app` value in `fly.toml` before deployment; the Android build automatically uses the changed name.

**Required one-time hosting setup:** add GitHub Actions secrets `FLY_API_TOKEN` and `ADMIN_TOKEN` (use a random secret of at least 32 characters for `ADMIN_TOKEN`). The deployment workflow cannot create or authenticate a hosting account without these user-owned credentials. After deployment, install both APKs from the `EchoStrike-and-Developer-Console-APKs` artifact. In Developer Console, enter `https://<app-name>.fly.dev`, the same `ADMIN_TOKEN`, username `Chaos`, and a strong password.

The Android build and server deployment are separate workflows. Building an APK does not itself prove that cloud deployment or end-to-end multiplayer is working; confirm both workflow runs and test the installed apps. Fly.io hosting may incur charges.


## Optional: upload a ZIP and let GitHub extract/build it

After the GitHub repository already contains this workflow, upload a project ZIP (for example, `EchoStrike_Repository_Ready.zip`) to the repository and commit it to `main` or `master`. The `Import ZIP and Build Both APKs` workflow will extract the project files into the repository root, commit those extracted files, build the player APK and developer-console APK, and publish both as the `EchoStrike-and-Developer-Console-APKs` workflow artifact. The ZIP is removed by the workflow after extraction.

**First-time setup limitation:** GitHub cannot run a workflow that exists only inside a ZIP that has not been extracted yet. For the first setup, upload the ZIP contents (the files and folders inside the `EchoStrike` folder) to the repository once, including `.github/workflows/`. After that, the ZIP-upload automation can run. In the repository settings, also check **Settings → Actions → General → Workflow permissions** and allow workflows to have read and write permissions so the import workflow can commit extracted files.
