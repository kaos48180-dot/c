package com.echostrike.game

import java.util.Random
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * BotBrain — simple computer-player AI with no Android code in it.
 * Used by the offline game and by the dedicated server.
 *
 * Coordinates: x east, y north, angle in degrees, 0 = north (same as the rest of the game).
 */
object BotBrain {

    enum class Difficulty(
        val label: String,
        val speed: Float,          // metres per second while chasing
        val shotIntervalMs: Long,  // average time between shots
        val accuracy: Float,       // 0..1 chance to hit at point blank
        val damageScale: Float,
        val sightRange: Float,     // starts chasing inside this distance
        val fireRange: Float
    ) {
        EASY("Easy", 1.6f, 2400, 0.25f, 0.6f, 25f, 16f),
        NORMAL("Normal", 2.3f, 1600, 0.45f, 1.0f, 35f, 24f),
        HARD("Hard", 3.0f, 1000, 0.70f, 1.2f, 50f, 34f);

        companion object {
            fun fromLevel(level: Int): Difficulty = when {
                level <= 1 -> EASY
                level == 2 -> NORMAL
                else -> HARD
            }
        }
    }

    class State(var x: Float, var y: Float, var angle: Float = 0f) {
        var waypointX = x
        var waypointY = y
        var hasWaypoint = false
        var nextShotAt = 0L
    }

    class Result(val fired: Boolean, val hit: Boolean, val chasing: Boolean)

    private const val TURN_DEG_PER_SEC = 220f
    private const val MARGIN = 5f

    fun bearing(fromX: Float, fromY: Float, toX: Float, toY: Float): Float =
        Math.toDegrees(atan2((toX - fromX).toDouble(), (toY - fromY).toDouble())).toFloat()

    fun angleDiff(a: Float, b: Float): Float = abs(((a - b + 540f) % 360f + 360f) % 360f - 180f)

    private fun turnToward(current: Float, target: Float, maxStep: Float): Float {
        var d = ((target - current + 540f) % 360f + 360f) % 360f - 180f
        if (d > maxStep) d = maxStep
        if (d < -maxStep) d = -maxStep
        return ((current + d) % 360f + 360f) % 360f
    }

    /**
     * Advance one bot by dtSec seconds. Target may be null (nobody to hunt).
     * Updates state.x / y / angle in place and says whether the bot fired and whether the shot hit.
     */
    fun step(
        s: State, targetX: Float?, targetY: Float?, dtSec: Float, nowMs: Long,
        d: Difficulty, rnd: Random, arena: Float = 100f
    ): Result {
        val dist = if (targetX != null && targetY != null) hypot(targetX - s.x, targetY - s.y) else Float.MAX_VALUE
        val chasing = dist <= d.sightRange

        val goalX: Float
        val goalY: Float
        val speed: Float
        if (chasing) {
            goalX = targetX!!; goalY = targetY!!
            speed = if (dist > 7f) d.speed else 0f      // stop when close
        } else {
            if (!s.hasWaypoint || hypot(s.waypointX - s.x, s.waypointY - s.y) < 2f) {
                s.waypointX = MARGIN + rnd.nextFloat() * (arena - 2 * MARGIN)
                s.waypointY = MARGIN + rnd.nextFloat() * (arena - 2 * MARGIN)
                s.hasWaypoint = true
            }
            goalX = s.waypointX; goalY = s.waypointY
            speed = d.speed * 0.55f
        }

        val want = bearing(s.x, s.y, goalX, goalY)
        s.angle = turnToward(s.angle, want, TURN_DEG_PER_SEC * dtSec)
        if (speed > 0f && angleDiff(s.angle, want) < 60f) {
            val rad = Math.toRadians(s.angle.toDouble())
            s.x = (s.x + sin(rad).toFloat() * speed * dtSec).coerceIn(0f, arena)
            s.y = (s.y + cos(rad).toFloat() * speed * dtSec).coerceIn(0f, arena)
        }

        var fired = false
        var hit = false
        if (chasing && dist <= d.fireRange && nowMs >= s.nextShotAt && angleDiff(s.angle, want) < 20f) {
            fired = true
            s.nextShotAt = nowMs + (d.shotIntervalMs * (0.8f + rnd.nextFloat() * 0.5f)).toLong()
            val falloff = (1f - dist / (d.fireRange * 1.3f)).coerceAtLeast(0.15f)
            hit = rnd.nextFloat() < d.accuracy * falloff
        }
        return Result(fired, hit, chasing)
    }
}
