package com.echostrike.server

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import com.echostrike.game.BotBrain
import com.echostrike.security.APKValidator
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.net.*
import java.util.concurrent.ConcurrentHashMap
import java.util.Random
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.hypot

/**
 * EmbeddedGameServer
 * ──────────────────
 * Runs INSIDE the APK. No external server. No internet required.
 * One player hosts, others connect by LAN auto-discovery or direct IP.
 *
 * Security: clients must present a token derived from the APK signing
 * certificate. A different APK = different token = rejected instantly.
 *
 * Ports:
 *   TCP 17550 — reliable game events (fire, kill, chat, handshake)
 *   UDP 17551 — fast position snapshots at 20 Hz
 *   UDP 17552 — LAN discovery broadcasts every 2 s
 */
class EmbeddedGameServer(private val context: Context) {

    companion object {
        private const val TAG = "EchoServer"
        const val TCP_PORT       = 17550
        const val UDP_PORT       = 17551
        const val DISC_PORT      = 17552
        const val MAX_PLAYERS    = 16
        const val TICK_MS        = 50L   // 20 Hz
        const val DISC_MS        = 2000L
        const val PROTOCOL_MAGIC = "ECHO2025"
        const val PROTOCOL_VER   = 2
    }

    // ── sockets ──────────────────────────────────────────────────────────
    private var tcpServer:   ServerSocket?   = null
    private var udpSocket:   DatagramSocket? = null
    private var discSocket:  DatagramSocket? = null

    private var scope   = CoroutineScope(Dispatchers.IO + SupervisorJob())
    val  players = ConcurrentHashMap<String, ServerPlayer>()
    private val rooms   = ConcurrentHashMap<String, ServerRoom>()
    private val nextId  = AtomicInteger(1)

    @Volatile var isRunning = false

    /** Settings for a dedicated / hosted server. Set before start(). */
    var options = HostOptions()

    /** Human-readable event log (joins, kills ...). May be called from any thread. */
    var onLog: ((String) -> Unit)? = null
    /** Called when a signed-in player asks to become an admin. */
    var onAdminRequest: ((String) -> Unit)? = null
    private fun log(msg: String) { Log.i(TAG, msg); try { onLog?.invoke(msg) } catch (_: Exception) {} }

    private val botStates = ConcurrentHashMap<String, BotBrain.State>()
    private val botRandom = Random()

    /** Names of everyone online (people and bots). */
    fun playerNames(): List<String> = players.values.map { if (it.isBot) "${it.displayName} (bot)" else it.displayName }
    fun humanCount(): Int = players.values.count { !it.isBot }

    /** Disconnect a player by name. Returns true if somebody was kicked. */
    fun kick(name: String): Boolean {
        val p = players.values.firstOrNull { !it.isBot && it.displayName.equals(name, ignoreCase = true) } ?: return false
        log("Kicked ${p.displayName}")
        p.close()
        return true
    }

    // derived once from THIS APK's signing cert
    private val apkToken: String by lazy { APKValidator.computeToken(context) }

    // ── host callbacks ────────────────────────────────────────────────────
    var onPlayerJoined:  ((String) -> Unit)?       = null
    var onPlayerLeft:    ((String) -> Unit)?        = null
    var onStatusUpdate:  ((ServerStatus) -> Unit)?  = null

    // ═════════════════════════════════════════════════════════════════════
    // START
    // ═════════════════════════════════════════════════════════════════════
    fun start(onError: ((String) -> Unit)? = null, onReady: (ip: String, port: Int) -> Unit) {
        if (isRunning) return
        isRunning = true
        // stop() cancels the scope; make a fresh one so hosting works a second time
        if (!scope.isActive) scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

        scope.launch {
            try {
                tcpServer  = ServerSocket().apply {
                    reuseAddress = true; bind(InetSocketAddress(TCP_PORT))
                }
                udpSocket  = DatagramSocket(null as SocketAddress?).apply {
                    reuseAddress = true; bind(InetSocketAddress(UDP_PORT))
                }
                discSocket = DatagramSocket(null as SocketAddress?).apply {
                    reuseAddress = true; broadcast = true; bind(InetSocketAddress(DISC_PORT))
                }

                val ip = localIP()
                log("Server started on $ip:$TCP_PORT (${options.botCount} bots, sign-in ${if (options.requireLogin) "required" else "off"})")

                launch { tcpAcceptLoop() }
                launch { udpReceiveLoop() }
                launch { discoveryBroadcastLoop() }
                launch { tickLoop() }
                spawnBots()

                withContext(Dispatchers.Main) { onReady(ip, TCP_PORT) }
            } catch (e: Exception) {
                Log.e(TAG, "Server start failed: ${e.message}")
                isRunning = false
                try { tcpServer?.close(); udpSocket?.close(); discSocket?.close() } catch (_: Exception) {}
                withContext(Dispatchers.Main) { onError?.invoke(e.message ?: "could not open the game ports") }
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // STOP
    // ═════════════════════════════════════════════════════════════════════
    fun stop() {
        isRunning = false
        players.values.forEach { it.close() }
        players.clear(); rooms.clear(); botStates.clear()
        tcpServer?.close(); udpSocket?.close(); discSocket?.close()
        scope.cancel()
        log("Server stopped")
    }

    // ═════════════════════════════════════════════════════════════════════
    // TCP ACCEPT LOOP
    // ═════════════════════════════════════════════════════════════════════
    private suspend fun tcpAcceptLoop() = withContext(Dispatchers.IO) {
        while (isRunning) {
            try {
                val sock = tcpServer?.accept() ?: break
                launch { handleClient(sock) }
            } catch (_: SocketException) { break }
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // CLIENT HANDLER — handshake then message loop
    // ═════════════════════════════════════════════════════════════════════
    private suspend fun handleClient(sock: Socket) = withContext(Dispatchers.IO) {
        sock.soTimeout = 6000
        val reader = BufferedReader(InputStreamReader(sock.getInputStream()))
        val writer = PrintWriter(BufferedWriter(OutputStreamWriter(sock.getOutputStream())), true)

        var player: ServerPlayer? = null
        try {
            // ── handshake ────────────────────────────────────────────────
            val hello = JSONObject(reader.readLine() ?: return@withContext)

            if (hello.optString("magic") != PROTOCOL_MAGIC) {
                writer.println(reject("Bad magic — wrong app?")); sock.close(); return@withContext
            }
            if (hello.optInt("ver") != PROTOCOL_VER) {
                writer.println(reject("Version mismatch — update your game")); sock.close(); return@withContext
            }
            if (!APKValidator.validateToken(hello.optString("token"), apkToken)) {
                Log.w(TAG, "Rejected ${sock.inetAddress} — bad APK token")
                writer.println(reject("Access denied. Only genuine EchoStrike APKs can connect."))
                sock.close(); return@withContext
            }
            if (hello.optBoolean("console")) { handleConsole(sock, reader, writer, hello); return@withContext }
            if (humanCount() >= options.maxPlayers) {
                writer.println(reject("Server full (${options.maxPlayers} max)")); sock.close(); return@withContext
            }

            if (hello.optString("role") == "console" && !(options.requireLogin && options.accounts != null)) {
                writer.println(reject("Turn on \"Require an account to join\" in the server app first, then use the console.")); sock.close(); return@withContext
            }

            // ── optional account sign-in ─────────────────────────────────
            var loginName: String? = null
            val accounts = options.accounts
            if (options.requireLogin && accounts != null) {
                val user = hello.optString("user").trim()
                val pass = hello.optString("pass")
                if (user.isEmpty() || pass.isEmpty()) {
                    writer.println(reject("This server needs an account. Enter your username and password.")); sock.close(); return@withContext
                }
                if (hello.optBoolean("register") && hello.optBoolean("adminRequest")) {
                    writer.println(reject("Create the account first, then sign in and ask for admin access.")); sock.close(); return@withContext
                }
                if (hello.optBoolean("register")) {
                    if (!options.allowRegistration) {
                        writer.println(reject("New accounts are closed on this server.")); sock.close(); return@withContext
                    }
                    val err = accounts.create(user, pass)
                    if (err != null) { writer.println(reject(err)); sock.close(); return@withContext }
                    log("New account: $user")
                } else if (!accounts.verify(user, pass)) {
                    log("Failed sign-in for '$user' from ${sock.inetAddress?.hostAddress}")
                    writer.println(reject("Wrong username or password.")); sock.close(); return@withContext
                }
                if (hello.optBoolean("adminRequest")) {
                    val err = accounts.requestAdmin(user)
                    if (err == null) {
                        log("ADMIN REQUEST from $user - approve it in the server app")
                        try { onAdminRequest?.invoke(user) } catch (_: Exception) {}
                    }
                    writer.println(reject(err ?: "Admin request sent. The server owner must approve it in the server app. Sign in normally after that."))
                    sock.close(); return@withContext
                }
                if (hello.optString("role") == "console") {
                    val adminName = accounts.names().firstOrNull { it.equals(user, ignoreCase = true) } ?: user
                    if (!accounts.isAdmin(adminName)) {
                        writer.println(reject("This account is not an admin. Ask the server owner to approve it in the server app.")); sock.close(); return@withContext
                    }
                    runConsole(adminName, sock, reader, writer)
                    return@withContext
                }
                if (players.values.any { !it.isBot && it.displayName.equals(user, ignoreCase = true) }) {
                    writer.println(reject("$user is already signed in.")); sock.close(); return@withContext
                }
                loginName = accounts.names().firstOrNull { it.equals(user, ignoreCase = true) } ?: user
            }

            // ── accept ───────────────────────────────────────────────────
            val id      = "P${nextId.getAndIncrement()}"
            val name    = (loginName ?: hello.optString("name", "Player")).take(20)
            val roomId  = hello.optString("room", "default")
            sock.soTimeout = 30_000

            player = ServerPlayer(id, name, sock, writer, reader, roomId)
            players[id] = player
            rooms.getOrPut(roomId) { ServerRoom(roomId) }.addPlayer(id)

            writer.println(JSONObject().apply {
                put("type", "welcome")
                put("id", id); put("room", roomId)
                put("tickHz", 1000 / TICK_MS)
                put("serverIp", localIP())
                put("admin", loginName != null && accounts?.isAdmin(loginName) == true)
                put("serverName", options.serverName)
            })

            broadcastRoom(roomId, JSONObject().apply {
                put("type", "player_joined"); put("id", id); put("name", name)
            }, exclude = id)

            withContext(Dispatchers.Main) { onPlayerJoined?.invoke(name) }
            log("Player joined: $name  [players: ${humanCount()}]")

            // ── message loop ─────────────────────────────────────────────
            sock.soTimeout = 30_000
            while (isRunning && !sock.isClosed) {
                val line = reader.readLine() ?: break
                handleMessage(player, line)
            }

        } catch (e: Exception) {
            Log.d(TAG, "Client disconnected: ${e.message}")
        } finally {
            player?.let { p ->
                players.remove(p.id)
                rooms[p.roomId]?.removePlayer(p.id)
                broadcastRoom(p.roomId, JSONObject().apply {
                    put("type", "player_left"); put("id", p.id); put("name", p.displayName)
                })
                withContext(Dispatchers.Main) { onPlayerLeft?.invoke(p.displayName) }
                log("Player left: ${p.displayName}  [players: ${humanCount()}]")
            }
            sock.close()
            updateStatus()
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // MESSAGE DISPATCH
    // ═════════════════════════════════════════════════════════════════════
    // ═════════════════════════════════════════════════════════════════════
    // DEVELOPER CONSOLE — the Developer Console app signs in here with an ADMIN account
    // (no separate admin token). The first console sign-up can claim the admin role while
    // the server has no admin yet.
    // ═════════════════════════════════════════════════════════════════════
    private fun consoleState(note: String? = null): String = JSONObject().apply {
        val a = options.accounts
        put("type", "console_state")
        put("server", options.serverName)
        put("online", humanCount())
        put("players", JSONArray(playerNames()))
        put("requests", JSONArray(a?.pendingRequests().orEmpty()))
        put("admins", JSONArray(a?.admins().orEmpty()))
        put("accounts", a?.count() ?: 0)
        put("bots", options.botCount)
        if (note != null) put("note", note)
    }.toString()

    private fun handleConsole(sock: Socket, reader: BufferedReader, writer: PrintWriter, hello: JSONObject) {
        val accounts = options.accounts
        fun fail(m: String) { writer.println(reject(m)); sock.close() }
        if (accounts == null) { fail("This server has no accounts, so the console cannot sign in."); return }
        val user = hello.optString("user").trim()
        val pass = hello.optString("pass")
        if (user.isEmpty() || pass.isEmpty()) { fail("Type your admin username and password."); return }

        if (hello.optBoolean("claim")) {
            if (accounts.admins().isNotEmpty()) { fail("This server already has an admin. Sign in with that account."); return }
            if (accounts.exists(user)) {
                if (!accounts.verify(user, pass)) { fail("That username exists and the password is wrong."); return }
                accounts.approve(user)
            } else {
                val err = accounts.create(user, pass)
                if (err != null) { fail(err); return }
                accounts.approve(user)
            }
            log("DEVELOPER ACCOUNT created from the console: $user")
        } else {
            if (!accounts.verify(user, pass)) { log("Console sign-in failed for '$user'"); fail("Wrong username or password."); return }
            if (!accounts.isAdmin(user)) { fail("This account is not an admin. Ask the server owner to approve you."); return }
        }
        val me = accounts.names().firstOrNull { it.equals(user, true) } ?: user
        log("Console signed in: $me")
        sock.soTimeout = 90_000
        writer.println(JSONObject(consoleState()).put("type", "console_ok").put("user", me).toString())

        while (isRunning && !sock.isClosed) {
            val line = reader.readLine() ?: break
            val m = try { JSONObject(line) } catch (_: Exception) { continue }
            val arg = m.optString("name").trim()
            var note: String? = null
            when (m.optString("cmd")) {
                "kick" -> note = if (arg.isNotEmpty() && kick(arg)) "Kicked $arg." else "No player named $arg."
                "approve" -> note = if (accounts.approve(arg)) { log("$me approved admin: $arg"); "$arg is now an admin." } else "No such account."
                "deny" -> note = if (accounts.deny(arg)) "Request from $arg denied." else "No request from $arg."
                "revoke" -> note = if (arg.equals(me, true)) "You cannot remove your own admin rights."
                                   else if (accounts.revoke(arg)) { log("$me removed admin: $arg"); "$arg is no longer an admin." } else "$arg is not an admin."
                "say" -> {
                    val text = m.optString("text").trim().take(200)
                    if (text.isNotEmpty()) {
                        val msg = JSONObject().apply {
                            put("type","chat"); put("id","server"); put("name","Admin $me"); put("text", text); put("ts", System.currentTimeMillis())
                        }
                        players.values.map { it.roomId }.distinct().forEach { broadcastRoom(it, msg) }
                        note = "Announcement sent."
                    }
                }
                "ping", "refresh" -> {}
            }
            writer.println(consoleState(note))
        }
        sock.close()
    }

    // ═════════════════════════════════════════════════════════════════════
    // ADMIN CONSOLE (the Developer Console app signs in with an admin account)
    // ═════════════════════════════════════════════════════════════════════
    private fun runConsole(admin: String, sock: Socket, reader: BufferedReader, writer: PrintWriter) {
        sock.soTimeout = 60_000
        writer.println(JSONObject().put("type", "console_ok").put("admin", admin).put("serverName", options.serverName))
        log("Console signed in: $admin")
        try {
            while (isRunning && !sock.isClosed) {
                val line = reader.readLine() ?: break
                val m = try { JSONObject(line) } catch (_: Exception) { continue }
                if (m.optString("type") != "cmd") continue
                val text = try { consoleCommand(admin, m.optString("cmd"), m.optString("arg").trim()) } catch (e: Exception) { "Error: ${e.message}" }
                writer.println(JSONObject().put("type", "result").put("cmd", m.optString("cmd")).put("text", text))
            }
        } catch (_: Exception) { }
        log("Console signed out: $admin")
    }

    private fun consoleCommand(admin: String, cmd: String, arg: String): String {
        val acc = options.accounts ?: return "Accounts are off."
        return when (cmd) {
            "status" -> "${options.serverName}: ${humanCount()} players online, ${players.size - humanCount()} bots. " +
                "${acc.count()} accounts, ${acc.admins().size} admins, ${acc.pendingRequests().size} admin requests waiting."
            "players" -> playerNames().joinToString("\n").ifEmpty { "Nobody is online." }
            "kick" -> if (arg.isNotEmpty() && kick(arg)) "Kicked $arg." else "No player named \"$arg\" is online."
            "say" -> if (arg.isEmpty()) "Type a message first." else {
                for (r in rooms.keys.toList()) broadcastRoom(r, JSONObject().apply {
                    put("type","chat"); put("id","server"); put("name","Admin $admin"); put("text", arg.take(200)); put("ts", System.currentTimeMillis())
                })
                "Sent."
            }
            "requests" -> acc.pendingRequests().joinToString("\n").ifEmpty { "No admin requests waiting." }
            "approve" -> if (acc.approve(arg)) { log("$admin approved admin for $arg"); "$arg is now an admin." } else "No account named \"$arg\"."
            "deny" -> if (acc.deny(arg)) "Denied $arg." else "$arg has no waiting request."
            "revoke" -> if (arg.equals(admin, true)) "You cannot remove your own admin rights." else if (acc.revoke(arg)) "$arg is no longer an admin." else "$arg is not an admin."
            "accounts" -> acc.names().joinToString("\n") { it + if (acc.isAdmin(it)) "  (admin)" else "" }.ifEmpty { "There are no accounts." }
            "delete" -> if (arg.equals(admin, true)) "You cannot delete your own account here." else if (acc.remove(arg)) { kick(arg); log("$admin deleted account $arg"); "Deleted $arg." } else "No account named \"$arg\"."
            else -> "Unknown command."
        }
    }

    /** Chat commands for admins: /kick name, /say message, /who */
    private fun handleAdminCommand(player: ServerPlayer, text: String) {
        fun tell(m: String) = player.writer.println(JSONObject().apply {
            put("type","chat"); put("id","server"); put("name","Server"); put("text", m); put("ts", System.currentTimeMillis())
        })
        if (options.accounts?.isAdmin(player.displayName) != true) { tell("Only admins can use commands."); return }
        val parts = text.removePrefix("/").split(" ", limit = 2)
        val arg = parts.getOrNull(1)?.trim().orEmpty()
        when (parts[0].lowercase()) {
            "kick" -> tell(if (arg.isNotEmpty() && kick(arg)) "Kicked $arg." else "No player named $arg.")
            "say" -> broadcastRoom(player.roomId, JSONObject().apply {
                put("type","chat"); put("id","server"); put("name","Admin ${player.displayName}"); put("text", arg); put("ts", System.currentTimeMillis())
            })
            "who" -> tell(playerNames().joinToString(", ").ifEmpty { "Nobody online." })
            else -> tell("Commands: kick name, say message, who.")
        }
    }

    private fun handleMessage(player: ServerPlayer, raw: String) {
        val msg = try { JSONObject(raw) } catch (_: Exception) { return }
        when (msg.optString("type")) {

            "move" -> {
                player.x     = msg.optDouble("x", player.x.toDouble()).toFloat()
                player.y     = msg.optDouble("y", player.y.toDouble()).toFloat()
                player.angle = msg.optDouble("a", player.angle.toDouble()).toFloat()
            }

            "fire" -> {
                val weapon = msg.optString("weapon", "pistol")
                val fx = msg.optDouble("x").toFloat()
                val fy = msg.optDouble("y").toFloat()
                val fa = msg.optDouble("a").toFloat()

                val hit = serverRaycast(player, fa)
                broadcastRoom(player.roomId, JSONObject().apply {
                    put("type","player_fired"); put("id", player.id)
                    put("x",fx); put("y",fy); put("a",fa)
                    put("weapon",weapon); put("hit", hit != null)
                }, exclude = player.id)
                hit?.let { applyDamage(player, it, weapon) }
            }

            "chat" -> {
                val text = msg.optString("text","").take(200).trim()
                if (text.startsWith("/")) { handleAdminCommand(player, text); return }
                if (text.isNotEmpty()) {
                    broadcastRoom(player.roomId, JSONObject().apply {
                        put("type","chat"); put("id",player.id); put("name",player.displayName)
                        put("text",text); put("ts", System.currentTimeMillis())
                    })
                }
            }

            "ping" -> player.writer.println(
                JSONObject().put("type","pong").put("ts", msg.optLong("ts"))
            )

            "leaderboard" -> sendLeaderboard(player)

            "friend_request" -> {
                val target = players[msg.optString("targetId")] ?: return
                target.writer.println(JSONObject().apply {
                    put("type","friend_request"); put("fromId",player.id); put("fromName",player.displayName)
                })
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // SERVER-SIDE HIT DETECTION
    // ═════════════════════════════════════════════════════════════════════
    private fun serverRaycast(shooter: ServerPlayer, angleDeg: Float): ServerPlayer? {
        return players.values
            .filter { it.id != shooter.id && it.roomId == shooter.roomId && it.health > 0 }
            .filter { t ->
                val dist = hypot((t.x-shooter.x).toDouble(), (t.y-shooter.y).toDouble()).toFloat()
                if (dist > 150f) return@filter false
                val bearingDeg = Math.toDegrees(
                    Math.atan2((t.x-shooter.x).toDouble(), (t.y-shooter.y).toDouble())
                ).toFloat()
                Math.abs(((bearingDeg - angleDeg + 540) % 360) - 180) < 12f
            }
            .minByOrNull { hypot((it.x-shooter.x).toDouble(), (it.y-shooter.y).toDouble()) }
    }

    private fun applyDamage(shooter: ServerPlayer, victim: ServerPlayer, weapon: String, scale: Float = 1f) {
        val dmg = ((WEAPON_DAMAGE[weapon] ?: 35) * scale).toInt().coerceAtLeast(1)
        victim.health = (victim.health - dmg).coerceAtLeast(0)

        victim.writer.println(JSONObject().apply {
            put("type","you_hit"); put("fromId",shooter.id); put("fromName",shooter.displayName)
            put("damage",dmg); put("health",victim.health)
        })
        shooter.writer.println(JSONObject().apply {
            put("type","hit_confirmed"); put("victimId",victim.id); put("damage",dmg)
        })

        if (victim.health <= 0) handleKill(shooter, victim)
    }

    private fun handleKill(killer: ServerPlayer, victim: ServerPlayer) {
        killer.kills++; victim.deaths++
        log("${killer.displayName} killed ${victim.displayName}")
        val room = rooms[killer.roomId] ?: return
        room.scores[killer.id] = (room.scores[killer.id] ?: 0) + 100

        broadcastRoom(killer.roomId, JSONObject().apply {
            put("type","kill_event")
            put("killerId",killer.id); put("killerName",killer.displayName)
            put("victimId",victim.id); put("victimName",victim.displayName)
        })

        scope.launch {
            delay(3000)
            if (players.containsKey(victim.id)) {
                victim.health = 100
                victim.x = (Math.random() * 90 + 5).toFloat()
                victim.y = (Math.random() * 90 + 5).toFloat()
                victim.writer.println(JSONObject().apply {
                    put("type","respawned"); put("x",victim.x); put("y",victim.y)
                })
            }
        }
    }

    private fun sendLeaderboard(player: ServerPlayer) {
        val room = rooms[player.roomId] ?: return
        val arr = JSONArray()
        room.scores.entries.sortedByDescending { it.value }.take(10).forEach { (pid, score) ->
            arr.put(JSONObject().apply {
                put("name", players[pid]?.displayName ?: "Unknown"); put("score", score)
            })
        }
        player.writer.println(JSONObject().apply { put("type","leaderboard"); put("entries",arr) })
    }

    // ═════════════════════════════════════════════════════════════════════
    // BOTS
    // ═════════════════════════════════════════════════════════════════════
    private fun spawnBots() {
        val count = options.botCount.coerceIn(0, 8)
        for (i in 1..count) {
            val id = "B$i"
            val x = 5f + botRandom.nextFloat() * 90f
            val y = 5f + botRandom.nextFloat() * 90f
            val bot = ServerPlayer(
                id, "Bot $i", Socket(), PrintWriter(NullWriter()), BufferedReader(StringReader("")), "default",
                x = x, y = y, isBot = true
            )
            players[id] = bot
            rooms.getOrPut("default") { ServerRoom("default") }.addPlayer(id)
            botStates[id] = BotBrain.State(x, y)
        }
        if (count > 0) log("$count bots (${options.botDifficulty.label}) are in the arena")
    }

    private class NullWriter : Writer() {
        override fun write(cbuf: CharArray, off: Int, len: Int) {}
        override fun flush() {}
        override fun close() {}
    }

    private fun botTick(dtSec: Float) {
        val now = System.currentTimeMillis()
        for (bot in players.values.filter { it.isBot && it.health > 0 }) {
            val st = botStates[bot.id] ?: continue
            st.x = bot.x; st.y = bot.y; st.angle = bot.angle
            val target = players.values
                .filter { !it.isBot && it.health > 0 && it.roomId == bot.roomId }
                .minByOrNull { hypot((it.x - bot.x).toDouble(), (it.y - bot.y).toDouble()) }
            val r = BotBrain.step(st, target?.x, target?.y, dtSec, now, options.botDifficulty, botRandom)
            bot.x = st.x; bot.y = st.y; bot.angle = st.angle
            if (r.fired && target != null) {
                val weapon = "mp5"
                broadcastRoom(bot.roomId, JSONObject().apply {
                    put("type", "player_fired"); put("id", bot.id)
                    put("x", bot.x.toDouble()); put("y", bot.y.toDouble()); put("a", bot.angle.toDouble())
                    put("weapon", weapon); put("hit", r.hit)
                })
                if (r.hit) applyDamage(bot, target, weapon, options.botDifficulty.damageScale)
            }
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // UDP POSITION SNAPSHOTS (20 Hz tick)
    // ═════════════════════════════════════════════════════════════════════
    private suspend fun udpReceiveLoop() = withContext(Dispatchers.IO) {
        val buf = ByteArray(512)
        while (isRunning) {
            try {
                val pkt = DatagramPacket(buf, buf.size)
                udpSocket?.receive(pkt)
                val msg = JSONObject(String(pkt.data, 0, pkt.length))
                val p   = players[msg.optString("pid")] ?: continue
                p.x     = msg.optDouble("x").toFloat()
                p.y     = msg.optDouble("y").toFloat()
                p.angle = msg.optDouble("a").toFloat()
                p.udpAddr = pkt.address; p.udpPort = pkt.port
            } catch (_: Exception) {}
        }
    }

    private suspend fun tickLoop() = withContext(Dispatchers.IO) {
        while (isRunning) {
            delay(TICK_MS)
            if (botStates.isNotEmpty()) botTick(TICK_MS / 1000f)
            rooms.values.forEach { room ->
                val inRoom = players.values.filter { it.roomId == room.id && it.health > 0 }
                if (inRoom.size < 2) return@forEach
                val arr = JSONArray()
                inRoom.forEach { p -> arr.put(JSONObject().apply {
                    put("id",p.id); put("x",p.x); put("y",p.y); put("a",p.angle); put("hp",p.health)
                })}
                val bytes = JSONObject().apply {
                    put("type","world_state"); put("ts",System.currentTimeMillis()); put("players",arr)
                }.toString().toByteArray()
                inRoom.forEach { p ->
                    val addr = p.udpAddr ?: return@forEach
                    try { udpSocket?.send(DatagramPacket(bytes, bytes.size, addr, p.udpPort)) }
                    catch (_: Exception) {}
                }
            }
            updateStatus()
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // LAN DISCOVERY — broadcasts every 2 s so clients auto-find us
    // ═════════════════════════════════════════════════════════════════════
    private suspend fun discoveryBroadcastLoop() = withContext(Dispatchers.IO) {
        val broadcast = InetAddress.getByName("255.255.255.255")
        while (isRunning) {
            try {
                val bytes = JSONObject().apply {
                    put("type","echo_server"); put("magic",PROTOCOL_MAGIC); put("ver",PROTOCOL_VER)
                    put("ip",localIP()); put("port",TCP_PORT)
                    put("players",humanCount()); put("max",options.maxPlayers); put("name",options.serverName)
                }.toString().toByteArray()
                discSocket?.send(DatagramPacket(bytes, bytes.size, broadcast, DISC_PORT))
            } catch (_: Exception) {}
            delay(DISC_MS)
        }
    }

    // ═════════════════════════════════════════════════════════════════════
    // HELPERS
    // ═════════════════════════════════════════════════════════════════════
    private fun broadcastRoom(roomId: String, msg: JSONObject, exclude: String? = null) {
        val line = msg.toString()
        players.values.filter { it.roomId == roomId && it.id != exclude }
            .forEach { try { it.writer.println(line) } catch (_: Exception) {} }
    }

    private fun reject(reason: String) =
        JSONObject().apply { put("type","rejected"); put("reason",reason) }.toString()

    fun localIP(): String = try {
        val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ip = wm.connectionInfo.ipAddress
        "%d.%d.%d.%d".format(ip and 0xff, ip shr 8 and 0xff, ip shr 16 and 0xff, ip shr 24 and 0xff)
            .also { if (it == "0.0.0.0") throw Exception("wifi ip zero") }
    } catch (_: Exception) {
        NetworkInterface.getNetworkInterfaces()?.toList()
            ?.flatMap { it.inetAddresses.toList() }
            ?.firstOrNull { !it.isLoopbackAddress && it is Inet4Address }
            ?.hostAddress ?: "127.0.0.1"
    }

    /** Every IPv4 address of this device (WiFi, mobile, Tailscale ...), for showing to the host. */
    fun allIPs(): List<String> = try {
        NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
            .flatMap { it.inetAddresses.toList() }
            .filter { !it.isLoopbackAddress && it is Inet4Address }
            .mapNotNull { it.hostAddress }
    } catch (_: Exception) { emptyList() }

    private fun updateStatus() {
        onStatusUpdate?.invoke(ServerStatus(humanCount(), rooms.size, localIP(), TCP_PORT))
    }

    // ═════════════════════════════════════════════════════════════════════
    // AUTHORITATIVE WEAPON DAMAGE TABLE
    // ═════════════════════════════════════════════════════════════════════
    private val WEAPON_DAMAGE = mapOf(
        "glock17" to 35,    "deagle" to 75,      "usp45" to 42,
        "p250" to 38,       "revolver" to 85,
        "mp5" to 26,        "uzi" to 22,          "p90" to 24,
        "mac10" to 20,      "kriss" to 29,
        "m870" to 120,      "spas12" to 130,      "aa12" to 100,   "judge" to 115,
        "ak47" to 40,       "m4a1" to 35,         "scar_h" to 48,
        "aug" to 36,        "g36c" to 34,          "fal" to 50,    "tar21" to 37,
        "m14" to 58,        "mk17" to 60,
        "m249" to 38,       "minigun" to 20,       "mg42" to 36,
        "awp" to 115,       "barrett" to 200,      "sv98" to 95,   "dmr" to 65,
        "rpg7" to 300,      "stinger" to 500,      "m79" to 250,
        "knife" to 80
    )
}

// ── data classes ─────────────────────────────────────────────────────────────

data class ServerPlayer(
    val id: String, val displayName: String,
    val socket: Socket, val writer: PrintWriter, val reader: BufferedReader,
    val roomId: String,
    var x: Float = 50f, var y: Float = 50f, var angle: Float = 0f,
    var health: Int = 100, var kills: Int = 0, var deaths: Int = 0,
    var udpAddr: InetAddress? = null, var udpPort: Int = 0,
    val isBot: Boolean = false
) { fun close() = try { socket.close() } catch (_: Exception) {} }

class ServerRoom(val id: String) {
    private val ids = ConcurrentHashMap.newKeySet<String>()
    val scores = ConcurrentHashMap<String, Int>()
    fun addPlayer(id: String) { ids.add(id); scores.putIfAbsent(id, 0) }
    fun removePlayer(id: String) { ids.remove(id) }
}

data class ServerStatus(val players: Int, val rooms: Int, val ip: String, val port: Int)

/** Settings for a hosted or dedicated server. */
class HostOptions(
    var serverName: String = "EchoStrike Server",
    var maxPlayers: Int = EmbeddedGameServer.MAX_PLAYERS,
    var botCount: Int = 0,
    var botDifficulty: BotBrain.Difficulty = BotBrain.Difficulty.NORMAL,
    var requireLogin: Boolean = false,
    var allowRegistration: Boolean = true,
    var accounts: AccountStore? = null
)
