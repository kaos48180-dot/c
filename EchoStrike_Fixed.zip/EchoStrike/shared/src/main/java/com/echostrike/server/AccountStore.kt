package com.echostrike.server

import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * AccountStore — usernames and salted password hashes for a dedicated server.
 * Passwords are never stored, only PBKDF2 hashes. Pass file = null to keep accounts in memory only.
 */
class AccountStore(private val file: File?) {

    private class Entry(val name: String, val salt: ByteArray, val hash: ByteArray)

    private val entries = LinkedHashMap<String, Entry>()   // key = lowercase username

    init { load() }

    companion object {
        const val MIN_PASSWORD = 8
        private const val ITERATIONS = 60_000
        private val NAME_RE = Regex("^[A-Za-z0-9_.-]{3,20}$")

        fun validName(n: String) = NAME_RE.matches(n)

        private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
        private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

        private fun hash(password: String, salt: ByteArray): ByteArray =
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)).encoded
    }

    @Synchronized fun count() = entries.size
    @Synchronized fun names(): List<String> = entries.values.map { it.name }
    @Synchronized fun exists(user: String) = entries.containsKey(user.lowercase())

    /** Returns null on success, otherwise a message to show the player. */
    @Synchronized fun create(user: String, password: String): String? {
        if (!validName(user)) return "Username must be 3 to 20 letters, numbers, dots, dashes or underscores."
        if (password.length < MIN_PASSWORD) return "Password must be at least $MIN_PASSWORD characters."
        if (exists(user)) return "That username is already taken."
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        entries[user.lowercase()] = Entry(user, salt, hash(password, salt))
        save()
        return null
    }

    @Synchronized fun verify(user: String, password: String): Boolean {
        val e = entries[user.lowercase()] ?: return false
        return MessageDigest.isEqual(e.hash, hash(password, e.salt))
    }

    @Synchronized fun remove(user: String): Boolean {
        val removed = entries.remove(user.lowercase()) != null
        if (removed) save()
        return removed
    }

    @Synchronized fun setPassword(user: String, password: String): String? {
        val e = entries[user.lowercase()] ?: return "No such account."
        if (password.length < MIN_PASSWORD) return "Password must be at least $MIN_PASSWORD characters."
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        entries[user.lowercase()] = Entry(e.name, salt, hash(password, salt))
        save()
        return null
    }

    private fun load() {
        val f = file ?: return
        if (!f.exists()) return
        try {
            f.readLines().forEach { line ->
                val p = line.split('\t')
                if (p.size == 3) entries[p[0].lowercase()] = Entry(p[0], unhex(p[1]), unhex(p[2]))
            }
        } catch (_: Exception) { /* corrupt file: start empty */ }
    }

    private fun save() {
        val f = file ?: return
        try {
            f.parentFile?.mkdirs()
            val tmp = File(f.path + ".tmp")
            tmp.writeText(entries.values.joinToString("\n") { "${it.name}\t${hex(it.salt)}\t${hex(it.hash)}" })
            tmp.renameTo(f)
        } catch (_: Exception) { }
    }
}
