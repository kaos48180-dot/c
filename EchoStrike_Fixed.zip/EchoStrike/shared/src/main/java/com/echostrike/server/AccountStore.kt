package com.echostrike.server

import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * AccountStore — usernames and salted password hashes for a dedicated server.
 * Passwords are never stored, only PBKDF2 hashes. Pass file = null to keep accounts in memory only.
 */
class AccountStore(private val file: File?) {

    private class Entry(val name: String, val salt: ByteArray, val hash: ByteArray, var admin: Boolean = false)

    private val entries = LinkedHashMap<String, Entry>()   // key = lowercase username
    private val requests = LinkedHashSet<String>()          // lowercase names waiting for admin approval

    init { load() }

    companion object {
        const val MIN_PASSWORD = 8
        private const val ITERATIONS = 60_000
        private val NAME_RE = Regex("^[A-Za-z0-9_.-]{3,20}$")

        fun validName(n: String) = NAME_RE.matches(n)

        private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
        private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

        private fun hash(password: String, salt: ByteArray): ByteArray =
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)).encoded
    }

    @Synchronized fun count() = entries.size
    @Synchronized fun names(): List<String> = entries.values.map { it.name }
    @Synchronized fun exists(user: String) = entries.containsKey(user.lowercase())

    /** Returns null on success, otherwise a message to show the player. */
    @Synchronized fun create(user: String, password: String): String? {
        if (!validName(user)) return "Username must be 3 to 20 letters, numbers, dots, dashes or underscores."
        if (password.length < MIN_PASSWORD) return "Password must be at least $MIN_PASSWORD characters."
        if (exists(user)) return "That username is already taken."
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        entries[user.lowercase()] = Entry(user, salt, hash(password, salt))
        save()
        return null
    }

    @Synchronized fun verify(user: String, password: String): Boolean {
        val e = entries[user.lowercase()] ?: return false
        return MessageDigest.isEqual(e.hash, hash(password, e.salt))
    }

    // ── admin rights ─────────────────────────────────────────────────────
    @Synchronized fun isAdmin(user: String) = entries[user.lowercase()]?.admin == true
    @Synchronized fun admins(): List<String> = entries.values.filter { it.admin }.map { it.name }

    /** A player asks to become an admin. Returns null if the request was recorded, else a message. */
    @Synchronized fun requestAdmin(user: String): String? {
        val e = entries[user.lowercase()] ?: return "No such account."
        if (e.admin) return "You are already an admin."
        requests.add(user.lowercase()); save()
        return null
    }
    @Synchronized fun pendingRequests(): List<String> =
        requests.mapNotNull { entries[it]?.name }
    @Synchronized fun approve(user: String): Boolean {
        val e = entries[user.lowercase()] ?: return false
        e.admin = true; requests.remove(user.lowercase()); save(); return true
    }
    @Synchronized fun deny(user: String): Boolean {
        val r = requests.remove(user.lowercase()); if (r) save(); return r
    }
    @Synchronized fun revoke(user: String): Boolean {
        val e = entries[user.lowercase()] ?: return false
        if (!e.admin) return false
        e.admin = false; save(); return true
    }

    /** Creates (or resets the password of) the main developer account and makes it an admin. */
    @Synchronized fun setDeveloper(user: String, password: String): String? {
        val err = if (exists(user)) setPassword(user, password) else create(user, password)
        if (err != null) return err
        entries[user.lowercase()]?.admin = true
        requests.remove(user.lowercase()); save()
        return null
    }

    @Synchronized fun remove(user: String): Boolean {
        val removed = entries.remove(user.lowercase()) != null
        requests.remove(user.lowercase())
        if (removed) save()
        return removed
    }

    @Synchronized fun setPassword(user: String, password: String): String? {
        val e = entries[user.lowercase()] ?: return "No such account."
        if (password.length < MIN_PASSWORD) return "Password must be at least $MIN_PASSWORD characters."
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        entries[user.lowercase()] = Entry(e.name, salt, hash(password, salt), e.admin)
        save()
        return null
    }

    private fun load() {
        val f = file ?: return
        if (!f.exists()) return
        try {
            f.readLines().forEach { line ->
                val p = line.split('\t')
                if (p.size >= 3 && p[0] != "#request")
                    entries[p[0].lowercase()] = Entry(p[0], unhex(p[1]), unhex(p[2]), p.getOrNull(3) == "admin")
                else if (p.size == 2 && p[0] == "#request") requests.add(p[1].lowercase())
            }
        } catch (_: Exception) { /* corrupt file: start empty */ }
    }

    private fun save() {
        val f = file ?: return
        try {
            f.parentFile?.mkdirs()
            val tmp = File(f.path + ".tmp")
            val lines = entries.values.map { "${it.name}\t${hex(it.salt)}\t${hex(it.hash)}\t${if (it.admin) "admin" else "user"}" } +
                requests.map { "#request\t$it" }
            tmp.writeText(lines.joinToString("\n"))
            tmp.renameTo(f)
        } catch (_: Exception) { }
    }
}
