package com.echostrike.developer

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * EchoStrike Developer Console.
 *
 *  1. Test server connection  — GET /health
 *  2. Check admin token       — GET /admin/account
 *  3. Save main account       — POST /admin/account
 *  4. Send server to player app — hands the server address to the EchoStrike app
 *     (only works because both apps are signed with the same key).
 *
 * The admin token and password are typed in each time and never stored.
 * Only the server address is remembered.
 */
class DeveloperActivity : Activity() {

    private lateinit var server: EditText
    private lateinit var token: EditText
    private lateinit var username: EditText
    private lateinit var password: EditText
    private lateinit var status: TextView

    private val playerPackage = "com.echostrike"
    private val prefs by lazy { getSharedPreferences("console", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(28, 28, 28, 28); setBackgroundColor(Color.BLACK)
        }
        fun label(text: String) {
            layout.addView(TextView(this).apply {
                this.text = text; setTextColor(Color.WHITE); textSize = 16f
                setPadding(0, 12, 0, 4)
            })
        }
        fun field(hintText: String, secret: Boolean = false): EditText = EditText(this).apply {
            hint = hintText; setTextColor(Color.WHITE); setHintTextColor(0xFFBBBBBB.toInt()); contentDescription = hintText
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            layout.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fun button(text: String, action: () -> Unit) {
            layout.addView(Button(this).apply {
                this.text = text; contentDescription = text; setOnClickListener { action() }
            })
        }

        label("EchoStrike Developer Console")
        label("Server address (your deployed https address):")
        server = field("https://your-app.fly.dev")
        val saved = prefs.getString("server_url", null)
        server.setText(saved ?: if (BuildConfig.ECHO_SERVER_HOST.isNotBlank()) "https://${BuildConfig.ECHO_SERVER_HOST}" else "")
        button("1. Test server connection") { testConnection() }

        label("Admin token (the ADMIN_TOKEN secret; typed each time, never saved):")
        token = field("Admin token", true)
        button("2. Check admin token and account") { checkAccount() }

        label("Main account for the player app:")
        username = field("Main account username (default: Chaos)").apply { inputType = InputType.TYPE_CLASS_TEXT; setText("Chaos") }
        password = field("New main account password (12+ characters)", true)
        button("3. Save main account on server") { saveAccount() }

        label("Connect the player app:")
        button("4. Send server address to EchoStrike app") { sendToPlayerApp() }

        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; setPadding(0, 20, 0, 0)
            contentDescription = "Status"; text = "Ready."
            accessibilityLiveRegion = TextView.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        layout.addView(status)
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    // ── helpers ──────────────────────────────────────────────────────────
    private fun baseUrl(): String? {
        val base = server.text.toString().trim().trimEnd('/')
        val full = if (base.startsWith("https://")) base else if (base.isNotEmpty() && !base.contains("://")) "https://$base" else ""
        if (!full.startsWith("https://") || full.length < 12) {
            status.text = "Enter your server address, for example https://your-app.fly.dev"
            return null
        }
        server.setText(full)
        return full
    }

    private class Reply(val code: Int, val body: String)

    private fun request(url: String, method: String, bearer: String?, json: String?): Reply {
        var c: HttpURLConnection? = null
        try {
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = method; connectTimeout = 10000; readTimeout = 15000
                if (bearer != null) setRequestProperty("Authorization", "Bearer $bearer")
                if (json != null) { doOutput = true; setRequestProperty("Content-Type", "application/json") }
            }
            c = conn
            if (json != null) conn.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return Reply(code, body)
        } finally {
            c?.disconnect()
        }
    }

    private fun errorText(body: String): String =
        try { JSONObject(body).optString("error").ifBlank { body.take(200) } } catch (_: Exception) { body.take(200) }

    private fun run(working: String, job: () -> String) {
        status.text = working
        thread {
            val msg = try { job() } catch (e: Exception) { "Could not reach the server: ${e.message ?: "network error"}" }
            runOnUiThread { status.text = msg }
        }
    }

    // ── 1. health ────────────────────────────────────────────────────────
    private fun testConnection() {
        val base = baseUrl() ?: return
        run("Testing connection…") {
            val t0 = System.currentTimeMillis()
            val r = request("$base/health", "GET", null, null)
            val ms = System.currentTimeMillis() - t0
            if (r.code in 200..299) {
                prefs.edit().putString("server_url", base).apply()
                "Server is online (${ms} ms). Address saved."
            } else "Server answered with error ${r.code}. Is the cloud server deployed and running?"
        }
    }

    // ── 2. admin check ───────────────────────────────────────────────────
    private fun checkAccount() {
        val base = baseUrl() ?: return
        val admin = token.text.toString()
        if (admin.isBlank()) { status.text = "Enter the admin token first."; return }
        run("Checking…") {
            val r = request("$base/admin/account", "GET", admin, null)
            when {
                r.code in 200..299 -> {
                    prefs.edit().putString("server_url", base).apply()
                    val j = JSONObject(r.body)
                    if (j.optBoolean("configured")) "Admin token accepted. Main account '${j.optString("username")}' is set up."
                    else "Admin token accepted. No main account yet. Fill in the account fields and use button 3."
                }
                r.code == 401 -> "Admin token rejected. It must match the ADMIN_TOKEN secret the server was deployed with."
                else -> "Server error ${r.code}: ${errorText(r.body)}"
            }
        }
    }

    // ── 3. save account ──────────────────────────────────────────────────
    private fun saveAccount() {
        val base = baseUrl() ?: return
        val admin = token.text.toString()
        val user = username.text.toString().trim()
        val pass = password.text.toString()
        if (admin.isBlank() || user.isBlank() || pass.length < 12) {
            status.text = "Enter the admin token, a username, and a password of at least 12 characters."
            return
        }
        status.text = "Saving account…"
        thread {
            val msg = try {
                val payload = JSONObject().put("username", user).put("password", pass).toString()
                val r = request("$base/admin/account", "POST", admin, payload)
                when {
                    r.code in 200..299 -> {
                        prefs.edit().putString("server_url", base).apply()
                        "Main account '$user' saved on the server. Now use button 4 to connect the player app."
                    }
                    r.code == 401 -> "Admin token rejected."
                    else -> "Server error ${r.code}: ${errorText(r.body)}"
                }
            } catch (e: Exception) { "Could not reach the server: ${e.message ?: "network error"}" }
            runOnUiThread {
                status.text = msg
                if (msg.startsWith("Main account")) { password.setText(""); token.setText("") }
            }
        }
    }

    // ── 4. hand the address to the player app ────────────────────────────
    private fun sendToPlayerApp() {
        val base = baseUrl() ?: return
        val host = base.removePrefix("https://").trimEnd('/').substringBefore('/')
        try { packageManager.getPackageInfo(playerPackage, 0) } catch (_: PackageManager.NameNotFoundException) {
            status.text = "The EchoStrike player app is not installed. Install the other APK first."
            return
        }
        val i = Intent("com.echostrike.action.CONFIGURE_SERVER").apply {
            component = ComponentName(playerPackage, "com.echostrike.ui.MainActivity")
            putExtra("host", host)
        }
        try {
            prefs.edit().putString("server_url", base).apply()
            startActivityForResult(i, 77)
        } catch (e: Exception) {
            status.text = "Could not open the EchoStrike app: ${e.message}"
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 77) return
        status.text = if (resultCode == RESULT_OK)
            "The EchoStrike app now uses ${data?.getStringExtra("host") ?: "your server"}."
        else
            "The EchoStrike app refused the address. Both apps must come from the same build (same signing key). Reinstall both APKs from the same build."
    }
}
