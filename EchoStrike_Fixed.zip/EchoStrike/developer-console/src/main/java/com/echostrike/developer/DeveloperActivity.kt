package com.echostrike.developer

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.echostrike.security.APKValidator
import com.echostrike.server.EmbeddedGameServer
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

/**
 * EchoStrike Developer Console.
 *
 * Sign in with an ADMIN account on your EchoStrike Server (the server app). No token needed:
 * your developer account is made in the server app, and other admins are approved there or here.
 * Address, username and password are remembered on this phone, so next time it signs in by itself.
 */
class DeveloperActivity : Activity() {

    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val playerPackage = "com.echostrike"

    private var socket: Socket? = null
    private var reader: BufferedReader? = null
    private var writer: PrintWriter? = null
    @Volatile private var signedIn = false

    private lateinit var status: TextView
    private lateinit var output: TextView
    private lateinit var address: EditText
    private lateinit var user: EditText
    private lateinit var pass: EditText
    private lateinit var signBtn: Button
    private lateinit var panel: LinearLayout
    private lateinit var target: EditText
    private lateinit var message: EditText

    private val prefs by lazy { getSharedPreferences("console", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val keepAlive = object : Runnable {
        override fun run() { if (signedIn) { command("status", "", quiet = true); ui.postDelayed(this, 20_000) } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24)); setBackgroundColor(Color.BLACK)
        }
        fun add(v: View) = col.addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        fun text(t: String, size: Float = 17f, color: Int = Color.WHITE) = TextView(this).apply {
            this.text = t; textSize = size; setTextColor(color); setPadding(0, dp(8), 0, dp(2)); add(this)
        }
        fun field(hint: String, value: String, secret: Boolean = false) = EditText(this).apply {
            this.hint = hint; setText(value); textSize = 18f; setTextColor(Color.WHITE); setHintTextColor(0xFF999999.toInt())
            contentDescription = hint
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            add(this)
        }
        fun button(t: String, p: LinearLayout = col, onClick: () -> Unit) = Button(this).apply {
            text = t; textSize = 17f; setOnClickListener { onClick() }
            p.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        text("EchoStrike Developer Console", 24f).setTypeface(null, Typeface.BOLD)
        status = text("Not signed in.", 18f, 0xFFFFD54F.toInt()).apply { accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE }

        text("Server address (shown in the server app)")
        address = field("Example 192.168.1.20 or 100.64.1.2", prefs.getString("address", "") ?: "")
        text("Admin username")
        user = field("Admin username", prefs.getString("user", "") ?: "")
        text("Admin password")
        pass = field("Admin password", prefs.getString("pass", "") ?: "", secret = true)
        signBtn = button("Sign in") { if (signedIn) signOut("Signed out.") else signIn() }
        button("Send this address to the EchoStrike game") { sendToPlayerApp() }

        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        add(panel)
        TextView(this).apply {
            text = "Admin tools"; textSize = 22f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(18), 0, dp(4)); panel.addView(this)
        }
        button("Server status", panel) { command("status") }
        button("Who is online", panel) { command("players") }
        button("Admin requests waiting", panel) { command("requests") }
        button("All accounts", panel) { command("accounts") }
        TextView(this).apply { text = "Player or account name"; textSize = 17f; setTextColor(Color.WHITE); panel.addView(this) }
        target = EditText(this).apply {
            hint = "Name"; contentDescription = "Player or account name"; textSize = 18f
            setTextColor(Color.WHITE); setHintTextColor(0xFF999999.toInt()); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            panel.addView(this)
        }
        button("Approve as admin", panel) { command("approve", target.text.toString()) }
        button("Deny admin request", panel) { command("deny", target.text.toString()) }
        button("Remove admin rights", panel) { command("revoke", target.text.toString()) }
        button("Kick player", panel) { command("kick", target.text.toString()) }
        button("Delete account", panel) { command("delete", target.text.toString()) }
        TextView(this).apply { text = "Message to everyone"; textSize = 17f; setTextColor(Color.WHITE); panel.addView(this) }
        message = EditText(this).apply {
            hint = "Message"; contentDescription = "Message to everyone"; textSize = 18f
            setTextColor(Color.WHITE); setHintTextColor(0xFF999999.toInt()); inputType = InputType.TYPE_CLASS_TEXT
            panel.addView(this)
        }
        button("Say to everyone", panel) { command("say", message.text.toString()); message.setText("") }

        output = text("", 17f, 0xFF66FF66.toInt()).apply {
            setBackgroundColor(0xFF111111.toInt()); setPadding(dp(8), dp(8), dp(8), dp(8))
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) })

        if (address.text.isNotBlank() && user.text.isNotBlank() && pass.text.isNotBlank()) signIn()
    }

    // ── connection ───────────────────────────────────────────────────────
    private fun signIn() {
        val addr = address.text.toString().trim()
        val u = user.text.toString().trim()
        val p = pass.text.toString()
        if (addr.isEmpty() || u.isEmpty() || p.isEmpty()) { say("Type the server address, your admin username and password."); return }
        signBtn.isEnabled = false
        say("Signing in to $addr.")
        io.execute {
            var host = addr; var port = EmbeddedGameServer.TCP_PORT
            val c = addr.lastIndexOf(':')
            if (c > 0 && addr.indexOf(':') == c) addr.substring(c + 1).toIntOrNull()?.let { port = it; host = addr.substring(0, c) }
            var err: String? = null
            try {
                val s = Socket()
                s.connect(InetSocketAddress(host, port), 5000)
                s.soTimeout = 8000
                val r = BufferedReader(InputStreamReader(s.getInputStream()))
                val w = PrintWriter(s.getOutputStream(), true)
                w.println(JSONObject().apply {
                    put("magic", EmbeddedGameServer.PROTOCOL_MAGIC); put("ver", EmbeddedGameServer.PROTOCOL_VER)
                    put("token", APKValidator.computeToken(this@DeveloperActivity))
                    put("name", u); put("user", u); put("pass", p); put("role", "console")
                }.toString())
                val reply = JSONObject(r.readLine() ?: throw Exception("The server closed the connection."))
                if (reply.optString("type") == "console_ok") {
                    socket = s; reader = r; writer = w; signedIn = true
                    prefs.edit().putString("address", addr).putString("user", u).putString("pass", p).apply()
                    val name = reply.optString("serverName")
                    ui.post {
                        panel.visibility = View.VISIBLE; signBtn.text = "Sign out"
                        say("Signed in as ${reply.optString("admin")} on $name.")
                        ui.removeCallbacks(keepAlive); ui.postDelayed(keepAlive, 20_000)
                    }
                    command("status")
                } else {
                    s.close()
                    err = reply.optString("reason", "The server said no.")
                }
            } catch (e: Exception) {
                err = when (e) {
                    is java.net.ConnectException, is java.net.SocketTimeoutException ->
                        "Cannot reach the server. Check the address and that the server app is running."
                    else -> e.message ?: "Network error."
                }
            }
            ui.post { signBtn.isEnabled = true; err?.let { say(it) } }
        }
    }

    private fun signOut(msg: String) {
        signedIn = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null; reader = null; writer = null
        ui.post { panel.visibility = View.GONE; signBtn.text = "Sign in"; signBtn.isEnabled = true; say(msg) }
    }

    private fun command(cmd: String, arg: String = "", quiet: Boolean = false) {
        if (!signedIn) { say("Sign in first."); return }
        io.execute {
            try {
                writer!!.println(JSONObject().put("type", "cmd").put("cmd", cmd).put("arg", arg.trim()).toString())
                val line = reader!!.readLine() ?: throw Exception("closed")
                val text = JSONObject(line).optString("text")
                if (!quiet) ui.post { output.text = text; output.announceForAccessibility(text) }
            } catch (_: Exception) {
                if (signedIn) signOut("Connection lost. Tap Sign in to reconnect.")
            }
        }
    }

    private fun say(t: String) { status.text = t; status.announceForAccessibility(t) }

    // ── hand the address to the player app ───────────────────────────────
    private fun sendToPlayerApp() {
        val addr = address.text.toString().trim()
        if (addr.isEmpty()) { say("Type the server address first."); return }
        try { packageManager.getPackageInfo(playerPackage, 0) } catch (_: PackageManager.NameNotFoundException) {
            say("The EchoStrike game is not installed. Install the Player APK first."); return
        }
        val i = Intent("com.echostrike.action.CONFIGURE_SERVER").apply {
            component = ComponentName(playerPackage, "com.echostrike.ui.MainActivity")
            putExtra("host", addr)
        }
        try { startActivityForResult(i, 77) } catch (e: Exception) { say("Could not open the game: ${e.message}") }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 77) return
        say(if (resultCode == RESULT_OK) "The game will now start with this server address filled in."
            else "The game refused the address. Install all apps from the same build.")
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        signedIn = false
        try { socket?.close() } catch (_: Exception) {}
        io.shutdownNow()
    }
}
